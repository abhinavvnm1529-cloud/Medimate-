package com.abhi.medimate;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.res.Configuration;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.media.AudioManager;
import android.app.Activity;
import androidx.core.view.WindowInsetsControllerCompat;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.util.Base64;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.app.NotificationManager;
import android.app.DownloadManager;
import android.os.Environment;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONArray;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.pm.PackageInstaller;
import android.app.PendingIntent;
import android.media.AudioAttributes;
import android.os.Process;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@CapacitorPlugin(name = "MediMateAlarm")
public class MediMateAlarmPlugin extends Plugin {

    private boolean notifGranted() {
        return Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(getContext(),
                Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void requestSetup(PluginCall call) {
        try {
            if (!notifGranted()) {
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4711);
            }
        } catch (Exception ignored) { }
        call.resolve(new JSObject());
    }

    @Override
    protected void handleOnResume() {
        super.handleOnResume();
        try {
            if (Build.VERSION.SDK_INT >= 34 && notifGranted()) {
                NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
                SharedPreferences sp = getContext().getSharedPreferences("mm_setup", Context.MODE_PRIVATE);
                if (!nm.canUseFullScreenIntent() && !sp.getBoolean("fsi_asked", false)) {
                    sp.edit().putBoolean("fsi_asked", true).apply();
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:" + getContext().getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i);
                }
            }
        } catch (Exception ignored) { }
    }

    @PluginMethod
    public void stopAlarm(PluginCall call) {
        try {
            NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            nm.cancelAll();
        } catch (Exception ignored) { }
        call.resolve(new JSObject());
    }

    @PluginMethod
    public void savePdf(PluginCall call) {
        try {
            String name = call.getString("name", "MediMate.pdf");
            String data = call.getString("data");
            if (data == null) { call.reject("no data"); return; }
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            Context c = getContext();
            JSObject r = new JSObject();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) { call.reject("could not create file"); return; }
                OutputStream os = c.getContentResolver().openOutputStream(u);
                if (os == null) { call.reject("could not open file"); return; }
                try { os.write(bytes); } finally { os.close(); }
                r.put("saved", true);
                r.put("uri", u.toString());
            } else {
                File dir = new File(c.getCacheDir(), "pdf");
                dir.mkdirs();
                File f = new File(dir, name);
                FileOutputStream fo = new FileOutputStream(f);
                try { fo.write(bytes); } finally { fo.close(); }
                Uri uri = FileProvider.getUriForFile(c, c.getPackageName() + ".fileprovider", f);
                Intent s = new Intent(Intent.ACTION_SEND);
                s.setType("application/pdf");
                s.putExtra(Intent.EXTRA_STREAM, uri);
                s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent ch = Intent.createChooser(s, "Save or share your timetable");
                ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(ch);
                r.put("saved", false);
            }
            call.resolve(r);
        } catch (Exception e) {
            call.reject("save failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void openPdf(PluginCall call) {
        try {
            String uri = call.getString("uri");
            if (uri == null) { call.reject("no uri"); return; }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(uri), "application/pdf");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve(new JSObject());
        } catch (Exception e) {
            call.reject("open failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void setOrientation(PluginCall call) {
        final String mode = call.getString("mode", "auto");
        final Activity a = getActivity();
        a.runOnUiThread(() -> a.setRequestedOrientation("portrait".equals(mode)
                ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                : "landscape".equals(mode) ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : "system".equals(mode) ? ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                : ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR));
        call.resolve(new JSObject());
    }

    @PluginMethod
    public void setPrefs(PluginCall call) {
        try {
            Integer tone = call.getInt("tone", 0);
            Integer vol = call.getInt("vol", 80);
            getContext().getSharedPreferences("mm_setup", Context.MODE_PRIVATE).edit().putInt("tone", tone).apply();
            AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            am.setStreamVolume(AudioManager.STREAM_ALARM, Math.max(1, Math.round(Math.max(10, vol) / 100f * max)), 0);
        } catch (Exception ignored) { }
        call.resolve(new JSObject());
    }

    @PluginMethod
    public void setBars(PluginCall call) {
        final boolean dark = Boolean.TRUE.equals(call.getBoolean("dark", false));
        final Activity a = getActivity();
        a.runOnUiThread(() -> {
            a.getWindow().getDecorView().setBackgroundColor(Color.parseColor(dark ? "#070502" : "#f8fafd"));
            WindowInsetsControllerCompat c = new WindowInsetsControllerCompat(a.getWindow(), a.getWindow().getDecorView());
            c.setAppearanceLightStatusBars(!dark);
            c.setAppearanceLightNavigationBars(!dark);
        });
        call.resolve(new JSObject());
    }

    @PluginMethod
    public void haptic(PluginCall call) {
        try {
            Vibrator v = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
            boolean click = "click".equals(call.getString("kind", "tick"));
            int intensity = Math.max(0, Math.min(100, call.getInt("intensity", 72)));
            if (v != null && v.hasVibrator() && intensity > 0) {
                // Low really is gentle and High really is strong: strength AND length both follow the slider.
                // 1% = a faint short tick, 100% = full motor amplitude with the longest pulse.
                float f = intensity / 100f;
                int duration = Math.round((click ? 16 : 12) + f * (click ? 34 : 26)); // ~16-50 ms
                if (Build.VERSION.SDK_INT >= 26) {
                    VibrationEffect fx;
                    if (v.hasAmplitudeControl()) {
                        int amp = Math.max(18, Math.min(255, Math.round(18 + f * f * 237f)));
                        if (intensity >= 97) amp = 255;
                        fx = VibrationEffect.createOneShot(duration, amp);
                    } else {
                        // No amplitude control: imitate strength with length and an on/off duty cycle.
                        int on = Math.max(6, Math.round(duration * (0.35f + 0.65f * f)));
                        if (intensity >= 90) {
                            fx = VibrationEffect.createOneShot(duration + 10, VibrationEffect.DEFAULT_AMPLITUDE);
                        } else {
                            int off = Math.max(2, Math.round(on * (1f - f) * 0.8f));
                            fx = VibrationEffect.createWaveform(new long[]{0, on, off, Math.max(4, on / 2)}, -1);
                        }
                    }
                    // Accessibility-type vibration is not muted by the system "touch feedback" switch
                    // or by silent mode, which is why the old touch-type haptics could feel dead on some phones.
                    boolean played = false;
                    try {
                        if (Build.VERSION.SDK_INT >= 33) {
                            v.vibrate(fx, android.os.VibrationAttributes.createForUsage(android.os.VibrationAttributes.USAGE_ACCESSIBILITY));
                        } else {
                            v.vibrate(fx, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                        }
                        played = true;
                    } catch (Exception e) { /* try the plain call below */ }
                    if (!played) v.vibrate(fx);
                } else {
                    v.vibrate(duration);
                }
            }
        } catch (Exception ignored) { }
        call.resolve(new JSObject());
    }

    private void emitProgress(String status, long done, long total, String msg) {
        JSObject o = new JSObject();
        o.put("status", status); o.put("done", done); o.put("total", total);
        if (msg != null) o.put("message", msg);
        notifyListeners("updateProgress", o);
    }

    private volatile boolean updCancel = false;
    private volatile boolean updRunning = false;

    private boolean trustedHost(String url) {
        try {
            Uri u = Uri.parse(url);
            String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
            return "https".equals(u.getScheme()) && (h.equals("github.com") || h.endsWith(".githubusercontent.com"));
        } catch (Exception e) { return false; }
    }

    @PluginMethod
    public void canInstall(PluginCall call) {
        JSObject r = new JSObject();
        r.put("ok", Build.VERSION.SDK_INT < 26 || getContext().getPackageManager().canRequestPackageInstalls());
        call.resolve(r);
    }

    @PluginMethod
    public void allowInstalls(PluginCall call) {
        try {
            Context ctx = getContext();
            Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
            call.resolve(new JSObject());
        } catch (Exception e) { call.reject("settings unavailable"); }
    }

    @PluginMethod
    public void cancelUpdate(PluginCall call) {
        updCancel = true;
        call.resolve(new JSObject());
    }

    @PluginMethod
    public void downloadApk(final PluginCall call) {
        final String url = call.getString("url", "");
        final String want = call.getString("sha256", "");
        if (!trustedHost(url)) { call.reject("Untrusted APK download address"); return; }
        if (updRunning) { call.resolve(new JSObject()); return; }
        updRunning = true; updCancel = false;
        call.resolve(new JSObject());
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                File dir = new File(getContext().getCacheDir(), "update");
                dir.mkdirs();
                File apk = new File(dir, "MediMate-update.apk");
                File part = new File(dir, "MediMate-update.part");
                if (apk.exists()) apk.delete();
                long have = part.exists() ? part.length() : 0;
                String cur = url;
                int code = 0;
                // follow redirects by hand so every hop is checked against the trusted hosts
                for (int hop = 0; hop < 6; hop++) {
                    c = (HttpURLConnection) new URL(cur).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(15000); c.setReadTimeout(20000);
                    c.setRequestProperty("User-Agent", "MediMate-Updater");
                    if (have > 0) c.setRequestProperty("Range", "bytes=" + have + "-");
                    code = c.getResponseCode();
                    if (code / 100 == 3) {
                        String loc = c.getHeaderField("Location");
                        c.disconnect();
                        if (loc == null || !trustedHost(loc)) { emitProgress("error", 0, 0, "Update server redirected somewhere untrusted"); return; }
                        cur = loc; continue;
                    }
                    break;
                }
                if (code == 416) { part.delete(); have = 0; emitProgress("error", 0, 0, "Download was interrupted. Tap Update again."); return; }
                if (code != 200 && code != 206) { emitProgress("error", 0, 0, "Update server replied " + code); return; }
                boolean resumed = code == 206;
                if (!resumed) have = 0;
                long len = c.getContentLengthLong();
                long total = len > 0 ? len + have : -1;
                InputStream in = c.getInputStream();
                FileOutputStream out = new FileOutputStream(part, resumed);
                byte[] buf = new byte[65536];
                long done = have, last = 0, t0 = System.currentTimeMillis(), base = have; int n;
                while ((n = in.read(buf)) > 0) {
                    if (updCancel) { out.close(); in.close(); c.disconnect(); emitProgress("cancelled", done, total, "Update cancelled"); return; }
                    out.write(buf, 0, n); done += n;
                    long now = System.currentTimeMillis();
                    if (now - last > 200) {
                        last = now;
                        JSObject o = new JSObject();
                        o.put("status", "downloading"); o.put("done", done); o.put("total", total);
                        o.put("bps", (done - base) * 1000L / Math.max(1, now - t0));
                        notifyListeners("updateProgress", o);
                    }
                }
                out.getFD().sync(); out.close(); in.close(); c.disconnect();
                if (total > 0 && done < total) { emitProgress("error", 0, 0, "Download stopped early. Tap Update to continue."); return; }
                emitProgress("verifying", done, done, "Checking the update is genuine\u2026");
                if (!part.renameTo(apk)) { emitProgress("error", 0, 0, "Could not save the update"); return; }
                String problem = verifyApk(apk, want);
                if (problem != null) { apk.delete(); part.delete(); emitProgress("error", 0, 0, problem); return; }
                emitProgress("installing", done, done, null);
                installApk(apk);
            } catch (Exception e) {
                emitProgress("error", 0, 0, "Connection problem. Tap Update to continue.");
            } finally {
                updRunning = false;
                try { if (c != null) c.disconnect(); } catch (Exception ignored) { }
            }
        }).start();
    }

    /** Returns null when the file is a genuine, newer MediMate build signed with the same key; otherwise a plain-English problem. */
    private String verifyApk(File apk, String wantSha) {
        try {
            if (wantSha != null && wantSha.length() >= 64) {
                java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
                InputStream is = new java.io.FileInputStream(apk);
                byte[] b = new byte[65536]; int n;
                while ((n = is.read(b)) > 0) md.update(b, 0, n);
                is.close();
                StringBuilder sb = new StringBuilder();
                for (byte x : md.digest()) sb.append(String.format("%02x", x));
                if (!sb.toString().equalsIgnoreCase(wantSha.replace("sha256:", "").trim()))
                    return "The downloaded file did not match the published checksum, so it was discarded.";
            }
            PackageManager pm = getContext().getPackageManager();
            int flags = Build.VERSION.SDK_INT >= 28 ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
            android.content.pm.PackageInfo np = pm.getPackageArchiveInfo(apk.getAbsolutePath(), flags);
            android.content.pm.PackageInfo op = pm.getPackageInfo(getContext().getPackageName(), flags);
            if (np == null) return "The downloaded file is not a valid app.";
            if (!getContext().getPackageName().equals(np.packageName)) return "The downloaded file is not MediMate.";
            long nv = Build.VERSION.SDK_INT >= 28 ? np.getLongVersionCode() : np.versionCode;
            long ov = Build.VERSION.SDK_INT >= 28 ? op.getLongVersionCode() : op.versionCode;
            if (nv <= ov) return "This update is not newer than the version you have.";
            android.content.pm.Signature[] ns, os;
            if (Build.VERSION.SDK_INT >= 28) {
                ns = np.signingInfo == null ? null : np.signingInfo.getApkContentsSigners();
                os = op.signingInfo == null ? null : op.signingInfo.getApkContentsSigners();
            } else { ns = np.signatures; os = op.signatures; }
            if (ns == null || os == null || ns.length == 0 || !ns[0].equals(os[0]))
                return "The update is signed by a different developer key, so it was not installed.";
            return null;
        } catch (Exception e) {
            return "Could not verify the update.";
        }
    }

    private void installApk(File apk) throws Exception {
        final Context ctx = getContext();
        if (Build.VERSION.SDK_INT >= 26 && !ctx.getPackageManager().canRequestPackageInstalls()) {
            emitProgress("needpermission", 0, 0, "Allow MediMate to install updates");
            return;
        }
        PackageInstaller pi = ctx.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams sp = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        sp.setAppPackageName(ctx.getPackageName());
        if (Build.VERSION.SDK_INT >= 31) sp.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
        int sid = pi.createSession(sp);
        PackageInstaller.Session ses = pi.openSession(sid);
        InputStream in = new java.io.FileInputStream(apk);
        OutputStream os = ses.openWrite("medimate", 0, apk.length());
        byte[] b = new byte[65536]; int n;
        while ((n = in.read(b)) > 0) os.write(b, 0, n);
        ses.fsync(os); os.close(); in.close();
        final String action = ctx.getPackageName() + ".INSTALL_RESULT";
        BroadcastReceiver rcv = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent it) {
                int st = it.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
                if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                    Intent confirm = it.getParcelableExtra(Intent.EXTRA_INTENT);
                    if (confirm != null) { confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(confirm); }
                } else if (st == PackageInstaller.STATUS_SUCCESS) {
                    emitProgress("done", apk.length(), apk.length(), "Installation completed.");
                    try { c.unregisterReceiver(this); } catch (Exception ignored) { }
                } else {
                    String m = it.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
                    emitProgress(st == PackageInstaller.STATUS_FAILURE_ABORTED ? "cancelled" : "error", 0, 0,
                            st == PackageInstaller.STATUS_FAILURE_ABORTED ? "Install cancelled" : (m == null ? "Install failed" : m));
                    try { c.unregisterReceiver(this); } catch (Exception ignored) { }
                }
            }
        };
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(rcv, new IntentFilter(action), Context.RECEIVER_NOT_EXPORTED);
        else ctx.registerReceiver(rcv, new IntentFilter(action));
        Intent cb = new Intent(action).setPackage(ctx.getPackageName());
        PendingIntent pend = PendingIntent.getBroadcast(ctx, sid, cb,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0));
        ses.commit(pend.getIntentSender());
    }

    @PluginMethod
    public void composeEmail(PluginCall call) {
        try {
            String to = call.getString("to", "");
            String subject = call.getString("subject", "");
            String body = call.getString("body", "");
            Context c = getContext();
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("message/rfc822");
            i.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
            i.putExtra(Intent.EXTRA_SUBJECT, subject);
            i.putExtra(Intent.EXTRA_TEXT, body);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                Intent g = new Intent(i);
                g.setPackage("com.google.android.gm");
                c.startActivity(g);
            } catch (Exception noGmail) {
                try {
                    Intent s = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + to));
                    s.putExtra(Intent.EXTRA_SUBJECT, subject);
                    s.putExtra(Intent.EXTRA_TEXT, body);
                    s.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    c.startActivity(s);
                } catch (Exception e2) {
                    Intent ch = Intent.createChooser(i, "Send with email");
                    ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    c.startActivity(ch);
                }
            }
            call.resolve(new JSObject());
        } catch (Exception e) { call.reject("no email app: " + e.getMessage()); }
    }

    @PluginMethod
    public void closeApp(PluginCall call) {
        call.resolve(new JSObject());
        final Activity a = getActivity();
        a.runOnUiThread(() -> {
            try { a.finishAndRemoveTask(); } catch (Exception e) { a.finish(); }
            // End the process so nothing keeps running in the background (alarms are held by Android's AlarmManager).
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> Process.killProcess(Process.myPid()), 400);
        });
    }

    @PluginMethod
    public void getNight(PluginCall call) {
        JSObject r = new JSObject();
        r.put("dark", (getContext().getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES);
        call.resolve(r);
    }

    @PluginMethod
    public void shareText(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, call.getString("text", ""));
            Intent ch = Intent.createChooser(i, "Share profile");
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(ch);
            call.resolve(new JSObject());
        } catch (Exception e) { call.reject("share failed: " + e.getMessage()); }
    }

    @PluginMethod
    public void copyText(PluginCall call) {
        try {
            ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("MediMate profile link", call.getString("text", "")));
            call.resolve(new JSObject());
        } catch (Exception e) { call.reject("copy failed: " + e.getMessage()); }
    }

    @PluginMethod
    public void openUrl(PluginCall call) {
        try {
            String u = call.getString("url", "");
            if (!u.startsWith("https://")) { call.reject("bad url"); return; }
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve(new JSObject());
        } catch (Exception e) { call.reject("open failed: " + e.getMessage()); }
    }

    @PluginMethod
    public void getLaunchAlarm(PluginCall call) {
        try {
            Intent i = getActivity().getIntent();
            if (i == null || !i.getBooleanExtra("alarmLaunch", false)) { call.resolve(new JSObject()); return; }
            JSObject r = new JSObject();
            r.put("profileId", i.getLongExtra("profileId", -1));
            r.put("medicineId", i.getLongExtra("medicineId", -1));
            r.put("profileName", i.getStringExtra("profileName"));
            r.put("medicineName", i.getStringExtra("medicineName"));
            r.put("dose", i.getStringExtra("dose"));
            r.put("time", i.getStringExtra("time"));
            i.removeExtra("alarmLaunch");
            call.resolve(r);
        } catch (Exception e) { call.reject("alarm launch details unavailable"); }
    }

    @PluginMethod
    public void schedule(PluginCall call) {
        try {
            JSONArray arr = call.getArray("notifications");
            AlarmScheduler.scheduleAll(getContext(), arr == null ? new JSONArray() : arr);
            call.resolve(new JSObject());
        } catch (Exception e) {
            call.reject("schedule failed: " + e.getMessage());
        }
    }
}
