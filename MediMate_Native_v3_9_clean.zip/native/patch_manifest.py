import re,sys
p='android/app/src/main/AndroidManifest.xml'
s=open(p,encoding='utf-8').read()
perms=''.join('    <uses-permission android:name="android.permission.%s" />\n'%x for x in
  ['POST_NOTIFICATIONS','USE_FULL_SCREEN_INTENT','RECEIVE_BOOT_COMPLETED','WAKE_LOCK','VIBRATE','SCHEDULE_EXACT_ALARM','REQUEST_INSTALL_PACKAGES','REQUEST_IGNORE_BATTERY_OPTIMIZATIONS','RECORD_AUDIO','MODIFY_AUDIO_SETTINGS'])
s=s.replace('<application',perms+'    <queries><intent><action android:name="android.media.action.IMAGE_CAPTURE" /></intent></queries>\n'+'    <application',1)
s=s.replace('<application','<application android:usesCleartextTraffic="false"',1) if 'usesCleartextTraffic' not in s else s
s=s.replace('<activity','<activity android:showWhenLocked="true" android:turnScreenOn="true"',1)
recv='''
        <receiver android:name=".AlarmReceiver" android:exported="false" />
        <receiver android:name=".AlarmActionReceiver" android:exported="false" />
        <receiver android:name=".UpdateCheckReceiver" android:exported="false" />
        <receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
            </intent-filter>
        </receiver>
    </application>'''
s=s.replace('</application>',recv,1)
s=s.replace('</activity>','''            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="medimate" android:host="import" />
            </intent-filter>
        </activity>''',1)
open(p,'w',encoding='utf-8').write(s)
print(s)

import os,glob,shutil
os.makedirs('android/app/src/main/res/raw',exist_ok=True)
for f in glob.glob('native/raw/*.wav'): shutil.copy(f,'android/app/src/main/res/raw/')
print('ringtones copied:',len(glob.glob('android/app/src/main/res/raw/*.wav')))

import re as _re
g='android/app/build.gradle'
if os.path.exists(g):
    t=open(g).read()
    t=_re.sub(r'versionCode\s+\d+','versionCode 39',t,1)
    t=_re.sub(r'versionName\s+"[^"]*"','versionName "3.9"',t,1)
    open(g,'w').write(t)
    print('version set to 3.9 (code 39)')

# ---- Release signing (same key as earlier versions so in-app updates keep working) + hardening ----
if os.path.exists(g):
    t=open(g).read()
    if 'mmRelease' not in t:
        t+="""

// mmRelease: sign the RELEASE build with the project's existing key (identical signature to older builds)
android {
    signingConfigs {
        mmRelease {
            storeFile file(System.getProperty('user.home') + '/.android/debug.keystore')
            storePassword 'android'
            keyAlias 'androiddebugkey'
            keyPassword 'android'
            enableV1Signing true
            enableV2Signing true
            enableV3Signing true
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.mmRelease
            debuggable false
            minifyEnabled false
            shrinkResources false
        }
    }
    lint {
        checkReleaseBuilds false
        abortOnError false
    }
}
"""
        open(g,'w').write(t)
        print('release signing configured')

# ---- Copy assets/icon.png into Android launcher mipmap directories ----
if os.path.exists('assets/icon.png'):
    for density in ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']:
        d = f'android/app/src/main/res/mipmap-{density}'
        os.makedirs(d, exist_ok=True)
        shutil.copy('assets/icon.png', f'{d}/ic_launcher.png')
        shutil.copy('assets/icon.png', f'{d}/ic_launcher_round.png')
    print('launcher icons updated from assets/icon.png')
