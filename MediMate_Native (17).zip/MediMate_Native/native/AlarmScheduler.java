package com.abhi.medimate;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

public class AlarmScheduler {
    static final String PREFS = "mm_alarms";
    static final String KEY = "items";

    static Intent baseIntent(Context c, int id) {
        Intent in = new Intent(c, AlarmReceiver.class);
        in.setAction("com.abhi.medimate.ALARM." + id);
        return in;
    }

    static void cancelAll(Context c, AlarmManager am) {
        try {
            SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String old = sp.getString(KEY, "[]");
            JSONArray arr = new JSONArray(old);
            for (int i = 0; i < arr.length(); i++) {
                int id = arr.getJSONObject(i).getInt("id");
                PendingIntent pi = PendingIntent.getBroadcast(c, id, baseIntent(c, id),
                        PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                if (pi != null) { am.cancel(pi); pi.cancel(); }
            }
        } catch (Exception ignored) { }
    }

    public static void scheduleAll(Context c, JSONArray items) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        JSONArray kept = new JSONArray();
        try {
            cancelAll(c, am);
            long now = System.currentTimeMillis();
            PendingIntent show = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            for (int i = 0; i < items.length(); i++) {
                try {
                    JSONObject o = items.getJSONObject(i);
                    long at = o.getLong("at");
                    if (at <= now) continue;
                    int id = o.getInt("id");
                    Intent in = baseIntent(c, id);
                    in.putExtra("id", id);
                    in.putExtra("title", o.optString("title", "Medicine time"));
                    in.putExtra("body", o.optString("body", ""));
                    PendingIntent pi = PendingIntent.getBroadcast(c, id, in,
                            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                    am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pi);
                    kept.put(o);
                } catch (Exception ignored) { }   // skip this one alarm, keep scheduling the others
            }
        } catch (Exception ignored) {
        } finally {
            // always record what was really scheduled, so the next run can cancel it (no orphaned alarms)
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, kept.toString()).apply();
        }
    }
}
