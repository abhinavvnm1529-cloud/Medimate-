MediMate AI service (Cloudflare Worker)

1. Cloudflare dashboard > Workers & Pages > open your existing worker > Edit code.
2. Replace the code with worker.js from this folder and Deploy.
3. Settings > Variables and Secrets:
     GEMINI_API_KEY = your key from Google AI Studio   (type: Secret)
     APP_TOKEN      = the access code you type in the app (type: Secret)
     GEMINI_MODEL   = optional; leave empty to use gemini-3.8-flash and auto-recover.
4. Test:  curl -X POST <worker-url> -H "X-App-Token: <code>" -H "Content-Type: application/json" -d '{"mime":"image/png","data":"<base64>"}'
