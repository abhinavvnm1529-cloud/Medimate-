// MediMate AI proxy for Cloudflare Workers (v3.6).
// Routes:  POST /        prescription scan (unchanged)
//          POST /chat    MedEx AI chat    ("cosmos" = Gemini, most accurate / slower;  "oxygen" = Groq, fastest)
//          POST /stt     voice to text for the MedEx microphone button
// Secrets:   GEMINI_API_KEY (Google AI Studio), APP_TOKEN (access code typed in the app), OXYGEN_KEY (Groq key)
// Variables (optional, names only, no code change needed to switch models):
//            GEMINI_MODEL   scan model          COSMOS_MODEL  MedEx Cosmos model (default gemini-3.8-flash; put a Pro model here for best accuracy)
//            OXYGEN_MODEL   MedEx Oxygen model (default llama-3.3-70b-versatile)    OXYGEN_URL  (default Groq's OpenAI-style chat address)
//            STT_MODEL      voice model (default whisper-large-v3-turbo)            STT_URL     (default Groq's transcription address)
// Keys never reach the phone: the app only sends "cosmos" or "oxygen" and this worker picks the key.
//
// Why this fixes "AI service error (404)": Google retires old Gemini models, and calling a retired
// model returns 404. This worker uses a current model and, if it ever gets a 404 again, looks up
// the newest available Flash model by itself and retries once.

const API = 'https://generativelanguage.googleapis.com/v1beta';
const DEFAULT_MODEL = 'gemini-3.5-flash-lite';   // fast: answers in seconds
const FALLBACK_MODEL = 'gemini-3.8-flash';       // stronger: only used if the fast model finds nothing
let discovered = null; // remembered until the worker restarts

const promptFor = (today) => `You read a photo or PDF of a medicine prescription or label and list every medicine.
Today's date is ${today}. Dates in India are written day/month/year.
Rules:
- Read carefully. The writing may be very messy handwriting. Give your best reading of every word, using common medicine names, strengths and abbreviations (OD, BD, TDS, 1-0-1, before/after food) for context. Never invent a medicine that is not on the page.
- If the same medicine appears for different date ranges or with different timings, return one entry for each date range.
- "startDate" and "endDate": the first and last day of that course as YYYY-MM-DD, taken from the written dates. If a year is missing, use the year that puts the dates closest to today. Leave both empty when no dates are written for that medicine.
- "days": whole number of days only if a duration is written without dates, otherwise 0.
- "dose": the strength and how much to take each time, for example "500 mg, 1 tablet" or "5 ml, twice a day". Always fill this in when any strength or quantity is written anywhere for that medicine.
- "times": 24-hour HH:MM. Morning 08:00, afternoon 14:00, evening 18:00, night 21:00. If only a frequency is written (for example "twice a day"), use evenly spaced daytime times. The person will check them.
- "notes": short extra instructions (for example "after food").
- If you are unsure about a name or dose, still give your best guess and add "unclear - please check" to notes.
- If nothing readable is found, return an empty list.`;

const SCHEMA = {
  type: 'OBJECT',
  properties: {
    medicines: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          name: { type: 'STRING' }, dose: { type: 'STRING' }, notes: { type: 'STRING' }, startDate: { type: 'STRING' }, endDate: { type: 'STRING' },
          times: { type: 'ARRAY', items: { type: 'STRING' } }, days: { type: 'INTEGER' },
        },
        required: ['name'],
      },
    },
  },
  required: ['medicines'],
};

const ORIGINS = ['https://localhost', 'capacitor://localhost', 'http://localhost'];
const hits = new Map();
let CORS = {};
const safeEq = (a, b) => { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; };
const reply = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...CORS } });

const version = (name) => {
  const m = String(name).match(/gemini-(\d+)(?:\.(\d+))?-flash$/);
  return m ? Number(m[1]) * 1000 + Number(m[2] || 0) : 0;
};

async function findModel(key) {
  const r = await fetch(`${API}/models?pageSize=200`, { headers: { 'x-goog-api-key': key } });
  if (!r.ok) return null;
  const { models = [] } = await r.json();
  const ok = models
    .filter((m) => (m.supportedGenerationMethods || []).includes('generateContent') && version(m.name) > 0)
    .sort((a, b) => version(b.name) - version(a.name));
  return ok.length ? ok[0].name.replace(/^models\//, '') : null;
}

const callGemini = (model, key, body, fast = true) => {
  const gc = { ...body.generationConfig };
  if (fast && /^gemini-3\.8/.test(model)) gc.thinkingConfig = { thinkingLevel: 'low' };   // much faster, still reads handwriting
  return fetch(`${API}/models/${model}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
    body: JSON.stringify({ ...body, generationConfig: gc }),
    signal: AbortSignal.timeout(40000),
  });
};

function cleanTime(t) {
  const m = String(t || '').trim().match(/^(\d{1,2}):(\d{2})$/);
  if (!m || +m[1] > 23 || +m[2] > 59) return '';
  return m[1].padStart(2, '0') + ':' + m[2];
}

const cleanDate = (d) => /^\d{4}-\d\d-\d\d$/.test(String(d || '')) && !isNaN(new Date(d + 'T00:00:00Z')) ? d : '';

function clean(list) {
  return (Array.isArray(list) ? list : [])
    .filter((m) => m && typeof m.name === 'string' && m.name.trim())
    .slice(0, 30)
    .map((m) => ({
      name: m.name.trim().slice(0, 80),
      dose: String(m.dose || '').trim().slice(0, 160),
      notes: String(m.notes || '').trim().slice(0, 200),
      times: [...new Set((Array.isArray(m.times) ? m.times : []).map(cleanTime).filter(Boolean))],
      startDate: cleanDate(m.startDate),
      endDate: cleanDate(m.endDate) >= cleanDate(m.startDate) ? cleanDate(m.endDate) : '',
      days: Number.isInteger(m.days) && m.days > 0 && m.days <= 365 ? m.days : 0,
    }));
}


// ---------------- MedEx (v3.7) ----------------
const GROQ_CHAT = 'https://api.groq.com/openai/v1/chat/completions';
const GROQ_STT = 'https://api.groq.com/openai/v1/audio/transcriptions';

const chatSystem = (schedule) => `You are MedEx, the medicine assistant inside the MediMate reminder app.
You are given the person's medicine schedule, what they have taken today, and optional user-stated memory notes (JSON at the end). Use relevant notes as context, but treat them as unverified self-reports, never as confirmed diagnoses. Do not infer conditions, allergies or phobias. Use the schedule and relevant notes to answer questions like "can I take my medicine late?", "what is next?" or "did I miss anything?".
Rules:
- Be concise and kind: 2 to 6 short sentences, or a short list. Plain language. Reply in the language the person writes in.
- Base answers on well-established guidance (WHO, national drug regulators, patient information leaflets). Say plainly when the answer depends on the specific medicine or the person.
- Late or missed doses: work out how late it is from "now" and the scheduled time. Give the usual general guidance for that type of medicine only if you are confident, and never suggest doubling a dose unless the leaflet clearly says so. If the medicine is time-critical or high-risk (for example insulin, blood thinners, anti-seizure, heart rhythm or blood pressure medicines, immunosuppressants, thyroid, chemotherapy, opioids, controlled drugs, or an antibiotic course) or you are not sure, say to ask the doctor or pharmacist before taking it.
- Never tell the person to start, stop, skip, increase, decrease or swap a medicine, and never suggest a dose that is not on their schedule. Do not diagnose.
- Severe symptoms (trouble breathing, chest pain, fainting, seizure, swelling of the face or lips, suspected overdose or poisoning, heavy bleeding): tell them to call emergency services (112 in India) or a doctor immediately.
- If ageYears is 18 or less, remind them to ask a parent or guardian.
- If you are not sure, or it involves a chronic or complex condition, say you are not certain and suggest the doctor or pharmacist. Never invent facts, doses or studies.
- You only know what is in the schedule data. If a medicine is not listed, say you cannot see it.
- Add a short "please check with your doctor or pharmacist" line when the answer is about timing or doses, but do not repeat a long disclaimer every time.
Schedule data:
${JSON.stringify(schedule || {}).slice(0, 6000)}`;

const SAFETY = ['HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT']
  .map((category) => ({ category, threshold: 'BLOCK_ONLY_HIGH' }));

async function askGemini(env, model, system, msgs, file) {
  const contents = msgs.map((m) => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.text }] }));
  if (file) {
    const last = contents[contents.length - 1];
    if (last && last.role === 'user') last.parts.push({ inlineData: { mimeType: file.mime, data: file.data } });
  }
  const body = { systemInstruction: { parts: [{ text: system }] }, contents, safetySettings: SAFETY, generationConfig: { temperature: 0.3, maxOutputTokens: 1400 } };
  const call = (m) => fetch(`${API}/models/${m}:generateContent`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY },
    body: JSON.stringify(body), signal: AbortSignal.timeout(55000),
  });
  let r = await call(model);
  if (r.status === 404) {                       // model name retired: look up the newest Flash model once
    const found = await findModel(env.GEMINI_API_KEY);
    if (found && found !== model) r = await call(found);
  }
  if (!r.ok) return { error: r.status };
  const out = await r.json();
  if (out.promptFeedback && out.promptFeedback.blockReason) return { text: 'I cannot answer that one. Please ask your doctor or pharmacist.' };
  const text = ((out.candidates || [])[0]?.content?.parts || []).map((p) => p.text || '').join('').trim();
  return text ? { text } : { error: 502 };
}

async function askOxygen(env, system, msgs) {
  const r = await fetch(env.OXYGEN_URL || GROQ_CHAT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${env.OXYGEN_KEY}` },
    body: JSON.stringify({
      model: env.OXYGEN_MODEL || 'llama-3.3-70b-versatile', temperature: 0.3, max_tokens: 900,
      messages: [{ role: 'system', content: system }, ...msgs.map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', content: m.text }))],
    }),
    signal: AbortSignal.timeout(30000),
  });
  if (!r.ok) return { error: r.status };
  const out = await r.json();
  const text = String(out.choices?.[0]?.message?.content || '').trim();
  return text ? { text } : { error: 502 };
}

function limited(key, max) {
  const now = Date.now(), recent = (hits.get(key) || []).filter((t) => now - t < 600000);
  if (recent.length >= max) return true;
  recent.push(now); hits.set(key, recent); return false;
}

async function chat(request, env) {
  const ip = request.headers.get('CF-Connecting-IP') || 'x';
  if (limited('chat:' + ip, 60)) return reply({ error: 'Too many questions. Try again in a few minutes.' }, 429);
  let input;
  try { input = await request.json(); } catch { return reply({ error: 'Bad request.' }, 400); }
  const msgs = (Array.isArray(input.messages) ? input.messages : [])
    .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.text === 'string' && m.text.trim())
    .slice(-14).map((m) => ({ role: m.role, text: m.text.slice(0, 4000) }));
  if (!msgs.length || msgs[msgs.length - 1].role !== 'user') return reply({ error: 'Send a question.' }, 400);
  let file = null;
  if (input.file) {
    if (!['image/jpeg', 'image/png', 'image/webp', 'application/pdf'].includes(input.file.mime) || typeof input.file.data !== 'string' || input.file.data.length > 18 * 1024 * 1024)
      return reply({ error: 'That file type or size is not supported.' }, 400);
    file = input.file;
  }
  const system = chatSystem(input.schedule);
  const cosmosModel = env.COSMOS_MODEL || 'gemini-3.8-flash';
  let model = input.model === 'cosmos' ? 'cosmos' : 'oxygen';
  if (file) model = 'cosmos';                    // only Gemini reads files
  try {
    let res;
    if (model === 'oxygen') {
      if (env.OXYGEN_KEY) res = await askOxygen(env, system, msgs);
      if (!res || res.error) {                   // Oxygen missing or busy: fall back to the fast Gemini model so the person still gets an answer
        if (!env.GEMINI_API_KEY) return reply({ error: 'Oxygen is not set up on the service yet.' }, 500);
        res = await askGemini(env, env.GEMINI_MODEL || DEFAULT_MODEL, system, msgs, null);
        if (!res.error) return reply({ reply: res.text, via: 'cosmos' });
      }
    } else {
      if (!env.GEMINI_API_KEY) return reply({ error: 'Cosmos is not set up on the service yet.' }, 500);
      res = await askGemini(env, cosmosModel, system, msgs, file);
    }
    if (res.error) return reply({ error: `AI service error (${res.error})` }, res.error === 429 ? 429 : 502);
    return reply({ reply: res.text, via: model });
  } catch (e) {
    return reply({ error: 'The AI service took too long or could not be reached.' }, 502);
  }
}

const AUDIO = ['audio/webm', 'audio/mp4', 'audio/ogg', 'audio/mpeg', 'audio/wav', 'audio/x-wav', 'audio/aac', 'audio/3gpp'];
async function stt(request, env) {
  const ip = request.headers.get('CF-Connecting-IP') || 'x';
  if (limited('stt:' + ip, 60)) return reply({ error: 'Too many requests. Try again in a few minutes.' }, 429);
  let input;
  try { input = await request.json(); } catch { return reply({ error: 'Bad request.' }, 400); }
  const mime = input && input.mime, data = input && input.data;
  if (!AUDIO.includes(mime) || typeof data !== 'string' || !data || data.length > 6 * 1024 * 1024) return reply({ error: 'Unsupported audio.' }, 400);
  try {
    if (env.OXYGEN_KEY) {
      const bytes = Uint8Array.from(atob(data), (c) => c.charCodeAt(0));
      const ext = mime.split('/')[1].replace('x-', '').replace('mpeg', 'mp3');
      const form = new FormData();
      form.append('file', new Blob([bytes], { type: mime }), `voice.${ext}`);
      form.append('model', env.STT_MODEL || 'whisper-large-v3-turbo');
      form.append('response_format', 'json');
      const r = await fetch(env.STT_URL || GROQ_STT, { method: 'POST', headers: { Authorization: `Bearer ${env.OXYGEN_KEY}` }, body: form, signal: AbortSignal.timeout(30000) });
      if (r.ok) { const o = await r.json(); return reply({ text: String(o.text || '').trim() }); }
    }
    if (!env.GEMINI_API_KEY) return reply({ error: 'Voice is not set up on the service yet.' }, 500);
    const body = { contents: [{ parts: [{ text: 'Transcribe this audio exactly as spoken, in the language spoken. Output only the words, nothing else.' }, { inlineData: { mimeType: mime, data } }] }], generationConfig: { temperature: 0 } };
    const r2 = await fetch(`${API}/models/${env.GEMINI_MODEL || DEFAULT_MODEL}:generateContent`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY }, body: JSON.stringify(body), signal: AbortSignal.timeout(30000) });
    if (!r2.ok) return reply({ error: `AI service error (${r2.status})` }, 502);
    const o2 = await r2.json();
    return reply({ text: ((o2.candidates || [])[0]?.content?.parts || []).map((p) => p.text || '').join('').trim() });
  } catch (e) {
    return reply({ error: 'Could not convert the voice.' }, 502);
  }
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    CORS = { 'Access-Control-Allow-Origin': ORIGINS.includes(origin) ? origin : 'null', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, X-App-Token', 'Vary': 'Origin' };
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    if (request.method !== 'POST') return reply({ error: 'Use POST.' }, 405);
    if (!env.APP_TOKEN || !safeEq(request.headers.get('X-App-Token') || '', env.APP_TOKEN))
      return reply({ error: 'Wrong access code.' }, 401);
    const path = new URL(request.url).pathname.replace(/\/+$/, '');
    if (path.endsWith('/chat')) return chat(request, env);
    if (path.endsWith('/stt')) return stt(request, env);
    const ip = request.headers.get('CF-Connecting-IP') || 'x', now = Date.now();
    const recent = (hits.get('scan:' + ip) || []).filter((t) => now - t < 600000);
    if (recent.length >= 10) return reply({ error: 'Too many scans. Try again in a few minutes.' }, 429);
    recent.push(now); hits.set('scan:' + ip, recent);
    if (!env.GEMINI_API_KEY) return reply({ error: 'The service has no Gemini key set.' }, 500);

    let input;
    try { input = await request.json(); } catch { return reply({ error: 'Bad request.' }, 400); }
    const mime = input && input.mime, data = input && input.data;
    if (!['image/jpeg', 'image/png', 'image/webp', 'application/pdf'].includes(mime) || typeof data !== 'string' || !data)
      return reply({ error: 'Send a JPG, PNG, WebP or PDF.' }, 400);
    if (data.length > 18 * 1024 * 1024) return reply({ error: 'The file is too large.' }, 413);

    const body = {
      contents: [{ parts: [{ text: promptFor(new Date().toISOString().slice(0, 10)) }, { inlineData: { mimeType: mime, data } }] }],
      generationConfig: { responseMimeType: 'application/json', responseSchema: SCHEMA },
    };

    const ask = async (model, fast) => {
      let r = await callGemini(model, env.GEMINI_API_KEY, body, fast);
      if (r.status === 400 && fast) r = await callGemini(model, env.GEMINI_API_KEY, body, false);   // if the speed setting is refused, retry plainly
      if (r.status === 404) {                       // model retired: find the newest one and retry once
        const found = await findModel(env.GEMINI_API_KEY);
        if (found && found !== model) { discovered = found; r = await callGemini(found, env.GEMINI_API_KEY, body); }
      }
      return r;
    };
    const read = async (r) => {
      const out = await r.json();
      if (out.promptFeedback && out.promptFeedback.blockReason) return { blocked: true, meds: [] };
      const text = ((out.candidates || [])[0]?.content?.parts || []).map((p) => p.text || '').join('');
      let parsed = {};
      try { parsed = JSON.parse(text); } catch { /* fall through to empty list */ }
      return { meds: clean(parsed.medicines) };
    };

    try {
      const primary = env.GEMINI_MODEL || discovered || DEFAULT_MODEL;
      const r = await ask(primary, true);
      if (!r.ok) return reply({ error: `AI service error (${r.status})` }, r.status === 429 ? 429 : 502);
      let res = await read(r);
      if (res.blocked) return reply({ error: 'The AI could not read this file.' }, 422);
      if (!res.meds.length && primary !== FALLBACK_MODEL) {      // nothing found: try the stronger model once
        try {
          const r2 = await callGemini(FALLBACK_MODEL, env.GEMINI_API_KEY, body, true);
          if (r2.ok) { const res2 = await read(r2); if (res2.meds.length) res = res2; }
        } catch { /* keep the first result */ }
      }
      return reply({ medicines: res.meds });
    } catch (e) {
      return reply({ error: 'The AI service took too long or could not be reached.' }, 502);
    }
  },
};
