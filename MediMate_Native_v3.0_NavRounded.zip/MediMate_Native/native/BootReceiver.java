package com.abhi.medimate;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONArray;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        try {
            String s = c.getSharedPreferences(AlarmScheduler.PREFS, Context.MODE_PRIVATE)
                    .getString(AlarmScheduler.KEY, "[]");
            AlarmScheduler.scheduleAll(c, new JSONArray(s));
        } catch (Exception ignored) { }
        try {
            if (Intent.ACTION_MY_PACKAGE_REPLACED.equals(in.getAction())) {
                Intent open = new Intent(c, MainActivity.class);
                open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(open);
            }
        } catch (Exception ignored) { }
    }
}
