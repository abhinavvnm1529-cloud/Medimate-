MediMate native project (Capacitor + custom MediMateAlarm plugin).

Upload this ZIP to the target GitHub repository. It includes a GitHub Actions workflow to build the APK on tags (v3.0+) and manually from Actions. Tag v3.0 to publish the APK asset for the in-app updater.

worker/ = AI timetable service (Cloudflare Worker). Redeploy worker/worker.js if the AI service endpoint needs updates.

Android alarm behavior depends on device permissions and OEM restrictions. Full-screen intents may require enabling the app's full-screen alarm permission and notification permissions in Android settings. The app's installer update flow downloads in-app, but Android's system confirmation cannot be silently bypassed.

Profile, medicine schedule and history data remain in local WebView storage. Do not uninstall or clear app data when updating. Backups are unencrypted; keep them private.


Release version: 3.0.0 (20 November 2026). See CHANGELOG_3.0.txt for updates.
