import re,sys
p='android/app/src/main/AndroidManifest.xml'
s=open(p,encoding='utf-8').read()
perms=''.join('    <uses-permission android:name="android.permission.%s" />\n'%x for x in
  ['POST_NOTIFICATIONS','USE_FULL_SCREEN_INTENT','RECEIVE_BOOT_COMPLETED','WAKE_LOCK','VIBRATE','SCHEDULE_EXACT_ALARM'])
s=s.replace('<application',perms+'    <queries><intent><action android:name="android.media.action.IMAGE_CAPTURE" /></intent></queries>\n'+'    <application',1)
s=s.replace('<activity','<activity android:showWhenLocked="true" android:turnScreenOn="true"',1)
recv='''
        <receiver android:name=".AlarmReceiver" android:exported="false" />
        <receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
            </intent-filter>
        </receiver>
    </application>'''
s=s.replace('</application>',recv,1)
open(p,'w',encoding='utf-8').write(s)
print(s)

import os,glob,shutil
os.makedirs('android/app/src/main/res/raw',exist_ok=True)
for f in glob.glob('native/raw/*.wav'): shutil.copy(f,'android/app/src/main/res/raw/')
print('ringtones copied:',len(glob.glob('android/app/src/main/res/raw/*.wav')))
