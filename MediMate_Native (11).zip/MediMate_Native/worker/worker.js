// MediMate AI proxy for Cloudflare Workers.
// Secrets to set:  GEMINI_API_KEY  (from Google AI Studio)  and  APP_TOKEN  (the access code typed in the app)
// Optional variable: GEMINI_MODEL  (leave empty to use the default below)
//
// Why this fixes "AI service error (404)": Google retires old Gemini models, and calling a retired
// model returns 404. This worker uses a current model and, if it ever gets a 404 again, looks up
// the newest available Flash model by itself and retries once.

const API = 'https://generativelanguage.googleapis.com/v1beta';
const DEFAULT_MODEL = 'gemini-3.8-flash';
let discovered = null; // remembered until the worker restarts

const promptFor = (today) => `You read a photo or PDF of a medicine prescription or label and list every medicine.
Today's date is ${today}. Dates in India are written day/month/year.
Rules:
- Copy only what is written. Never invent a medicine, dose, date or number.
- If the same medicine appears for different date ranges or with different timings, return one entry for each date range.
- "startDate" and "endDate": the first and last day of that course as YYYY-MM-DD, taken from the written dates. If a year is missing, use the year that puts the dates closest to today. Leave both empty when no dates are written for that medicine.
- "days": whole number of days only if a duration is written without dates, otherwise 0.
- "dose": the strength and how much to take each time, for example "500 mg, 1 tablet" or "5 ml, twice a day". Always fill this in when any strength or quantity is written anywhere for that medicine.
- "times": 24-hour HH:MM. Morning 08:00, afternoon 14:00, evening 18:00, night 21:00. If only a frequency is written (for example "twice a day"), use evenly spaced daytime times. The person will check them.
- "notes": short extra instructions (for example "after food").
- If nothing readable is found, return an empty list.`;

const SCHEMA = {
  type: 'OBJECT',
  properties: {
    medicines: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          name: { type: 'STRING' }, dose: { type: 'STRING' }, notes: { type: 'STRING' }, startDate: { type: 'STRING' }, endDate: { type: 'STRING' },
          times: { type: 'ARRAY', items: { type: 'STRING' } }, days: { type: 'INTEGER' },
        },
        required: ['name'],
      },
    },
  },
  required: ['medicines'],
};

const ORIGINS = ['https://localhost', 'capacitor://localhost', 'http://localhost'];
const hits = new Map();
let CORS = {};
const safeEq = (a, b) => { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; };
const reply = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...CORS } });

const version = (name) => {
  const m = String(name).match(/gemini-(\d+)(?:\.(\d+))?-flash$/);
  return m ? Number(m[1]) * 1000 + Number(m[2] || 0) : 0;
};

async function findModel(key) {
  const r = await fetch(`${API}/models?pageSize=200`, { headers: { 'x-goog-api-key': key } });
  if (!r.ok) return null;
  const { models = [] } = await r.json();
  const ok = models
    .filter((m) => (m.supportedGenerationMethods || []).includes('generateContent') && version(m.name) > 0)
    .sort((a, b) => version(b.name) - version(a.name));
  return ok.length ? ok[0].name.replace(/^models\//, '') : null;
}

const callGemini = (model, key, body) =>
  fetch(`${API}/models/${model}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
    body: JSON.stringify(body),
  });

function cleanTime(t) {
  const m = String(t || '').trim().match(/^(\d{1,2}):(\d{2})$/);
  if (!m || +m[1] > 23 || +m[2] > 59) return '';
  return m[1].padStart(2, '0') + ':' + m[2];
}

const cleanDate = (d) => /^\d{4}-\d\d-\d\d$/.test(String(d || '')) && !isNaN(new Date(d + 'T00:00:00Z')) ? d : '';

function clean(list) {
  return (Array.isArray(list) ? list : [])
    .filter((m) => m && typeof m.name === 'string' && m.name.trim())
    .slice(0, 30)
    .map((m) => ({
      name: m.name.trim().slice(0, 80),
      dose: String(m.dose || '').trim().slice(0, 160),
      notes: String(m.notes || '').trim().slice(0, 200),
      times: [...new Set((Array.isArray(m.times) ? m.times : []).map(cleanTime).filter(Boolean))],
      startDate: cleanDate(m.startDate),
      endDate: cleanDate(m.endDate) >= cleanDate(m.startDate) ? cleanDate(m.endDate) : '',
      days: Number.isInteger(m.days) && m.days > 0 && m.days <= 365 ? m.days : 0,
    }));
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    CORS = { 'Access-Control-Allow-Origin': ORIGINS.includes(origin) ? origin : 'null', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, X-App-Token', 'Vary': 'Origin' };
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    if (request.method !== 'POST') return reply({ error: 'Use POST.' }, 405);
    if (!env.APP_TOKEN || !safeEq(request.headers.get('X-App-Token') || '', env.APP_TOKEN))
      return reply({ error: 'Wrong access code.' }, 401);
    const ip = request.headers.get('CF-Connecting-IP') || 'x', now = Date.now();
    const recent = (hits.get(ip) || []).filter((t) => now - t < 600000);
    if (recent.length >= 10) return reply({ error: 'Too many scans. Try again in a few minutes.' }, 429);
    recent.push(now); hits.set(ip, recent);
    if (!env.GEMINI_API_KEY) return reply({ error: 'The service has no Gemini key set.' }, 500);

    let input;
    try { input = await request.json(); } catch { return reply({ error: 'Bad request.' }, 400); }
    const mime = input && input.mime, data = input && input.data;
    if (!['image/jpeg', 'image/png', 'image/webp', 'application/pdf'].includes(mime) || typeof data !== 'string' || !data)
      return reply({ error: 'Send a JPG, PNG, WebP or PDF.' }, 400);
    if (data.length > 18 * 1024 * 1024) return reply({ error: 'The file is too large.' }, 413);

    const body = {
      contents: [{ parts: [{ text: promptFor(new Date().toISOString().slice(0, 10)) }, { inlineData: { mimeType: mime, data } }] }],
      generationConfig: { temperature: 0, responseMimeType: 'application/json', responseSchema: SCHEMA },
    };

    try {
      let model = env.GEMINI_MODEL || discovered || DEFAULT_MODEL;
      let r = await callGemini(model, env.GEMINI_API_KEY, body);
      if (r.status === 404) {                       // model retired: find the newest one and retry once
        const found = await findModel(env.GEMINI_API_KEY);
        if (found && found !== model) {
          discovered = found;
          r = await callGemini(found, env.GEMINI_API_KEY, body);
        }
      }
      if (!r.ok) return reply({ error: `AI service error (${r.status})` }, r.status === 429 ? 429 : 502);

      const out = await r.json();
      if (out.promptFeedback && out.promptFeedback.blockReason)
        return reply({ error: 'The AI could not read this file.' }, 422);
      const text = ((out.candidates || [])[0]?.content?.parts || []).map((p) => p.text || '').join('');
      let parsed = {};
      try { parsed = JSON.parse(text); } catch { /* fall through to empty list */ }
      return reply({ medicines: clean(parsed.medicines) });
    } catch (e) {
      return reply({ error: 'The AI service could not be reached.' }, 502);
    }
  },
};
