package com.abhi.medimate;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    /** true while MediMate was opened ONLY by a ringing alarm (phone locked / app was closed), so it can close itself afterwards */
    static volatile boolean alarmOnly = false;
    static volatile boolean started = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(MediMateAlarmPlugin.class);
        super.onCreate(savedInstanceState);
        alarmOnly = getIntent() != null && getIntent().getBooleanExtra("alarmLaunch", false);

        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }

        // Same behaviour on every Android version: the window is edge-to-edge and the app
        // pads its own content so it always sits between the status bar and the navigation bar.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        if (Build.VERSION.SDK_INT < 35) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        getWindow().getDecorView().setBackgroundColor(Color.parseColor(night ? "#1b1c1f" : "#f8fafd"));
        WindowInsetsControllerCompat ctl = new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
        ctl.setAppearanceLightStatusBars(!night);
        ctl.setAppearanceLightNavigationBars(!night);

        final View root = findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            int types = WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout();
            if (Build.VERSION.SDK_INT >= 30) types |= WindowInsetsCompat.Type.ime();
            Insets b = insets.getInsets(types);
            v.setPadding(b.left, b.top, b.right, b.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        ViewCompat.requestApplyInsets(root);
    }

    @Override
    protected void onStart() { super.onStart(); started = true; }

    @Override
    protected void onStop() { super.onStop(); started = false; }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null) {
            setIntent(intent);
            boolean alarm = intent.getBooleanExtra("alarmLaunch", false);
            // an alarm that arrives while the app is on screen must never close it
            if (alarm) alarmOnly = !started; else alarmOnly = false;
            if (alarm) {
                try {
                    String payload = new org.json.JSONObject()
                        .put("profileId", intent.getLongExtra("profileId", -1))
                        .put("medicineId", intent.getLongExtra("medicineId", -1))
                        .put("profileName", intent.getStringExtra("profileName"))
                        .put("medicineName", intent.getStringExtra("medicineName"))
                        .put("dose", intent.getStringExtra("dose"))
                        .put("time", intent.getStringExtra("time")).toString();
                    getBridge().triggerWindowJSEvent("nativeAlarm", payload);
                } catch (Exception ignored) { }
            }
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        try { getBridge().triggerWindowJSEvent("systemTheme", "{}"); } catch (Exception ignored) { }
    }
}
