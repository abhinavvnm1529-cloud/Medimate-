
const APP="MediMate";
const $=id=>document.getElementById(id);
const pad=n=>String(n).padStart(2,'0');
const dkey=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const parseD=s=>new Date(s+'T00:00:00');
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=t=>{let [h,m]=t.split(':').map(Number);const ap=h>=12?'PM':'AM';h=h%12||12;return h+':'+pad(m)+' '+ap};
const fmtD=d=>d.toLocaleDateString('en',{day:'numeric',month:'short'});
const midnight=()=>{const d=new Date();d.setHours(0,0,0,0);return d};
const addDays=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x};
const toMin=t=>{const [h,m]=t.split(':').map(Number);return h*60+m};
const fromMin=n=>{n=Math.max(0,Math.min(1439,n));return pad(Math.floor(n/60))+':'+pad(n%60)};
let today=midnight();

$('appname').textContent=APP;

// ---------- storage ----------
const DEF_ROUTINE={breakfast:'08:00',lunch:'13:00',evening:'17:30',dinner:'20:00',bedtime:'22:00'};
const MISS_MIN=90;            // minutes after its time a dose counts as "missed"
const KEY='mm_store_v2';
const TERMS_VERSION=5;
let store={profiles:[],current:null}, storageOk=true;
const fired={};let needLock=0;
const ini=n=>([...String(n).trim()][0]||'?').toUpperCase();
function norm(p){
  p.routine=Object.assign({},DEF_ROUTINE,p.routine||{});p.meds=Array.isArray(p.meds)?p.meds:[];p.taken=p.taken||{};p.takenAt=p.takenAt&&typeof p.takenAt==='object'?p.takenAt:{};p.prn=Array.isArray(p.prn)?p.prn:[];p.snooze=p.snooze||{};p.pin=p.pin||'';p.dob=p.dob||'';p.agreed=p.agreed||0;p.termsVersion=p.termsVersion||0;p.best=p.best||0;
  p.alertVolume=Math.min(100,Math.max(20,Number(p.alertVolume)||90));
  if(typeof p.voiceAlerts!=='boolean')p.voiceAlerts=true;
  p.email=typeof p.email==='string'?p.email:'';
  p.nextId=p.nextId||(Math.max(0,...p.meds.map(m=>m.id),...p.prn.map(m=>m.id))+1);
  // Keep historical taken marks: they are needed to calculate a truthful
  // all-time longest streak. Snooze entries are temporary and can be cleaned up.
  p.bestStreak=Math.max(0,Number(p.bestStreak)||0,Number(p.best)||0);
  Object.keys(p.snooze).forEach(k=>{if(p.snooze[k]<Date.now()-864e5)delete p.snooze[k]});
  return p}
try{const s=localStorage.getItem(KEY);if(s){const o=JSON.parse(s);if(o&&Array.isArray(o.profiles))store=o}}catch(e){storageOk=false}
try{localStorage.setItem('mm_test','1');localStorage.removeItem('mm_test')}catch(e){storageOk=false}
store.profiles.forEach(norm);store.current=null;
try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist().catch(()=>{})}catch(e){}
function save(){scheduleNative();try{localStorage.setItem(KEY,JSON.stringify(store));return true}catch(e){storageOk=false;$('warn').style.display='block';return false}}
const P=()=>store.profiles.find(p=>p.id===store.current);

let editing=null, calY=today.getFullYear(), calM=today.getMonth(), selDay=new Date(today), delArmed=false, scanning=false,
    restoreArmed=false, pinFor=null, forgot=false, pinMode='open';

function activeOn(m,d){const diff=Math.round((d-parseD(m.start))/864e5);return diff>=0&&diff<m.days&&diff%(m.every||1)===0}
const medsOf=(p,d)=>p.meds.filter(m=>activeOn(m,d)&&(S.tasksEnabled||m.kind!=='task')).sort((a,b)=>a.time.localeCompare(b.time));
const medsOn=d=>medsOf(P(),d);
const isTaken=(m,d)=>!!P().taken[dkey(d)+'_'+m.id];
const nowHM=ts=>{const d=ts?new Date(ts):new Date();return pad(d.getHours())+':'+pad(d.getMinutes())};
// record a dose as taken together with the EXACT time it was taken (shown in History)
function markTaken(p,dk,mid,ts){const k=dk+'_'+mid;p.taken[k]=true;p.takenAt=p.takenAt||{};p.takenAt[k]=nowHM(ts)}
function unmarkTaken(p,k){delete p.taken[k];if(p.takenAt)delete p.takenAt[k]}

function toast(msg,act,ms){
  const t=$('toast');t.innerHTML='<span>'+esc(msg)+'</span>'+(act?'<button id="t-act">'+esc(act.label)+'</button>':'');
  t.style.display='flex';if(act)$('t-act').onclick=()=>{act.fn();t.style.display='none'};
  clearTimeout(t._x);t._x=setTimeout(()=>t.style.display='none',ms||(act?6000:4500));
}

// ---------- ringtone + incoming-call reminder ----------
let actx=null;
const AC=window.AudioContext||window.webkitAudioContext;
function unlockAudio(){try{actx=actx||(AC?new AC():null);if(actx&&actx.state==='suspended'){const resumed=actx.resume();if(resumed&&resumed.catch)resumed.catch(()=>{})}}catch(e){}}
function ringTone(){
  try{
    unlockAudio();if(!actx)return;
    const p=store.profiles.find(x=>x.id===ring.pid)||P();
    const volume=Math.max(.2,Math.min(1,(p&&p.alertVolume||90)/100));
    const t=actx.currentTime,master=actx.createGain();
    master.gain.setValueAtTime(volume*.8,t);master.connect(actx.destination);
    // soft bell chime: four rising notes, sine waves with a gentle decay
    [[1046.5,0],[1318.5,.26],[1568,.52],[2093,.78]].forEach(([f,off])=>{
      [[1,.5],[2,.1]].forEach(([mult,amp])=>{
        const o=actx.createOscillator(),g=actx.createGain(),s=t+off;
        o.type='sine';o.frequency.setValueAtTime(f*mult,s);
        g.gain.setValueAtTime(.0001,s);g.gain.exponentialRampToValueAtTime(amp,s+.02);g.gain.exponentialRampToValueAtTime(.0001,s+1.1);
        o.connect(g);g.connect(master);o.start(s);o.stop(s+1.15);
      });
    });
    setTimeout(()=>{try{master.disconnect()}catch(e){}},2400);
  }catch(e){console.warn('Audio reminder unavailable',e)}
}
function speakReminder(){
  try{
    const p=store.profiles.find(x=>x.id===ring.pid)||P();
    if(!p||p.voiceAlerts===false||!('speechSynthesis' in window)||!window.SpeechSynthesisUtterance)return;
    window.speechSynthesis.cancel();
    const child=profileAge(p.dob)<=18;
    const message=ring.test?'This is a test of your MediMate reminder.':child
      ?'Medicine time. Please ask your parent or guardian to help you check your medicine reminder.'
      :'Medicine time. Please check your medicine instructions now.';
    const u=new SpeechSynthesisUtterance(message);u.volume=1;u.rate=1.02;u.pitch=1.05;
    window.speechSynthesis.speak(u);
  }catch(e){console.warn('Spoken reminder unavailable',e)}
}
const ring={active:false,pid:null,meds:[],start:0,loop:null,vib:null,stopT:null,rt:null,voiceT:null,reps:0,test:false};
const fkey=(p,m)=>p.id+'_'+dkey(midnight())+'_'+m.id+'_'+m.time;
function ringList(){$('r-list').innerHTML=ring.meds.map(m=>`<div class="r-item"><div class="ri-ic"><span class="ms">medication</span></div><div class="ri-tx"><b>${esc(m.name)}</b>${m.dose?'<small>'+esc(m.dose)+'</small>':''}</div></div>`).join('')}
function stopSound(){try{stopToneAudio()}catch(e){}
  clearInterval(ring.loop);clearInterval(ring.vib);clearInterval(ring.voiceT);clearTimeout(ring.stopT);clearTimeout(ring.rt);
  try{navigator.vibrate&&navigator.vibrate(0)}catch(e){}
  try{if('speechSynthesis' in window)window.speechSynthesis.cancel()}catch(e){}
}

// ---------- app settings ----------
const APP_VERSION='4.0';
const APP_RELEASE_DATE='28 November 2026';

// Re-draw a list only when its content really changed (stops the once-a-minute flicker)
(function(){
  const keep=new Set(['nextcard','todaylist','timelist','daylist','grid','bday','plist','d-list','reviewbar']),d=Object.getOwnPropertyDescriptor(Element.prototype,'innerHTML');
  Object.defineProperty(Element.prototype,'innerHTML',{get:d.get,set(v){if(this.id&&keep.has(this.id)){if(this.__h===v&&this.firstChild)return;this.__h=v}d.set.call(this,v)},configurable:true});
})();
let S={orient:'auto',theme:'system',vol:80,tone:0,toneUri:'',toneName:'Default alarm sound',pdf:'normal',haptic:true,autoUpdate:false,early:false,tasksEnabled:false};
try{Object.assign(S,JSON.parse(localStorage.getItem('mm_settings')||'{}'))}catch(e){}
if(S.orient==='system')S.orient='auto';S.tone=Math.max(0,Math.min(9,Number(S.tone)||0));delete S.hapLevel;delete S.hapIntensity;S.haptic=S.haptic!==false;S.autoUpdate=S.autoUpdate===true;S.early=S.early===true;S.tasksEnabled=S.tasksEnabled===true;
const profilePrefKeys=['tone','toneUri','toneName','vol','haptic'];
function loadProfilePrefs(pid){try{const key='mm_profile_settings_'+pid,raw=localStorage.getItem(key);if(raw){const saved=JSON.parse(raw);profilePrefKeys.forEach(k=>{if(saved[k]!==undefined)S[k]=saved[k]});}else{const data={};profilePrefKeys.forEach(k=>data[k]=S[k]);localStorage.setItem(key,JSON.stringify(data));}}catch(e){}}
function persistProfilePrefs(){const p=P();if(!p)return;try{const data={};profilePrefKeys.forEach(k=>data[k]=S[k]);localStorage.setItem('mm_profile_settings_'+p.id,JSON.stringify(data));}catch(e){}}
const saveS=()=>{try{localStorage.setItem('mm_settings',JSON.stringify(S));persistProfilePrefs()}catch(e){}};
try{if(P())loadProfilePrefs(P().id)}catch(e){}
function setDark(d){document.documentElement.classList.toggle('dark',d);try{const m=MA();m&&m.setBars({dark:d})}catch(e){}}
async function applyTheme(){
  if(S.theme!=='system'){setDark(S.theme==='dark');return}
  let d=null;try{const m=MA();if(m&&m.getNight){const r=await m.getNight();d=!!r.dark}}catch(e){}
  if(d===null)d=!!(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches);
  setDark(d);
}
window.addEventListener('systemTheme',()=>{if(S.theme==='system')applyTheme()});
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&S.theme==='system')applyTheme()});
function applyS(k){
  const m=MA();
  if(!k||k==='theme')applyTheme();
  if(!k||k==='orient'){try{m&&m.setOrientation({mode:S.orient})}catch(e){}}
  if(!k||k==='tone'||k==='toneUri'||k==='vol'){try{m&&m.setPrefs({tone:S.tone,toneUri:S.toneUri||'',vol:S.vol})}catch(e){}}
}
function setS(k,v){S[k]=v;saveS();applyS(k);renderSettings()}
let pvAud=null,SOUNDS=null,SOUNDS_LOADING=false;
function stopPreview(){pvAud=null;try{const m=MA();m&&m.stopSound&&m.stopSound()}catch(e){}}
async function loadSounds(){
  if(SOUNDS||SOUNDS_LOADING)return;SOUNDS_LOADING=true;
  try{const m=MA();const r=m&&m.listSounds?await m.listSounds():null;SOUNDS=(r&&r.sounds)||[]}catch(e){SOUNDS=[]}
  SOUNDS_LOADING=false;try{renderSettings()}catch(e){}
}
let SOUNDS_ALL=false;
function toggleSounds(){SOUNDS_ALL=!SOUNDS_ALL;renderSettings()}
function pickSound(i){
  const list=[{title:'Default alarm sound',uri:''}].concat(SOUNDS||[]);const x=list[i];if(!x)return;
  const same=pvAud===x.uri&&S.toneUri===x.uri;
  S.toneUri=x.uri;S.toneName=x.title;saveS();applyS('toneUri');
  if(same){stopPreview()}else{pvAud=x.uri;try{const m=MA();m&&m.playSound&&m.playSound({uri:x.uri,volume:S.vol/100,loop:false})}catch(e){}}
  renderSettings();
}
function setTasksEnabled(on){S.tasksEnabled=!!on;saveS();renderSettings();render();toast(on?'Tasks enabled in schedules':'Tasks hidden from new schedule items')}
function setHaptic(on){
  if(on&&HAP_OK===false){toast('Haptic feedback is not available on this device');renderSettings();return}
  S.haptic=!!on;saveS();if(on)previewHaptic();renderSettings();
}
function setEarly(on){S.early=!!on;saveS();scheduleNative();renderSettings();toast(on?'Early reminder on: a notification 15 minutes before each dose':'Early reminder off')}
function setAutoUpdate(on){S.autoUpdate=!!on;saveS();renderSettings();toast(on?'Auto update on':'Auto update off');if(on)setTimeout(()=>checkUpdate(false),700)}
function soundList(){
  const all=[{title:'Default alarm sound',uri:''}].concat(SOUNDS||[]),real=all.length-1;
  let show=[];for(let i=1;i<all.length;i++)show.push(i);
  if(!SOUNDS_ALL){show=show.slice(0,10);const sel=all.findIndex(x=>x.uri===S.toneUri);if(sel>10)show=show.slice(0,9).concat([sel])}
  show=[0].concat(show);
  return show.map(i=>{const x=all[i],on=S.toneUri===x.uri;return `<div class="tr ${on?'on':''}" onclick="pickSound(${i})"><span class="ms">${on?'radio_button_checked':'radio_button_unchecked'}</span><b>${esc(x.title)}</b><span class="ms" style="color:#5f6368">music_note</span></div>`}).join('')
    +(real>10?`<div class="row" style="margin-top:6px"><button class="sc" onclick="toggleSounds()">${SOUNDS_ALL?'Show less':'See all ('+real+')'}</button></div>`:'');
}
// ---- reminder health check (notifications / lock-screen alarm / battery) ----
let RS=null;
async function loadRS(){try{const m=MA();if(!m||!m.getStatus){RS=null;return}RS=await m.getStatus()}catch(e){RS=null}try{if(document.getElementById('set-view')&&document.getElementById('set-view').classList.contains('on'))renderSettings()}catch(e){}}
async function fixRS(k){try{window.__rsWait=true;await MA().fixSetting({what:k})}catch(e){toast('Open Settings > Apps > MediMate')}}
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&window.__rsWait){window.__rsWait=false;setTimeout(loadRS,400)}});
async function reminderNudge(){
  try{
    const m=MA();if(!m||!m.getStatus)return;const st=await m.getStatus();RS=st;
    const day=dkey(new Date());let seen='';try{seen=localStorage.getItem('mm_nudge')||''}catch(e){}
    if(st.notif||seen===day||!store.profiles.some(p=>p.meds.length))return;
    try{localStorage.setItem('mm_nudge',day)}catch(e){}
    const a=$('ai-view'),r=$('ring');if((a&&a.classList.contains('on'))||(r&&r.classList.contains('on')))return;
    aiSheet(`<h2>Reminders are blocked</h2><p>Notifications are turned off for MediMate, so your medicine reminders cannot appear. Tap Fix and allow notifications.</p><div class="aib"><button onclick="aiClose()">Later</button><button class="p" onclick="aiClose();fixRS('notif')">Fix</button></div>`);
  }catch(e){}
}
window.addEventListener('load',()=>setTimeout(reminderNudge,3500));
// ---- doses marked "Taken" from the 15-minute notification while the app was closed ----
async function applyPendingTaken(){
  try{
    const m=MA();if(!m||!m.getPendingTaken)return;const r=await m.getPendingTaken(),xs=(r&&r.items)||[];let ch=false;
    xs.forEach(x=>{const p=store.profiles.find(q=>String(q.id)===String(x.profileId));if(!p||!x.dateKey)return;const k=x.dateKey+'_'+x.medicineId;if(!p.taken[k]){markTaken(p,x.dateKey,x.medicineId,x.ts);ch=true}});
    ((r&&r.snoozed)||[]).forEach(x=>{const p=store.profiles.find(q=>String(q.id)===String(x.profileId));if(!p||!x.dateKey||!x.until)return;const k=x.dateKey+'_'+x.medicineId;if(!p.taken[k]&&!(p.snooze[k]>x.until)){p.snooze[k]=x.until;ch=true}});
    if(ch){save();if(P())render()}
  }catch(e){}
}
window.addEventListener('load',()=>setTimeout(applyPendingTaken,900));
document.addEventListener('visibilitychange',()=>{if(!document.hidden)applyPendingTaken()});
document.addEventListener('resume',applyPendingTaken);
// ---- review request: asked after a reminder, until the person taps Later or writes one (then never again) ----
const REVIEW_KEY='mm_review';
function reviewState(){try{return localStorage.getItem(REVIEW_KEY)||''}catch(e){return ''}}
function setReviewState(v){try{localStorage.setItem(REVIEW_KEY,v)}catch(e){}}
function maybeAskReview(){
  if(reviewState())return;
  const a=document.getElementById('ai-view'),r=document.getElementById('ring');
  if((a&&a.classList.contains('on'))||(r&&r.classList.contains('on')))return;
  aiSheet(`<h2>Enjoying MediMate?</h2><p>Your reminder was a success. Would you like to write a short review? It helps us make MediMate better.</p><div class="aib"><button onclick="reviewLater()">Later</button><button class="p" onclick="reviewGo()"><span class="ms">rate_review</span>Write a review</button></div>`);
}
function reviewLater(){setReviewState('later');aiClose()}
async function reviewGo(){
  setReviewState('done');aiClose();
  const subject='MediMate review',body='Hello MediMate team,\n\nMy review of MediMate '+APP_VERSION+':\n\nRating (1 to 5): \nWhat I like: \nWhat can be better: \n';
  try{const m=MA();if(m&&m.composeEmail)await m.composeEmail({to:LINK_EMAIL,subject,body});else window.location.href='mailto:'+LINK_EMAIL+'?subject='+encodeURIComponent(subject)+'&body='+encodeURIComponent(body)}
  catch(e){toast('Could not open your email app')}
}
// kids' profiles: a new reminder does not ring until a parent or guardian confirms it
function reviewNudge(){
  const p=P();if(!p||!p.meds.some(m=>m.review&&!m.nodur))return;
  toast('A parent or guardian must confirm this reminder before it can ring.',{label:'Confirm',fn:confirmAll},10000);
}
// ---- What's new ----
const WHATS_NEW=[{v:'3.6',date:'27 November 2026',items:[
  'New MedEx tab next to Calendar: ask about your medicines and schedule. Tap MedEx at the top to choose Oxygen 1.0 (fastest, default) or Cosmos 1.0 (most accurate, slower).',
  'MedEx chat looks like a messaging app: a plus button for files, a microphone that turns your voice into text, grey bubbles for you and blue bubbles for the answers.',
  'Every button and screen now moves slowly and smoothly. The flashing see-through square under the bottom buttons is gone; only a soft blue pill appears.',
  'Settings switches keep their colour but now glide smoothly.',
  'Reminder screen: press and hold the middle button for 3 seconds to cancel. The medicine stays on your list.',
  'Haptic feedback rebuilt for more phones, with a Test vibration button in App settings.',
  'Phone settings button opens Autostart and Battery settings on Xiaomi, Oppo, Vivo, Realme, Samsung, Huawei and OnePlus phones so reminders keep working.',
  'Landscape layout redesigned with a slim side rail and centred content.'
]},{v:'3.5',date:'25 November 2026',items:[
  'Reminder screen redesigned: white on top with a soft blue, violet and pink cloud below, the MediMate logo, and clear see-through medicine cards.',
  'Slide to answer, like a phone call: slide right when you have taken the medicine, or slide left to snooze for 10 minutes.',
  'The exact time you press Taken is now saved, and History shows that time.',
  'The alarm notification also has Taken and Snooze buttons, so you can answer without opening the app.',
  'When an alarm opened MediMate on a locked phone, the app now closes smoothly after you answer it.',
  '15 minutes before: fixed. It now rings, stays on screen and has a Taken button. A dose added less than 15 minutes ahead is reminded right away.',
  'Update notification: MediMate checks once a day and tells you when a new version is ready. Auto update is more dependable.',
  'After an update, MediMate returns to the screen you were on.',
  'Haptic feedback is now always at maximum, and tells you if your phone cannot vibrate.',
  'Smoother app: lighter animations, and the motion sensor now runs only while a reminder is ringing, which saves battery.',
  'Settings and History redesigned in a cleaner Google style. Press and hold the About box for 3 seconds to see the version and release date.',
  'Removed the three-tick Reminder check from App settings.'
]},{v:'3.4',date:'24 November 2026',items:[
  'Early reminder, auto update, a simple haptic switch, 1 second screen motion, a ringtone list with See all, and a What\'s new screen.'
]}];
function showWhatsNew(){
  const cur=WHATS_NEW.find(x=>x.v===APP_VERSION)||WHATS_NEW[0];
  aiSheet(`<h2>What's new in ${esc(cur.v)}</h2><p style="font-size:13px;color:#5f6368">Released ${esc(cur.date)}</p><ul class="wn">${cur.items.map(i=>`<li>${esc(i)}</li>`).join('')}</ul><div class="aib"><button class="p" onclick="aiClose()">Got it</button></div>`);
}

function renderSettings(){
  const v=document.getElementById('set-view');if(!v)return;const y=v.scrollTop;
  const chip=(k,val,label)=>`<button class="sc ${S[k]===val?'on':''}" onclick="setS('${k}','${val}')">${label}</button>`;
  const sec=(t,inner)=>`<section class="gs"><h4>${t}</h4><div class="gc">${inner}</div></section>`;
  const sw=(t,sub,on,fn,dis)=>`<label class="gr sw"><span class="gt"><b>${t}</b>${sub?'<small>'+sub+'</small>':''}</span><input type="checkbox" ${on?'checked':''} ${dis?'disabled':''} onchange="${fn}"></label>`;
  const hapNo=HAP_OK===false;
  v.innerHTML=`<div class="sh"><button type="button" class="profile-back" aria-label="Back" onclick="closeSettings()"><span class="ms">arrow_back</span></button><h2>App settings</h2></div>`
  +sec('Display',`<div class="gr col"><div class="gt"><b>Screen rotation</b></div><div class="row">${chip('orient','auto','Auto')}${chip('orient','portrait','Portrait')}${chip('orient','landscape','Landscape')}</div></div>
    <div class="gr col"><div class="gt"><b>Theme</b></div><div class="row">${chip('theme','system','System')}${chip('theme','light','Light')}${chip('theme','dark','Dark')}</div></div>`)
  +sec('Tasks',sw('Show tasks in schedules','Allow non-medical reminders such as face wash or reading',S.tasksEnabled,'setTasksEnabled(this.checked)'))
  +sec('Haptic feedback',sw('Haptic feedback',hapNo?'Haptic feedback is not available on this device':'Strong vibration on every button and tap',!hapNo&&S.haptic!==false,'setHaptic(this.checked)',hapNo)+`<div class="gr col"><div class="row"><button class="sc" onclick="testHaptic()">Test vibration</button></div></div>`)
  +sec('Reminders',
    sw('Speak reminders','Voice message with the alarm for the current profile',P()&&P().voiceAlerts!==false,'setVoice(this.checked)',!P())
    +sw('15 minutes before','A notification before each dose that rings, stays on screen and has a Taken button',S.early,'setEarly(this.checked)')
    +`<div class="gr col"><div class="boxh"><b>Alarm volume</b><span id="vv">${S.vol}%</span></div><input type="range" min="10" max="100" value="${S.vol}" oninput="S.vol=+this.value;document.getElementById('vv').textContent=S.vol+'%'" onchange="setS('vol',+this.value)"><div class="gt"><small>This also sets your phone's alarm volume.</small></div></div>`)
  +sec('Reminders on every phone',`<div class="gr col"><div class="gt"><b>Keep reminders reliable</b><small>Some phones (Xiaomi, Oppo, Vivo, Realme, Samsung, Huawei, OnePlus) stop apps in the background. Allow Autostart, set Battery to No restrictions, and keep notifications on for MediMate.</small></div><div class="row"><button class="sc" onclick="openOemSettings()">Open phone settings</button></div></div>`)
  +sec('Alarm ringtone',SOUNDS?soundList():'<div class="tr"><b>Loading sounds…</b></div>')
  +sec('AI timetable scan',AI_BAKED?'<div class="gr"><div class="gt"><small>Ready. Tap the sparkle button on the Schedule screen to scan a prescription.</small></div></div>':'<div class="gr col"><div class="row"><button class="sc" onclick="aiSetup()">'+(AI.url?'Change AI service':'Set up AI service')+'</button></div><div class="gt" style="margin-top:8px"><small>Needs the address and access code from the app owner.</small></div></div>')
  +sec('Timetable download style',`<div class="gr col"><div class="row">${chip('pdf','normal','Normal list')}${chip('pdf','grid','Grid (times x dates)')}</div><div class="gt" style="margin-top:8px"><small>Grid shows times across the top, the next 14 dates down the side, and the medicines in the boxes.</small></div></div>`)
  +sec('Updates',sw('Auto update','Install each new version automatically when it is available',S.autoUpdate,'setAutoUpdate(this.checked)')
    +`<div class="gr col aboutbox" id="aboutbox"><div class="gt"><b>MediMate · Version ${APP_VERSION}</b><small>MediMate is still in development. Features, reminders and update behavior may change and may contain bugs. Use it only as a supplementary reminder and verify medicines with a parent/guardian and a qualified healthcare professional.</small></div></div>
    <div class="gr col"><div class="row"><button class="sc" style="background:#0b57d0;color:white;border-color:#0b57d0" onclick="checkUpdate(true)">Check for updates</button><button class="sc" onclick="showWhatsNew()">What's new</button></div></div>`);
  v.scrollTop=y;
}
// press and hold the About box for 3 seconds to see the version and release date
(function(){
  let tm=null,sx=0,sy=0;
  const clear=()=>{clearTimeout(tm);tm=null;document.querySelectorAll('.aboutbox.pressing').forEach(x=>x.classList.remove('pressing'))};
  document.addEventListener('pointerdown',e=>{
    const b=e.target.closest&&e.target.closest('#set-view .aboutbox');if(!b)return;
    clear();sx=e.clientX;sy=e.clientY;b.classList.add('pressing');
    tm=setTimeout(()=>{tm=null;b.classList.remove('pressing');hap('click');showVersionInfo()},3000);
  },true);
  ['pointerup','pointercancel','scroll','touchend'].forEach(ev=>document.addEventListener(ev,clear,true));
  document.addEventListener('pointermove',e=>{if(tm&&(Math.abs(e.clientX-sx)>12||Math.abs(e.clientY-sy)>12))clear()},true);
  document.addEventListener('contextmenu',e=>{if(e.target.closest&&e.target.closest('.aboutbox'))e.preventDefault()});
})();
function openSettings(){closeDrawer();loadSounds();let v=document.getElementById('set-view');if(!v){v=document.createElement('div');v.id='set-view';document.body.appendChild(v)}renderSettings();v.classList.add('on')}
function closeSettings(){stopPreview();const v=document.getElementById('set-view');if(v)v.classList.remove('on')}
window.addEventListener('load',()=>{try{if(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform())document.body.classList.add('native')}catch(e){}applyS()});
function playToneAudio(){
  const fb=()=>{ringTone();ring.loop=setInterval(ringTone,2600)};
  try{const m=MA();if(m&&m.playSound){m.playSound({uri:S.toneUri||'',volume:S.vol/100,loop:true}).catch(fb);return}}catch(e){}
  fb();
}
function stopToneAudio(){try{const m=MA();m&&m.stopSound&&m.stopSound()}catch(e){}if(ring.aud){try{ring.aud.pause()}catch(e){}ring.aud=null}}
function playSelectedPreviewForTest(){stopToneAudio();playToneAudio()}

// ---------- AI schedule from a photo (optional) ----------
let AI={url:'',code:'',ok:false,list:[]};
try{Object.assign(AI,JSON.parse(localStorage.getItem('mm_ai')||'{}'))}catch(e){}
const AI_URL='@@AI_URL@@',AI_CODE='@@AI_CODE@@',AI_BAKED=AI_URL.charAt(0)!=='@';
if(AI_BAKED){AI.url=AI_URL;AI.code=AI_CODE}
const saveAI=()=>{try{localStorage.setItem('mm_ai',JSON.stringify({url:AI_BAKED?'':AI.url,code:AI_BAKED?'':AI.code,ok:AI.ok}))}catch(e){}};

// Haptics always run at maximum strength. HAP_OK says whether this phone can vibrate at all.
let HAP_OK=null;
window.addEventListener('load',async()=>{try{const m=MA();if(m&&m.hapticInfo){const r=await m.hapticInfo();HAP_OK=!!(r&&r.available)}else HAP_OK=!!navigator.vibrate}catch(e){HAP_OK=!!navigator.vibrate}try{if(document.getElementById('set-view'))renderSettings()}catch(e){}});
function hap(k){if(S.haptic===false)return;let nativeDone=false;try{const m=MA();if(m&&m.haptic){m.haptic({kind:k||'tick'});nativeDone=true}}catch(e){}if(!nativeDone){try{if(navigator.vibrate)navigator.vibrate(k==='click'?45:22)}catch(e){}}}
document.addEventListener('pointerdown',e=>{const t=e.target.closest&&e.target.closest('button,a,.item,.card,.hrow,.day,.tr,.sc,.aip,.iconbtn,.herobtn,[role=button],[onclick],select,input[type=range],input[type=checkbox],input[type=time],input[type=date],label');if(t&&!t.disabled)hap(t.closest('#nav')?'click':'tick')},true);
function swipeTo(n,d){hap('click');document.body.dataset.dir=d;goTab(n);render()}
(function(){
  const order=['home','time','cal'];let x0=0,y0=0,t0=0,ok=false;
  const scrollX=el=>{for(;el&&el!==document.body;el=el.parentElement){const o=getComputedStyle(el).overflowX;if((o==='auto'||o==='scroll')&&el.scrollWidth>el.clientWidth+4)return true}return false};
  const busy=()=>{const d=$('drawer');return (d&&d.classList.contains('on'))||['ring','set-view','ai-view'].some(i=>{const e=document.getElementById(i);return e&&e.classList.contains('on')})||document.querySelector('dialog[open],.modal.on,.sheet.on')};
  let dOpen=false;const drawerOn=()=>{const d=$('drawer');return !!(d&&d.classList.contains('on'))};
  document.addEventListener('touchstart',e=>{dOpen=drawerOn();const t=e.touches[0];x0=t.clientX;y0=t.clientY;t0=Date.now();ok=e.touches.length===1&&!busy()&&!(e.target.closest&&e.target.closest('input,textarea,select'))&&!scrollX(e.target)},{passive:true});
  document.addEventListener('touchend',e=>{
    if(dOpen){dOpen=false;const t=e.changedTouches[0],dx=t.clientX-x0,dy=t.clientY-y0;if(dx<-60&&Math.abs(dy)<Math.abs(dx)*.7){hap('click');closeDrawer()}return}
    if(!ok)return;ok=false;const t=e.changedTouches[0],dx=t.clientX-x0,dy=t.clientY-y0;
    if(Math.abs(dx)<70||Math.abs(dy)>Math.abs(dx)*.6||Date.now()-t0>700)return;
    const cur=(document.querySelector('#nav button.on')||{dataset:{}}).dataset.s,i=order.indexOf(cur);if(i<0)return;
    if(dx>0){if(i===0){hap('click');openDrawer()}else{hap('click');swipeTo(order[i-1],'prev')}}
    else if(i<order.length-1){hap('click');swipeTo(order[i+1],'next')}
  },{passive:true});
})();

const histOn=d=>((P()||{}).hist||[]).filter(h=>h.date===dkey(d));
function histData(){
  const p=P(),out=[];if(!p)return out;
  Object.keys(p.taken||{}).forEach(k=>{if(!p.taken[k])return;const i=k.indexOf('_'),m=p.meds.find(x=>x.id===+k.slice(i+1));if(m&&!m.review)out.push({date:k.slice(0,i),name:m.name,time:(p.takenAt&&p.takenAt[k])||m.time||'00:00',sched:m.time||'',dose:m.dose||'',own:false,key:k})});
  (p.hist||[]).forEach(h=>out.push({date:h.date,name:h.name,time:h.time,dose:h.dose||'',own:true,id:h.id}));
  return out.sort((x,y)=>y.date.localeCompare(x.date)||y.time.localeCompare(x.time));
}
const ordinal=n=>n+((n%100>=11&&n%100<=13)?'th':({1:'st',2:'nd',3:'rd'}[n%10]||'th'));
const histDateFull=x=>{const d=parseD(x);return ordinal(d.getDate())+' '+d.toLocaleDateString('en-GB',{month:'long'})+' '+d.getFullYear()};
const histDate=x=>x===dkey(new Date())?'Today':histDateFull(x);
const histDateShort=x=>{
  const d=parseD(x),t=midnight(),y=addDays(t,-1);
  if(x===dkey(t))return 'Today';if(x===dkey(y))return 'Yesterday';
  const o={weekday:'short',day:'numeric',month:'short'};if(d.getFullYear()!==t.getFullYear())o.year='numeric';
  return d.toLocaleDateString('en-GB',o);
};
function histRender(){
  const v=document.getElementById('hist-view');if(!v)return;const H=window.__H=histData();let last='',h='';
  H.forEach((e,i)=>{
    if(e.date!==last){last=e.date;h+=`<div class="gh-date">${esc(histDateShort(e.date))}</div>`}
    h+=`<button type="button" class="hrow gh-row" data-history-index="${i}" onclick="histClick(${i})"><span class="gh-ic"><span class="ms">medication</span></span><span class="gh-tx"><b>${esc(e.name)}</b>${e.dose?'<small>'+esc(e.dose)+'</small>':''}</span><span class="gh-tm">${fmt(e.time)}</span></button>`;
  });
  v.innerHTML=`<div class="gh-bar"><button type="button" class="profile-back" aria-label="Back" onclick="document.getElementById('hist-view').classList.remove('on')"><span class="ms">arrow_back</span></button><h2>History</h2></div>`
    +(H.length?h:'<div class="gh-empty"><span class="ms">history</span>Nothing yet.<br>Medicines you mark as taken, or add here, will show up.</div>')
    +`<button type="button" class="histfab" aria-label="Add to history" onclick="histAdd()"><span class="ms">add</span>Add</button>`;
}
function openHistory(){closeDrawer();let v=document.getElementById('hist-view');if(!v){v=document.createElement('div');v.id='hist-view';document.body.appendChild(v)}histRender();v.classList.add('on');v.scrollTop=0}
function histOpen(i){
  const e=(window.__H||[])[i];if(!e)return;
  aiSheet(`<h2>${esc(e.name)}</h2><p><b>Date:</b> ${histDateFull(e.date)}<br><b>Taken at:</b> ${fmt(e.time)}${e.sched&&e.sched!==e.time?'<br><b>Scheduled for:</b> '+fmt(e.sched):''}${e.dose?'<br><b>Dose:</b> '+esc(e.dose):''}</p><div class="aib"><button onclick="aiClose()">Close</button><button onclick="histDeleteIndex(${i})">Delete</button></div>`);
}
function histDel(id){const p=P();if(!p)return;p.hist=(p.hist||[]).filter(h=>h.id!==id);save();aiClose();histRender();render();toast('Removed from history')}
function histAdd(){
  const d=new Date(),t=pad(d.getHours())+':'+pad(d.getMinutes());
  aiSheet(`<h2>Add to history</h2><small>Date</small><input type="date" id="h-date" value="${dkey(d)}" max="${dkey(d)}"><small>Medicine name</small><input type="text" id="h-name" placeholder="Medicine name"><small>Time taken</small><input type="time" id="h-time" value="${t}"><small>Dose</small><input type="text" id="h-dose" placeholder="Dose (optional)"><div class="aib"><button onclick="aiClose()">Cancel</button><button class="p" onclick="histSave()">Save</button></div>`);
}
function histSave(){
  const p=P();if(!p)return;const date=$('h-date').value,name=$('h-name').value.trim(),time=$('h-time').value,dose=$('h-dose').value.trim(),now=new Date();
  if(!name){toast('Enter the medicine name');return}
  if(!/^\d{4}-\d\d-\d\d$/.test(date)||!/^\d\d:\d\d$/.test(time)){toast('Enter the date and time');return}
  if(parseD(date+'')>midnight()||(date===dkey(now)&&time>pad(now.getHours())+':'+pad(now.getMinutes()))){toast("The date and time can't be in the future");return}
  p.hist=p.hist||[];p.hist.push({id:Date.now(),date:date,name:name,time:time,dose:dose});save();aiClose();histRender();render();toast('Added to history');
}

function checkEnded(){
  try{
    const p=P();if(!p||document.getElementById('ai-view')&&document.getElementById('ai-view').classList.contains('on'))return;
    const hit=[];let ch=false;
    p.meds.forEach(m=>{if(m.days>=3650||m.askedEnd)return;const end=addDays(parseD(m.start),m.days-1),ago=Math.round((today-end)/864e5);if(ago>=1){m.askedEnd=true;ch=true;if(ago<=14&&!hit.includes(m.name))hit.push(m.name)}});
    if(ch)save();
    if(hit.length)aiSheet(`<h2>Course finished</h2><p>${hit.map(esc).join(', ')} ${hit.length>1?'have':'has'} finished. Do you need the next dosage?</p><div class="aib"><button onclick="aiClose()">Later</button><button class="p" onclick="aiClose();aiStart()">Scan new prescription</button></div><div class="aib"><button onclick="aiClose();openEdit(null)">Add manually</button></div>`);
  }catch(e){}
}
window.addEventListener('load',()=>setTimeout(checkEnded,1500));
document.addEventListener('visibilitychange',()=>{if(!document.hidden)setTimeout(checkEnded,800)});
function calToday(){calY=today.getFullYear();calM=today.getMonth();renderCal();pickDay(today.getFullYear(),today.getMonth(),today.getDate())}
function calGo(y,m){calY=y;calM=m;renderCal();aiClose()}
function calJump(y){
  const mo=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  aiSheet(`<h2 style="display:flex;justify-content:space-between;align-items:center"><button class="aip" onclick="calJump(${y-1})"><span class="ms">chevron_left</span></button>${y}<button class="aip" onclick="calJump(${y+1})"><span class="ms">chevron_right</span></button></h2><div class="calm">${mo.map((n,i)=>`<button class="${y===calY&&i===calM?'p':''}" onclick="calGo(${y},${i})">${n}</button>`).join('')}</div><div class="aib"><button onclick="aiClose()">Close</button></div>`);
}

function mmRipple(t,e){const cs=getComputedStyle(t);if(cs.position==='static')t.style.position='relative';if(cs.overflow==='visible')t.style.overflow='hidden';const r=t.getBoundingClientRect(),d=Math.max(r.width,r.height)*2,sp=document.createElement('span');sp.className='mm-rip';sp.style.cssText='width:'+d+'px;height:'+d+'px;left:'+(e.clientX-r.left-d/2)+'px;top:'+(e.clientY-r.top-d/2)+'px';t.appendChild(sp);setTimeout(()=>sp.remove(),750)}
document.addEventListener('pointerdown',e=>{const t=e.target.closest&&e.target.closest('button,.item,.herobtn,.sc,.tr');if(t&&!t.disabled&&!t.closest('#ring,#nav,.mx-bar,.mx-head,.mx-opt,#mxintro')){const ev={clientX:e.clientX,clientY:e.clientY};requestAnimationFrame(()=>{try{mmRipple(t,ev)}catch(x){}})}},{passive:true});
let lastBack=0;
function mmBack(){
  const on=id=>{const e=document.getElementById(id);return !!(e&&e.classList.contains('on'))};
  if(on('ring')||on('mxintro'))return;
  if(on('ai-view')){aiClose();return}
  if(on('hist-view')){document.getElementById('hist-view').classList.remove('on');return}
  if(on('set-view')){closeSettings();return}
  if(on('drawer')){closeDrawer();return}
  const bs=[...document.querySelectorAll('button[aria-label^="Back"],button[aria-label^="Close"],button.profile-back')].filter(b=>{const r=b.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(b).visibility!=='hidden'});
  if(bs.length){bs[bs.length-1].click();return}
  const cur=(document.querySelector('#nav button.on')||{dataset:{}}).dataset.s;
  if(cur&&cur!=='home'){swipeTo('home','prev');return}
  const now=Date.now();if(now-lastBack<2000){try{plug('App').exitApp()}catch(e){}return}
  lastBack=now;toast('Press back again to exit',null,1800);
}
window.addEventListener('load',()=>{try{const A=plug('App');if(A&&A.addListener)A.addListener('backButton',()=>mmBack())}catch(e){}});

// ---------- share a profile by link ----------
const SHARE_PAGE='https://abhinavvnm1529-cloud.github.io/Medimate-/open.html';
const shareData=p=>({v:1,name:p.name,dob:p.dob||'',routine:p.routine||{},meds:p.meds.map(m=>({id:m.id,name:m.name,dose:m.dose||'',time:m.time,days:m.days,every:m.every||1,start:m.start,notes:m.notes||'',review:!!m.review,nodur:!!m.nodur})),prn:(p.prn||[]).map(m=>({id:m.id,name:m.name,dose:m.dose||''})),taken:p.taken||{},snooze:p.snooze||{},hist:p.hist||[],voiceAlerts:p.voiceAlerts!==false,alertVolume:p.alertVolume||90,bestStreak:p.bestStreak||0});
async function backupAllProfilesLink(){
  if(!store.profiles.length){toast('There are no profiles to back up');return}
  aiSpin('Preparing all profiles…');
  try{const payload={v:2,profiles:store.profiles.map(shareData)},link=SHARE_PAGE+'#d='+await b64enc(payload);window.__link=link;
    aiSheet(`<h2>All-profile backup link</h2><p>This link contains <b>${store.profiles.length} profile(s)</b>, including medicine schedules and history. It is not encrypted. Anyone who receives the link may be able to read the information, so share it only with a trusted parent or guardian and keep it private. Profile PINs and recovery email addresses are not included; set them again after restoring.</p>${link.length>20000?'<p style="color:#b3261e">This backup link is very long and may not work in some messaging apps. Use Copy backup text as an additional safe copy.</p>':''}<div class="aib"><button class="p" onclick="shareAllLinkNow()">Share link</button><button onclick="copyLinkNow()">Copy link</button></div><div class="aib"><button onclick="aiClose()">Close</button></div>`);
  }catch(e){aiSheet('<h2>Could not create backup link</h2><p>Please use the backup text option instead.</p><div class="aib"><button class="p" onclick="aiClose()">OK</button></div>')}
}
async function shareAllLinkNow(){try{await MA().shareText({text:'MediMate backup for all profiles: '+window.__link})}catch(e){try{await navigator.share({text:window.__link})}catch(x){toast('Could not open sharing')}}}
async function b64enc(obj){
  const raw=new TextEncoder().encode(JSON.stringify(obj));let bytes=raw,pre='j';
  if(window.CompressionStream){try{const cs=new CompressionStream('deflate-raw'),w=cs.writable.getWriter();w.write(raw);w.close();bytes=new Uint8Array(await new Response(cs.readable).arrayBuffer());pre='z'}catch(e){bytes=raw;pre='j'}}
  let bin='';for(let i=0;i<bytes.length;i+=8192)bin+=String.fromCharCode.apply(null,bytes.subarray(i,i+8192));
  return pre+btoa(bin).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
async function b64dec(str){
  const pre=str[0];let b=str.slice(1).replace(/-/g,'+').replace(/_/g,'/');b+='='.repeat((4-b.length%4)%4);
  let bytes=Uint8Array.from(atob(b),c=>c.charCodeAt(0));
  if(pre==='z'){const ds=new DecompressionStream('deflate-raw'),w=ds.writable.getWriter();w.write(bytes);w.close();bytes=new Uint8Array(await new Response(ds.readable).arrayBuffer())}
  return JSON.parse(new TextDecoder().decode(bytes));
}
async function shareProfile(){
  const p=P();if(!p)return;aiSpin('Making the link\u2026');
  try{
    const link=SHARE_PAGE+'#d='+await b64enc(shareData(p));window.__link=link;
    aiSheet(`<h2>Share ${esc(p.name)}</h2><p>Anyone who opens this link on a phone with MediMate can add this profile, with its medicines and history. Only send it to people you trust.</p>${link.length>20000?'<p style="color:#b3261e">This link is long. Some apps may not send it fully.</p>':''}<div class="aib"><button class="p" onclick="shareLinkNow()"><span class="ms">share</span>Share</button><button onclick="copyLinkNow()"><span class="ms">content_copy</span>Copy link</button></div><div class="aib"><button onclick="aiClose()">Cancel</button></div>`);
  }catch(e){aiSheet(`<h2>Could not make the link</h2><p>Please try again.</p><div class="aib"><button class="p" onclick="aiClose()">OK</button></div>`)}
}
async function shareLinkNow(){const t='MediMate profile for '+(P()?P().name:'')+': '+window.__link;try{await MA().shareText({text:t})}catch(e){try{await navigator.share({text:t})}catch(x){toast('Could not open sharing')}}}
async function copyLinkNow(){try{await MA().copyText({text:window.__link});toast('Link copied');aiClose()}catch(e){try{await navigator.clipboard.writeText(window.__link);toast('Link copied');aiClose()}catch(x){toast('Could not copy the link')}}}
function cleanShared(o){
  if(!o||o.v!==1||typeof o.name!=='string'||!o.name.trim())return null;
  const t=(x,n)=>String(x==null?'':x).slice(0,n),dOk=x=>/^\d{4}-\d\d-\d\d$/.test(x||''),tOk=x=>/^\d\d:\d\d$/.test(x||''),idMap={};
  const meds=(Array.isArray(o.meds)?o.meds:[]).slice(0,200).filter(m=>m&&tOk(m.time)&&dOk(m.start)&&String(m.name||'').trim()).map((m,i)=>{idMap[Math.floor(Number(m.id))]=i+1;return{id:i+1,name:t(m.name,80),dose:t(m.dose,160),time:m.time,days:Math.max(1,Math.min(3650,Math.floor(Number(m.days))||1)),every:Math.max(1,Math.min(365,Math.floor(Number(m.every))||1)),start:m.start,notes:t(m.notes,200),review:!!m.review,nodur:!!m.nodur}});
  const taken={};Object.keys(o.taken&&typeof o.taken==='object'?o.taken:{}).slice(0,20000).forEach(k=>{const q=k.match(/^(\d{4}-\d\d-\d\d)_(\d+)$/);if(q&&o.taken[k]&&idMap[q[2]])taken[q[1]+'_'+idMap[q[2]]]=true});
  const now=Date.now(),hist=(Array.isArray(o.hist)?o.hist:[]).slice(0,500).filter(h=>h&&dOk(h.date)&&tOk(h.time)&&String(h.name||'').trim()).map((h,i)=>({id:now+i,date:h.date,name:t(h.name,80),time:h.time,dose:t(h.dose,160)}));
  const prn=(Array.isArray(o.prn)?o.prn:[]).slice(0,100).filter(x=>x&&String(x.name||'').trim()).map((x,i)=>({id:meds.length+i+1,name:t(x.name,80),dose:t(x.dose,160)}));
  const routine={};['breakfast','lunch','evening','dinner','bedtime'].forEach(k=>{if(tOk(o.routine&&o.routine[k]))routine[k]=o.routine[k]});
  const snooze={};Object.keys(o.snooze&&typeof o.snooze==='object'?o.snooze:{}).slice(0,500).forEach(k=>{if(/^\d{4}-\d\d-\d\d_\d+$/.test(k)&&Number(o.snooze[k])>Date.now()-86400000)snooze[k]=Number(o.snooze[k])});
  return{name:t(o.name,60).trim(),dob:dOk(o.dob)?o.dob:'',routine:routine,meds:meds,prn:prn,taken:taken,snooze:snooze,hist:hist,voiceAlerts:o.voiceAlerts!==false,alertVolume:Math.max(20,Math.min(100,Number(o.alertVolume)||90)),bestStreak:Math.max(0,Number(o.bestStreak)||0)};
}
async function mmOpenUrl(url){
  try{
    const m=String(url||'').match(/[#?&]d=([A-Za-z0-9_\-]+)/);if(!m)return;
    let seen='';try{seen=localStorage.getItem('mm_lasturl')||''}catch(e){}if(seen===m[1])return;
    const decoded=await b64dec(m[1]);
    const profiles=decoded&&decoded.v===2&&Array.isArray(decoded.profiles)?decoded.profiles.map(cleanShared).filter(Boolean):[cleanShared(decoded)].filter(Boolean);
    if(!profiles.length){toast('This link is not valid');return}
    window.__imp={profiles:profiles,key:m[1]};
    const meds=profiles.reduce((n,p)=>n+p.meds.length,0);
    aiSheet(`<h2>Restore backup?</h2><p><b>${profiles.length} profile(s)</b><br>${meds} medicine entries will be added to this phone.</p><p style="font-size:13px;color:#5f6368">Only restore a link from someone you trust. Existing profiles will be kept. This backup link is not encrypted. Profile PINs and recovery email addresses are not transferred.</p><div class="aib"><button onclick="impDone()">Cancel</button><button class="p" onclick="impAdd()">Restore all</button></div>`);
  }catch(e){toast('This link could not be opened')}
}
function impDone(){try{localStorage.setItem('mm_lasturl',window.__imp.key)}catch(e){}aiClose()}
function impAdd(){
  const xs=window.__imp&&window.__imp.profiles;if(!xs||!xs.length)return;
  xs.forEach((x,i)=>{const p=norm({id:Date.now()+i,name:x.name,dob:x.dob,routine:x.routine,agreed:Date.now(),termsVersion:TERMS_VERSION,meds:x.meds,prn:x.prn,taken:x.taken,snooze:x.snooze,hist:x.hist,voiceAlerts:x.voiceAlerts,alertVolume:x.alertVolume,bestStreak:x.bestStreak,nextId:x.meds.length+x.prn.length+1});store.profiles.push(p)});
  save();const n=xs.length;impDone();toast(n===1?'Profile restored':n+' profiles restored');try{renderChooser()}catch(e){}
}
window.addEventListener('load',()=>{try{const A=plug('App');if(A&&A.addListener){A.addListener('appUrlOpen',e=>mmOpenUrl(e.url));if(A.getLaunchUrl)A.getLaunchUrl().then(r=>{if(r&&r.url)setTimeout(()=>mmOpenUrl(r.url),800)}).catch(()=>{})}}catch(e){}});


// ---------- Link with MediMate (sends this profile's link to the MediMate team by email) ----------
const LINK_EMAIL='medimate.ab@gmail.com';
function linkState(p){return p&&p.linkState||''}
function setLinkState(p,v){if(p){p.linkState=v;try{save()}catch(e){}}}
function maybeAskLink(){
  const p=P();if(!p||linkState(p))return;
  setTimeout(()=>{const q=P();if(!q||q.id!==p.id||linkState(q))return;if(window.__introOn){(window.__afterIntro=window.__afterIntro||[]).push(maybeAskLink);return}const a=document.getElementById('ai-view'),r=document.getElementById('ring');if((a&&a.classList.contains('on'))||(r&&r.classList.contains('on')))return;showLinkAsk()},900);
}
function showLinkAsk(){
  const p=P();if(!p)return;
  aiSheet(`<div class="linkbadge"><span class="ms">link</span></div><h2 style="text-align:center">Link with MediMate</h2><p>Tap <b>Link</b> and your email app opens with a message to the MediMate team (<b>${LINK_EMAIL}</b>). Just press send. It contains a MediMate link for <b>${esc(p.name)}</b>'s profile, with medicines and history, so the team can help you if something goes wrong.</p><p style="font-size:13px;color:#5f6368">Nothing is sent unless you press send in your email app. The link is not encrypted. You can also do this later from the menu.</p><div class="aib"><button onclick="linkLater()">Not now</button><button class="p" onclick="linkGo()"><span class="ms">link</span>Link</button></div>`);
}
function linkLater(){setLinkState(P(),'skipped');aiClose()}
async function linkGo(){
  const p=P();if(!p)return;
  try{
    const link=SHARE_PAGE+'#d='+await b64enc(shareData(p));
    const body='Hello MediMate team,\n\nPlease link this profile with MediMate.\n\nProfile: '+p.name+'\nApp version: '+APP_VERSION+'\n\nProfile link:\n'+link+'\n\nSent from the MediMate app.';
    const subject='Link with MediMate - '+p.name;
    const m=MA();
    if(m&&m.composeEmail)await m.composeEmail({to:LINK_EMAIL,subject,body});
    else window.location.href='mailto:'+LINK_EMAIL+'?subject='+encodeURIComponent(subject)+'&body='+encodeURIComponent(body);
    setLinkState(p,'linked');aiClose();toast('Email ready. Press send to finish linking.',null,3500);
  }catch(e){toast('Could not open your email app')}
}

// ---------- update checker (looks at the newest release on GitHub) ----------
const REL_API='https://api.github.com/repos/abhinavvnm1529-cloud/Medimate-/releases/latest';
// lets the phone check once a day (tiny, non-waking) and show a notification when a new version exists
window.addEventListener('load',()=>{try{const m=MA();m&&m.setUpdateApi&&m.setUpdateApi({api:REL_API})}catch(e){}});
const verGt=(a,b)=>{const x=String(a).split('.').map(n=>parseInt(n,10)||0),y=String(b).split('.').map(n=>parseInt(n,10)||0);for(let i=0;i<Math.max(x.length,y.length);i++){const d=(x[i]||0)-(y[i]||0);if(d)return d>0}return false};
async function checkUpdate(manual){
  try{
    const ls=k=>{try{return localStorage.getItem(k)||''}catch(e){return ''}},ss=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
    if(!manual){
            const e=document.getElementById('ring'),a=document.getElementById('ai-view');if(window.__introOn||(e&&e.classList.contains('on'))||(a&&a.classList.contains('on')))return;
    }
    if(navigator.onLine===false){if(manual)toast('No internet connection');return}
    const ac=new AbortController(),t=setTimeout(()=>ac.abort(),10000);
    const r=await fetch(REL_API,{headers:{Accept:'application/vnd.github+json'},signal:ac.signal});clearTimeout(t);
    if(!r.ok)throw new Error('http');const j=await r.json();ss('mm_updchk',String(Date.now()));
    const m=String(j.tag_name||'').match(/^v?(\d+(?:\.\d+)*)$/),apk=(j.assets||[]).find(x=>/\.apk$/i.test(x.name));window.__releaseDate=j.published_at||j.created_at||'';
    if(m&&apk&&verGt(m[1],APP_VERSION)){
      const sk=ls('mm_updskip').split('|');
      window.__upd={ver:m[1],url:apk.browser_download_url,sha:String(apk.digest||'').replace(/^sha256:/,''),size:apk.size||0,notes:String(j.body||'').replace(/[#*`>]/g,'').trim().slice(0,400)};
      if(!manual&&S.autoUpdate&&window.__autoTried!==m[1]&&!ring.active&&!__updBusy){window.__autoTried=m[1];let ok=true;try{const mm=MA();if(!mm||!mm.downloadApk)ok=false;else{const c=await mm.canInstall();if(c&&c.ok===false)ok=false}}catch(e){}if(ok){toast('Updating MediMate to '+m[1]+'…',null,4000);updGo(true);return}}
      if(!manual&&sk[0]===m[1]&&Date.now()-(+sk[1]||0)<864e5)return;
      const mb=window.__upd.size?(window.__upd.size/1048576).toFixed(1)+' MB':'';
      aiSheet(`<h2>Update available</h2><p>MediMate <b>version ${esc(m[1])}</b>${mb?' ('+mb+')':''} is ready. You have version ${esc(APP_VERSION)}. Your medicines and history stay safe when you update.</p>${window.__upd.notes?`<p style="font-size:13px;color:#444746;white-space:pre-line;max-height:120px;overflow:auto">${esc(window.__upd.notes)}</p>`:''}<p style="font-size:13px;color:#5f6368">The update downloads inside MediMate, is checked for authenticity (checksum and developer signature), and then Android asks you to confirm the install.</p><div class="aib"><button onclick="updLater()">Later</button><button class="p" onclick="updGo()"><span class="ms">system_update</span>Update now</button></div>`);
    }else if(manual)aiSheet(`<h2>No updates available</h2><p>You are already using the latest MediMate version <b>${APP_VERSION}</b>.</p><div class="aib"><button class="p" onclick="aiClose()">OK</button></div>`);
  }catch(e){if(manual)toast('Could not check for updates')}
}
function updLater(){try{localStorage.setItem('mm_updskip',window.__upd.ver+'|'+Date.now())}catch(e){}aiClose();try{const m=MA();m&&m.notifyUpdate&&m.notifyUpdate({version:window.__upd.ver})}catch(e){}}
let __updHandle=null,__updBusy=false;
async function updGo(silent){
  const u=window.__upd&&window.__upd.url;if(!u)return;const ver=window.__upd.ver,sha=window.__upd.sha||'';
  const m=MA();
  if(!m||!m.downloadApk){aiClose();toast('Updating is only available in the installed app');return}
  const closeBtn=(label)=>{if(silent)return;const x=document.getElementById('ai-view');if(x&&!document.getElementById('up-close'))x.querySelector('.aibox').insertAdjacentHTML('beforeend','<div class="aib" id="up-close"><button onclick="aiClose()">Close</button><button class="p" onclick="updGo()">'+label+'</button></div>')};
  // 1) Make sure Android will let MediMate install before spending any data
  try{const c=await m.canInstall();if(c&&c.ok===false){
    aiSheet(`<h2>One quick permission</h2><p>To update itself, MediMate needs Android's "Install unknown apps" permission switched on for MediMate only. Tap the button, switch it on, then come back. The update starts by itself.</p><div class="aib"><button onclick="aiClose()">Later</button><button class="p" onclick="updAllow()">Open settings</button></div>`);return}}catch(e){}
  try{const cur=(document.querySelector('#nav button.on')||{dataset:{}}).dataset.s||'home';localStorage.setItem('mm_resume',JSON.stringify({t:Date.now(),tab:cur,pid:store.current}))}catch(e){}
  const t0=Date.now();__updBusy=true;
  if(!silent)aiSheet(`<h2>Updating MediMate…</h2><p id="up-msg">Starting download…</p><div style="height:12px;border-radius:7px;background:#dbe5f5;overflow:hidden;margin:12px 0"><div id="up-bar" style="height:100%;width:0%;background:linear-gradient(90deg,#1769d2,#4b93f0);border-radius:7px;transition:width .25s"></div></div><p id="up-eta" style="font-size:13px;color:#5f6368;margin:0">Calculating time…</p><div class="aib" id="up-cancel"><button onclick="updCancel()">Cancel</button></div>`);
  const setP=(pc,msg,eta)=>{const b=document.getElementById('up-bar'),g=document.getElementById('up-msg'),e=document.getElementById('up-eta');if(b)b.style.width=pc+'%';if(g&&msg)g.textContent=msg;if(e&&eta!==undefined)e.textContent=eta};
  const hideCancel=()=>{const c=document.getElementById('up-cancel');if(c)c.remove()};
  try{
    if(__updHandle){try{await __updHandle.remove()}catch(e){}}
    __updHandle=await m.addListener('updateProgress',d=>{
      if(silent){if(d.status==='installing')toast('Update ready. Confirm the install if Android asks.',null,9000);else if(d.status==='done'||d.status==='needpermission'||d.status==='cancelled')__updBusy=false;else if(d.status==='error'){__updBusy=false;toast('Automatic update did not finish. Use App settings > Check for updates.',null,7000)}return}
      if(d.status==='downloading'){
        const pc=d.total>0?Math.min(99,Math.floor(d.done*100/d.total)):0;
        const mbDone=(d.done/1048576).toFixed(1),mbTot=d.total>0?(d.total/1048576).toFixed(1):'?';
        let eta='Calculating time…';
        if(d.bps>0&&d.total>0){const left=Math.max(1,Math.round((d.total-d.done)/d.bps)),sp=(d.bps/1048576).toFixed(1)+' MB/s';eta=(left>=60?'About '+Math.ceil(left/60)+' min left':'About '+left+' sec left')+' · '+sp}
        setP(pc,'Downloading… '+pc+'% ('+mbDone+' / '+mbTot+' MB)',eta);
      }else if(d.status==='verifying'){hideCancel();setP(100,'Checking the update is genuine…','Verifying checksum and developer signature')}
      else if(d.status==='installing'){hideCancel();setP(100,'Verified. Android is asking you to confirm the install.','Tap Update / Install on the Android screen')}
      else if(d.status==='done'){__updBusy=false;setP(100,'Updated!','')}
      else if(d.status==='needpermission'){__updBusy=false;aiSheet(`<h2>One quick permission</h2><p>Switch on "Install unknown apps" for MediMate, then come back. The update continues by itself.</p><div class="aib"><button onclick="aiClose()">Later</button><button class="p" onclick="updAllow()">Open settings</button></div>`)}
      else if(d.status==='cancelled'){__updBusy=false;setP(0,d.message||'Update cancelled','');hideCancel();closeBtn('Try again')}
      else if(d.status==='error'&&/INCOMPATIBLE|signatures do not match|different developer key/i.test(d.message||'')){__updBusy=false;updReinstall()}
      else if(d.status==='error'){__updBusy=false;hideCancel();setP(0,'Update failed: '+(d.message||'please try again'),'Your data is untouched.');closeBtn('Try again')}
    });
    await m.downloadApk({url:u,version:ver,sha256:sha});
  }catch(e){__updBusy=false;setP(0,'Could not start the update','');hideCancel();closeBtn('Try again')}
}
function updReinstall(){
  aiSheet(`<h2>One-time reinstall needed</h2><p>This copy of MediMate was installed from an older build that was signed with a different key, so Android refuses to update it in place. Your data is safe if you follow these steps once:</p><p style="font-size:14px;line-height:1.5"><b>1.</b> Back up your profiles (Menu &gt; Backup) and save the text somewhere safe.<br><b>2.</b> Uninstall MediMate (App settings &gt; Uninstall).<br><b>3.</b> Install the latest version from the download page.<br><b>4.</b> Restore from your backup. Future updates then work normally.</p><div class="aib"><button onclick="aiClose();openBackup()"><span class="ms">backup</span>Back up</button></div><div class="aib"><button onclick="try{MA().openAppSettings()}catch(e){}"><span class="ms">settings</span>App settings</button></div><div class="aib"><button class="p" onclick="try{MA().openUrl({url:'https://github.com/abhinavvnm1529-cloud/Medimate-/releases/latest'})}catch(e){}"><span class="ms">download</span>Download page</button></div>`);
}
async function updCancel(){try{await MA().cancelUpdate()}catch(e){}}
async function updAllow(){window.__updWait=true;try{await MA().allowInstalls()}catch(e){toast('Open Settings > Apps > MediMate > Install unknown apps')}}
// after the user returns from the permission screen, carry on with the update automatically
document.addEventListener('visibilitychange',async()=>{
  if(document.hidden||!window.__updWait)return;window.__updWait=false;
  try{const c=await MA().canInstall();if(c&&c.ok&&window.__upd)updGo()}catch(e){}
});
// After an update, show the MediMate logo splash once
(function(){try{const pv=localStorage.getItem('mm_lastver');if(pv&&pv!==APP_VERSION){window.__justUpdated=true}localStorage.setItem('mm_lastver',APP_VERSION)}catch(e){}})();
window.addEventListener('load',()=>{if(!window.__justUpdated)return;const d=document.createElement('div');d.style.cssText='position:fixed;inset:0;z-index:99999;background:#f8fafd;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;transition:opacity .6s';d.innerHTML='<svg viewBox="0 0 100 100" style="width:96px;height:96px"><use href="#mlogo"/></svg><b style="font:600 20px sans-serif;color:#1769d2">MediMate updated to '+APP_VERSION+'</b>';document.body.appendChild(d);setTimeout(()=>{d.style.opacity='0';setTimeout(()=>d.remove(),650)},1100);setTimeout(()=>{try{const a=document.getElementById('ai-view');if(!ring.active&&!(a&&a.classList.contains('on')))showWhatsNew()}catch(e){}},3200)});
window.addEventListener('load',()=>setTimeout(()=>checkUpdate(false),1800));
document.addEventListener('visibilitychange',()=>{if(document.hidden)return;let t=0;try{t=+localStorage.getItem('mm_updchk')||0}catch(e){}if(Date.now()-t>21600000)setTimeout(()=>checkUpdate(false),2500)});

function previewHaptic(){try{const m=MA();if(m&&m.haptic)m.haptic({kind:'click'});else if(navigator.vibrate)navigator.vibrate(60)}catch(e){}}
function showAbout(){const email='Medimate.ab@gmail.com';const subject=encodeURIComponent('MediMate feedback');const body=encodeURIComponent('Hello MediMate developers,\n\nI would like to share feedback about MediMate:\n\n');const mail='mailto:'+email+'?subject='+subject+'&body='+body;aiSheet(`<h2>About MediMate</h2><p><b>Version ${APP_VERSION}</b></p><p>MediMate is an app developed by Abhinav and Bavesh, Grade 8B, Velammal New Gen Annex School, with the aim of helping people take their medicines on time and maintain a proper medication schedule.</p><p>Our goal is to make medicine management simpler, easier, and more reliable, helping users stay on track with their prescribed medicines and avoid missing scheduled doses.</p><p>If you encounter any issues while using MediMate, or if you are happy with your experience, we kindly request you to share your feedback or write a review using the email account provided below.</p><p>Your feedback and suggestions are valuable to us. They help us identify areas for improvement and make MediMate better, more reliable, and more helpful for everyone.</p><p><b>Thank you for using MediMate!</b></p><div style=\"margin:12px 0;padding:14px;border-radius:18px;background:var(--grp);text-align:center\"><a href=\"${mail}\" style=\"color:var(--prim);font-weight:600;text-decoration:none;overflow-wrap:anywhere\">${email}</a></div><div class=\"aib\"><button class=\"p\" onclick=\"window.location.href='${mail}'\"><span class=\"ms\">mail</span>Send feedback / review</button><button onclick=\"showWhatsNew()\"><span class=\"ms\">new_releases</span>What's new</button><button onclick=\"aiClose()\">Done</button></div>`)}
function showVersionInfo(){aiSheet(`<h2>MediMate version</h2><p><b>Running version:</b> ${APP_VERSION}</p><p><b>Release date:</b> ${APP_RELEASE_DATE}</p><div class="aib"><button onclick="showWhatsNew()">What's new</button><button class="p" onclick="aiClose()">OK</button></div>`)}

function aiSheet(h){clearInterval(AI._tm);let v=document.getElementById('ai-view');if(!v){v=document.createElement('div');v.id='ai-view';document.body.appendChild(v)}v.innerHTML='<div class="aibox">'+h+'</div>';v.classList.add('on');v.scrollTop=0}
function aiClose(){const v=document.getElementById('ai-view');if(v)v.classList.remove('on')}
function aiSetup(){
  aiSheet(`<h2>AI schedule service</h2><p>Enter the address and access code given by the app owner. They are saved only on this device.</p>
  <input type="text" id="ai-url" placeholder="https://your-service.workers.dev" value="${esc(AI.url)}" autocapitalize="none" autocomplete="off">
  <input type="password" id="ai-code" placeholder="Access code" value="${esc(AI.code)}" autocomplete="off">
  <p class="hint">AI photo-scan privacy and limitations are covered in Terms and Privacy Policy, section 7A. The selected image is sent to the configured service for text extraction.</p>
  <div class="aib"><button onclick="aiClose()">Cancel</button><button class="p" onclick="aiSaveCfg()">Save</button></div>`);
}
function aiSaveCfg(){
  const u=$('ai-url').value.trim(),c=$('ai-code').value.trim();
  if(!/^https:\/\/[^\s]+$/.test(u)){toast('The address must start with https://');return}
  if(c.length<8){toast('Enter the access code');return}
    AI.url=u.replace(/\/+$/,'');AI.code=c;AI.ok=true;saveAI();aiClose();toast('AI service saved');if(document.getElementById('set-view')&&document.getElementById('set-view').classList.contains('on'))renderSettings();
}
function aiStart(){
  if(!P())return;if(!AI.url||!AI.code){aiSetup();return}
  AI.ok=true;saveAI();aiOpenPicker();
}
function aiConsent(){
  aiSheet(`<h2>Before you scan</h2><p>The photo you choose is sent to Google Gemini, through the app owner's private service, to read it. MediMate does not store it.</p><p>AI can make mistakes. You will check every result before anything is added. By continuing, you confirm you are an adult, or a parent or guardian who will check it.</p><div class="aib"><button onclick="aiClose()">Cancel</button><button class="p" onclick="AI.ok=true;saveAI();aiClose();aiOpenPicker()">I agree</button></div>`);
}
async function aiOpenPicker(){
  if(!(await aiNetCheck()))return;
  aiSheet(`<h2>Scan prescription</h2><p>How do you want to add it?</p><div class="aib"><button class="p" onclick="aiFile(true)"><span class="ms">photo_camera</span>Camera</button><button class="p" onclick="aiFile(false)"><span class="ms">folder_open</span>Files</button></div><div class="aib"><button onclick="aiClose()">Cancel</button></div>`);
}
function aiFile(cam){
  aiClose();const old=document.getElementById('ai-file');if(old)old.remove();
  const f=document.createElement('input');f.type='file';f.id='ai-file';f.accept=cam?'image/*':'image/*,application/pdf';
  if(cam)f.setAttribute('capture','environment');f.style.display='none';f.onchange=()=>aiPick(f);document.body.appendChild(f);f.click();
}
function aiSpin(msg){aiSheet(`<div style="text-align:center;padding:10px 0"><svg class="aispin" viewBox="0 0 50 50" width="48" height="48"><circle class="aispinc" cx="25" cy="25" r="20" fill="none" stroke="#0b57d0" stroke-width="5" stroke-linecap="round"/></svg><p style="margin:14px 0 0">${msg}</p></div>`)}
async function aiNetCheck(){
  aiSpin('Connecting\u2026');await new Promise(r=>setTimeout(r,450));
  if(navigator.onLine===false){aiSheet(`<h2>No internet</h2><p>Wi-Fi is currently not available. Please try again.</p><div class="aib"><button class="p" onclick="aiClose()">OK</button></div>`);return false}
  return true;
}
function aiBusy(msg){
  aiSheet(`<h2>${msg}</h2><div style="height:5px;background:#dcecff;border-radius:8px;overflow:hidden;margin:22px 0 10px"><div id="aiclipr" style="height:100%;width:0;background:linear-gradient(90deg,#4285f4,#34a853,#fbbc04,#ea4335);border-radius:8px;transition:width .35s ease"></div></div><p id="aipct" style="color:#5f6368;margin:0">Starting…</p><p style="font-size:13px;color:#5f6368;margin-top:14px">This usually takes around a minute. Please keep MediMate open while the prescription is being read.</p>`);
  AI._t0=Date.now();AI._pc=0;
  AI._tm=setInterval(()=>{const t=(Date.now()-AI._t0)/1000;AI._pc=Math.min(94,94*(1-Math.exp(-t/7)));aiProg(AI._pc)},120);
}
function aiProg(p){const r=document.getElementById('aiclipr'),t=document.getElementById('aipct');if(r)r.style.width=Math.min(100,p)+'%';if(t)t.textContent=p>=100?'Done':'Reading\u2026 '+Math.round(p)+'%'}
function aiBusyEnd(){clearInterval(AI._tm);aiProg(100);return new Promise(r=>setTimeout(r,450))}
function aiScanHelp(){aiSheet(`<h2>Need help with the scan?</h2><p>Please share the prescription photo with an LLM and ask it to prepare a clear medicine timetable PDF. Carefully verify every medicine name, strength, dose, date and time against the original prescription with a parent, guardian, doctor or pharmacist before using it.</p><div class="aib"><button class="p" onclick="aiClose()">Got it</button></div>`)}
const aiFail=(h,msg)=>aiSheet(`<div style="display:flex;align-items:center;justify-content:space-between"><h2>${h}</h2><button class="iconbtn" aria-label="Scan help" onclick="aiScanHelp()"><span class="ms" style="font-size:24px;color:#1769d2">help</span></button></div><p>${esc(msg)}</p><div class="aib"><button onclick="aiClose()">Close</button><button class="p" onclick="aiClose();openEdit(null)">Add manually</button></div>`);
// accepts 8:00, 08.00, 8 pm, 8:30pm, 20:00 ... and returns HH:MM (or '' if it is not a time)
function normTime(t){
  const m=String(t==null?'':t).trim().toLowerCase().match(/^(\d{1,2})(?:[:.h](\d{2}))?\s*(a\.?m?\.?|p\.?m?\.?)?$/);
  if(!m)return '';
  let h=+m[1];const mi=m[2]?+m[2]:0,ap=m[3]?m[3][0]:'';
  if(mi>59||h>24||(ap&&(h<1||h>12)))return '';
  if(ap==='p'&&h<12)h+=12;if(ap==='a'&&h===12)h=0;
  return h>23?'':pad(h)+':'+pad(mi);
}
function aiExplain(status,j){
  const e=String(j&&j.error||'');
  if(status===401||status===403)return 'The access code was not accepted. Check it in App settings.';
  if(status===404&&!e)return 'The AI service address was not found. Check the address in App settings.';
  if(/\(404\)|not found|no longer available/i.test(e))return 'The AI model used by the service is no longer available. The service needs to be updated.';
  if(status===429||/quota|rate|busy/i.test(e))return 'The AI service is busy or its limit is used up. Try again later.';
  return e||'The AI service had a problem (code '+status+'). Try again, or add the medicine manually.';
}
function aiPrep(file){
  return new Promise((res,rej)=>{
    if(file.type==='application/pdf'){const r=new FileReader();r.onload=()=>res({mime:'application/pdf',data:String(r.result).split(',')[1]});r.onerror=()=>rej(new Error('bad file'));r.readAsDataURL(file);return}
    const img=new Image(),u=URL.createObjectURL(file);
    img.onload=()=>{const k=Math.min(1,1600/Math.max(img.width,img.height)),c=document.createElement('canvas');c.width=Math.round(img.width*k);c.height=Math.round(img.height*k);c.getContext('2d').drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(u);res({mime:'image/jpeg',data:c.toDataURL('image/jpeg',.9).split(',')[1]})};
    img.onerror=()=>{URL.revokeObjectURL(u);rej(new Error('bad image'))};img.src=u;
  });
}
async function aiPick(f){
  const file=f.files&&f.files[0];f.value='';if(!file)return;
  if(file.size>(file.type==='application/pdf'?10:25)*1048576){aiFail('File too large','Please choose a photo or PDF under '+(file.type==='application/pdf'?'10':'25')+' MB.');return}
  if(navigator.onLine===false){aiFail('No internet','Connect to the internet and try again, or add the medicine manually.');return}
  aiBusy('Reading your prescription\u2026');
  try{
    const body=await aiPrep(file);let r=null,j={};
    for(let n=0;n<2;n++){                       // one automatic retry when the service is briefly overloaded
      const ac=new AbortController(),t=setTimeout(()=>ac.abort(),100000);
      try{r=await fetch(AI.url,{method:'POST',headers:{'Content-Type':'application/json','X-App-Token':AI.code},body:JSON.stringify(body),signal:ac.signal});j=await r.json().catch(()=>({}))}
      finally{clearTimeout(t)}
      if(r.status!==502&&r.status!==503&&r.status!==504)break;
      await new Promise(x=>setTimeout(x,1500));
    }
    if(!r.ok){aiFail('Could not read it',aiExplain(r.status,j));return}
    AI.list=(Array.isArray(j.medicines)?j.medicines:[]).filter(m=>m&&m.name).map(m=>({
      name:String(m.name),dose:String(m.dose||''),notes:String(m.notes||''),
      times:(Array.isArray(m.times)&&m.times.length)?m.times.map(normTime):[''],days:m.days?String(m.days):'',start:/^\d{4}-\d\d-\d\d$/.test(m.startDate||'')?m.startDate:'',end:/^\d{4}-\d\d-\d\d$/.test(m.endDate||'')?m.endDate:''}));
    if(!AI.list.length){aiFail('No medicines found','Try a clearer, well-lit photo of the whole prescription.');return}
    await aiBusyEnd();aiReview();
  }catch(e){
    if(e&&e.name==='AbortError')aiFail('Took too long','The AI service did not answer in time. Try again with a smaller or clearer photo.');
    else if(e&&/bad (image|file)/.test(e.message))aiFail('Could not open the file','Choose a JPG, PNG or PDF. Photos in other formats (for example HEIC) may need to be converted first.');
    else aiFail('Could not reach the AI service','Check your internet and the address in App settings.');
  }
}
function aiRK(k){const q=k.split('|');return{start:q[0],end:q[1]}}
function aiToggleEdit(){AI.edit=!AI.edit;aiReview()}
function aiDel(i,t){const m=AI.list[i];if(!m)return;m.times=m.times.filter(x=>x!==t);if(!m.times.length||!m.times.some(x=>/^\d\d:\d\d$/.test(x)))AI.list.splice(i,1);aiReview()}
function aiAdd(k,t){const r=aiRK(k);AI.list.push({name:'',dose:'',notes:'',times:[t],days:'',start:r.start,end:r.end});AI._new=AI.list.length-1;aiReview();setTimeout(()=>{const e=document.querySelector('#ai-view .ar.new input');if(e)e.focus()},60)}
function aiReview(){
  const ok=t=>/^\d\d:\d\d$/.test(t),iso0=(()=>{const d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())})(),dt=x=>parseD(x).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'});
  const R={};
  AI.list.forEach((m,i)=>{const k=(m.start||'')+'|'+(m.end||'');(R[k]=R[k]||{k:k,start:m.start||'',end:m.end||'',t:{}});m.times.filter(ok).forEach(t=>{(R[k].t[t]=R[k].t[t]||[]).push(i)})});
  const nt=AI.list.filter(m=>!m.times.some(ok)),E=!!AI.edit;
  const heads=Object.values(R).sort((x,y)=>(x.start||'9').localeCompare(y.start||'9'));
  aiSheet(`<h2>Your schedule</h2><p>${E?'Tap + to add a medicine under a time, or the bin to remove one.':'<b>AI can make mistakes.</b> Check the dates, times and doses, then tap the tick.'}</p>`+
  heads.filter(r=>Object.keys(r.t).length).map(r=>{const fin=r.end&&r.end<iso0;return `<div class="aic"><b style="color:#0b57d0;font-size:15px">${r.start&&r.end?dt(r.start)+' \u2013 '+dt(r.end):r.start?'From '+dt(r.start):r.end?'Until '+dt(r.end):'Every day, starting today'}</b>${fin?'<div style="color:#b3261e;font-size:13px">Already finished \u2013 will be skipped</div>':(r.start&&r.start<iso0?'<div style="color:#5f6368;font-size:13px">Starts today (earlier days are skipped)</div>':'')}`+
    Object.keys(r.t).sort().map(t=>`<div style="padding:8px 0 2px;border-top:1px solid #eef2fa;margin-top:8px"><div style="display:flex;align-items:center;justify-content:space-between"><b style="font-size:17px">${fmt(t)}</b>${E?`<button class="aip" aria-label="Add medicine at ${fmt(t)}" onclick="aiAdd('${r.k}','${t}')"><span class="ms">add</span></button>`:''}</div>`+
      r.t[t].map(i=>{const m=AI.list[i];return E?`<div class="ar ${AI._new===i?'new':''}"><div style="flex:1"><input type="text" value="${esc(m.name)}" placeholder="Medicine name" oninput="AI.list[${i}].name=this.value"><input type="text" value="${esc(m.dose)}" placeholder="Dose" oninput="AI.list[${i}].dose=this.value"></div><button class="aip" aria-label="Delete" onclick="aiDel(${i},'${t}')"><span class="ms">delete</span></button></div>`:`<div style="padding:4px 0"><b>${esc(m.name)}</b>${m.dose?'<br><small>'+esc(m.dose)+'</small>':''}</div>`}).join('')+`</div>`).join('')+`</div>`}).join('')+
  (nt.length?`<p>No time found for: ${nt.map(m=>esc(m.name)).join(', ')}.</p>`:'')+
  `<div class="aib"><button onclick="aiClose()">Cancel</button><button onclick="aiToggleEdit()">${E?'Done':'Edit'}</button>${E?'':'<button class="p" aria-label="Add to schedule" onclick="aiConfirm()"><span class="ms">check</span>Add</button>'}</div>`);
}
function aiEdit(){
  aiSheet(`<h2>Check before adding</h2><p><b>AI can make mistakes.</b> Compare every line with the prescription and fix anything wrong. Leave days empty for no end date.</p>`+
  AI.list.map((m,i)=>`<div class="aic"><input type="text" value="${esc(m.name)}" placeholder="Medicine name" oninput="AI.list[${i}].name=this.value">
  <input type="text" value="${esc(m.dose)}" placeholder="Dose / how to take" oninput="AI.list[${i}].dose=this.value">
  <small>Start date</small><input type="date" value="${esc(m.start||'')}" onchange="AI.list[${i}].start=this.value">
  <small>End date (optional)</small><input type="date" value="${esc(m.end||'')}" onchange="AI.list[${i}].end=this.value">
  ${m.times.map((t,j)=>`<input type="time" value="${esc(t)}" onchange="AI.list[${i}].times[${j}]=this.value">`).join('')}
  <input type="number" min="1" max="365" value="${esc(m.days)}" placeholder="Days (empty = no end date)" oninput="AI.list[${i}].days=this.value">
  <div class="aib" style="margin-top:0"><button onclick="AI.list[${i}].times.push('');aiReview()">+ Add time</button><button onclick="AI.list.splice(${i},1);aiReview()">Remove</button></div></div>`).join('')+
  `<div class="aib"><button onclick="aiReview()">Back</button><button class="p" onclick="aiConfirm()">Add to schedule</button></div>`);
}
function aiConfirm(){
  const p=P();if(!p)return;const d=new Date(),iso=d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());let n=0,bad=0,old=0;
  AI.list.forEach(m=>{
    const name=String(m.name||'').trim();if(!name)return;
    const times=[...new Set(m.times.filter(t=>/^\d\d:\d\d$/.test(t)))];if(!times.length){bad++;return}
    const dOk=x=>/^\d{4}-\d\d-\d\d$/.test(x||''),s0=dOk(m.start)&&m.start>iso?m.start:iso;let days;if(dOk(m.end)&&m.end<iso){old++;return}
    if(dOk(m.end)){const dd=Math.round((parseD(m.end)-parseD(s0))/864e5)+1;days=dd>0?Math.min(3649,dd):1}else{const dn=parseInt(m.days,10);days=dn>0?Math.min(3649,dn):3650}
    times.forEach(t=>{p.meds.push({id:p.nextId++,name,dose:String(m.dose||'').trim(),time:t,days,every:1,start:s0,notes:String(m.notes||'').trim(),review:profileAge(p.dob)<=18,nodur:false});n++});
  });
  if(!n){toast(old?'These courses have already finished':'Add a time for at least one medicine');return}
  save();render();aiClose();AI.list=[];toast('Added '+n+' reminder'+(n>1?'s':'')+(bad?' ('+bad+' skipped: no time)':'')+(old?' ('+old+' finished courses skipped)':''));if(profileAge(p.dob)<=18)setTimeout(reviewNudge,4800);
}
function sound(){
  stopSound();$('ring').classList.remove('quiet');
  playToneAudio();speakReminder();ring.voiceT=setInterval(speakReminder,18000);
  const vib=()=>{try{navigator.vibrate&&navigator.vibrate([500,250,500,250,700])}catch(e){}};vib();ring.vib=setInterval(vib,2600);
  ring.stopT=setTimeout(silence,90000);
}
function startRing(p,list,test){
  if(ring.active){
    // a new dose for the same person joins the ringing screen instead of being blocked
    if(test||ring.test||ring.pid!==p.id)return false;
    list.forEach(m=>{if(!ring.meds.some(x=>x.id===m.id))ring.meds.push(m)});
    ringList();sound();return true;
  }
  Object.assign(ring,{active:true,pid:p.id,meds:list.slice(),start:Date.now(),test:!!test,reps:0});
  const n=new Date();
  $('r-time').textContent=test?String(p.name||'Profile'):fmt(pad(n.getHours())+':'+pad(n.getMinutes()));
  $('r-who').textContent='For '+p.name+' · '+(profileAge(p.dob)<=18?'Ask a parent or guardian to help':'Check the prescription instructions');
  $('ring').querySelector('.r-top').textContent=test?'TEST RINGTONE':'MEDICINE TIME · PLEASE CHECK YOUR INSTRUCTIONS';
  $('sl-sn').textContent=test?'Close':'Snooze 10 min';$('sl-tk').textContent=test?'Close':'Taken';$('r-hint').textContent=test?'Slide either way to close · hold the middle button 3 seconds to cancel':'Slide right when taken · left to snooze · hold the middle 3 seconds to cancel';
  slideReset(true);ringList();$('ring').classList.add('on');motionStart();document.querySelector('.phone').classList.add('ringing');if(test)playSelectedPreviewForTest();else sound();
  if(!test){try{const m=MA();if(m&&m.stopAlarm)m.stopAlarm()}catch(e){}}   // phone's own alarm sound stops so only one sound plays
  try{if('Notification' in window&&Notification.permission==='granted')new Notification(APP,{body:list.map(m=>m.name).join(', ')})}catch(e){}
  return true;
}
// Silence only stops the noise. If nobody acknowledges it, it retries after 3 minutes (up to 5 times).
function silence(){
  stopSound();$('ring').classList.add('quiet');
  if(ring.active&&!ring.test&&ring.reps<5)ring.rt=setTimeout(()=>{if(ring.active){ring.reps++;sound()}},180000);
}
function endRing(){stopSound();motionStop();ring.active=false;$('ring').classList.remove('on','quiet');document.querySelector('.phone').classList.remove('ringing');if(needLock){const id=needLock;needLock=0;lockNow(id)}}
function ringTaken(){
  const p=store.profiles.find(x=>x.id===ring.pid);
  if(p&&!ring.test&&profileAge(p.dob)<=18){
    // a child's dose: a parent or guardian confirms first
    const names=ring.meds.map(m=>esc(m.name)).join(', ');
    aiSheet(`<h2>Confirm taken?</h2><p>Record ${names} as taken only after confirming they were actually taken as prescribed. A parent or guardian must check and supervise.</p><div class="aib"><button onclick="aiClose();slideReset()">Cancel</button><button class="p" onclick="confirmTakenNow()">Confirm</button></div>`);
    return;
  }
  if(p&&!ring.test){confirmTakenNow();return}
  endRing();if(P())render();ringFinish();
}
// records the dose with the exact time it was taken, then closes the app again if the alarm had opened it by itself
function confirmTakenNow(){
  const p=store.profiles.find(x=>x.id===ring.pid),nowTs=Date.now();
  if(p&&!ring.test){ring.meds.forEach(m=>markTaken(p,dkey(midnight()),m.id,nowTs));delete_snoozes(p,ring.meds);save()}
  aiClose();endRing();if(P())render();
  ringFinish().then(closing=>{if(!closing){toast('Marked as taken at '+fmt(nowHM(nowTs)));setTimeout(maybeAskReview,2200)}});
}
function delete_snoozes(p,meds){meds.forEach(m=>{delete p.snooze[dkey(midnight())+'_'+m.id]})}
async function ringFinish(){
  try{
    const m=MA();if(!m||!m.finishAlarm)return false;
    const r=await m.finishAlarm();
    if(r&&r.closing){document.body.classList.add('closing');setTimeout(()=>document.body.classList.remove('closing'),4000);return true}
  }catch(e){}
  return false;
}
function ringSnooze(){
  const p=store.profiles.find(x=>x.id===ring.pid),list=ring.meds.slice(),test=ring.test;
  endRing();
  if(p&&!test){
    const until=Date.now()+600000;     // saved, so a reload does not lose the snooze
    list.forEach(m=>{p.snooze[dkey(midnight())+'_'+m.id]=until;delete fired[fkey(p,m)]});
    save();
  }
  ringFinish().then(closing=>{if(closing)return;if(p&&!test)toast('Snoozed for 10 minutes');else if(test)toast('Snooze works like this for real reminders')});
}
// ---- slide to answer (right = taken, left = snooze) ----
const SL={on:false,x0:0,max:0,dx:0,done:false,tick:false};
function slideReset(instant){
  const sl=$('slide'),th=$('sl-thumb');if(!sl||!th)return;
  SL.on=false;SL.done=false;SL.dx=0;SL.tick=false;
  if(instant)sl.classList.remove('rest');else sl.classList.add('rest');
  th.style.transform='translateX(0)';delete sl.dataset.dir;sl.setAttribute('aria-valuenow','0');
}
function slideCommit(dir){
  if(SL.done)return;SL.done=true;hap('click');
  const th=$('sl-thumb'),sl=$('slide');sl.classList.add('rest');
  th.style.transform='translateX('+(dir>0?SL.max:-SL.max)+'px)';
  setTimeout(()=>{dir>0?ringTaken():ringSnooze()},180);
}
(function(){
  const sl=$('slide'),th=$('sl-thumb');if(!sl||!th)return;
  const calc=()=>{SL.max=Math.max(40,(sl.getBoundingClientRect().width-th.offsetWidth)/2-6)};
  th.addEventListener('pointerdown',e=>{
    if(SL.done)return;SL.on=true;SL.x0=e.clientX;SL.dx=0;SL.tick=false;calc();sl.classList.remove('rest');
    try{th.setPointerCapture(e.pointerId)}catch(x){}
    hap('tick');holdStart();e.preventDefault();
  });
  th.addEventListener('pointermove',e=>{
    if(!SL.on||SL.done)return;
    if(Math.abs(e.clientX-SL.x0)>14)holdStop();
    SL.dx=Math.max(-SL.max,Math.min(SL.max,e.clientX-SL.x0));
    th.style.transform='translateX('+SL.dx+'px)';
    const dir=SL.dx>8?'r':SL.dx<-8?'l':'';if(dir)sl.dataset.dir=dir;else delete sl.dataset.dir;
    if(!SL.tick&&Math.abs(SL.dx)>SL.max*.5){SL.tick=true;hap('tick')}
    sl.setAttribute('aria-valuenow',String(Math.round(SL.dx/SL.max*100)));
  });
  const end=e=>{
    holdStop();if(!SL.on)return;SL.on=false;try{th.releasePointerCapture(e.pointerId)}catch(x){}
    if(Math.abs(SL.dx)>=SL.max*.8)slideCommit(SL.dx>0?1:-1);else slideReset();
  };
  th.addEventListener('pointerup',end);th.addEventListener('pointercancel',end);
  sl.addEventListener('click',e=>e.stopPropagation());
  sl.addEventListener('keydown',e=>{            // keyboard / screen-reader fallback
    if(e.key==='ArrowRight'){calc();slideCommit(1);e.preventDefault()}
    else if(e.key==='ArrowLeft'){calc();slideCommit(-1);e.preventDefault()}
  });
})();
function testRing(){closeDrawer();unlockAudio();const p=P();if(!p)return;const m=p.meds[0];startRing(p,[{id:-1,name:m?m.name:'Sample medicine',dose:m&&m.dose?m.dose:'Your real reminders will look like this'}],true)}
// Test mode uses the selected ringtone from settings; spoken-alert test remains profile-aware.

// "lift to silence": picking the phone up makes the ringing stop
let lastAcc=null,motionOn=false,motionAllowed=(typeof DeviceMotionEvent!=='undefined')&&!DeviceMotionEvent.requestPermission;
function onMotion(e){
  if(!ring.active)return;const a=e.accelerationIncludingGravity;if(!a)return;
  const mag=Math.sqrt((a.x||0)**2+(a.y||0)**2+(a.z||0)**2);
  if(lastAcc!==null&&Math.abs(mag-lastAcc)>3.5&&Date.now()-ring.start>1500)silence();
  lastAcc=mag;
}
// the motion sensor is switched on only while a reminder is ringing, so it never drains the battery
function motionStart(){if(motionOn||!motionAllowed)return;motionOn=true;lastAcc=null;window.addEventListener('devicemotion',onMotion)}
function motionStop(){if(!motionOn)return;motionOn=false;window.removeEventListener('devicemotion',onMotion)}
function enableMotion(){
  try{if(typeof DeviceMotionEvent==='undefined')return;
    if(DeviceMotionEvent.requestPermission)DeviceMotionEvent.requestPermission().then(r=>{if(r==='granted')motionAllowed=true}).catch(()=>{});
    else motionAllowed=true}catch(e){}
}
function askPermission(){try{if('Notification' in window&&Notification.permission==='default'){const permission=Notification.requestPermission();if(permission&&permission.catch)permission.catch(()=>{})}}catch(e){}}

// ---------- phone notifications (after converting to an APK) ----------
// Works with Capacitor "@capacitor/local-notifications" or Cordova "cordova-plugin-local-notification".
// In a normal browser these plugins do not exist, so this simply does nothing there.
const plug=n=>{try{const C=window.Capacitor;if(!C)return null;return (C.Plugins&&C.Plugins[n])||(C.registerPlugin?C.registerPlugin(n):null)}catch(e){return null}};
const LN=()=>plug('LocalNotifications');
const CDV=()=>{try{return window.cordova&&window.cordova.plugins&&window.cordova.plugins.notification&&window.cordova.plugins.notification.local||null}catch(e){return null}};
let schedT=null,lnReady=false;
function scheduleNative(){clearTimeout(schedT);schedT=setTimeout(doSchedule,500)}
// "Early" reminders already sent for a dose that was added less than 15 minutes before its time (so they fire once, not on every save)
let ES={};try{ES=JSON.parse(localStorage.getItem('mm_early_sent')||'{}')||{}}catch(e){ES={}}
function nativeItems(){
  const out=[],now=Date.now(),multi=store.profiles.length>1,early=S.early===true,DAYS=21,EARLY_MS=15*60000;let esChanged=false;
  Object.keys(ES).forEach(k=>{if(ES[k]<now-2*864e5){delete ES[k];esChanged=true}});
  store.profiles.forEach(p=>{
    const who=multi?' for '+p.name:'';
    for(let i=0;i<DAYS;i++){
      const d=addDays(midnight(),i),dk=dkey(d),groups={};
      medsOf(p,d).forEach(m=>{
        if(m.review||p.taken[dk+'_'+m.id])return;
        const [h,mi]=m.time.split(':').map(Number);
        const at=new Date(d.getFullYear(),d.getMonth(),d.getDate(),h,mi,0);
        if(at.getTime()<=now+3000)return;
        out.push({k:p.id+'_'+dk+'_'+m.id,kind:'alarm',at,title:'MediMate · '+p.name,body:m.name+(m.dose?' · '+m.dose:'')+who,profileId:p.id,medicineId:m.id,profileName:p.name,medicineName:m.name,dose:m.dose||'',time:m.time,
          taken:JSON.stringify([{profileId:p.id,medicineId:m.id,dateKey:dk}])});
        if(early){
          const ea=at.getTime()-EARLY_MS;let eat=0;
          if(ea>now+3000)eat=ea;
          else if(at.getTime()-now>120000){
            // the dose is less than 15 minutes away (added late, or the switch was turned on late): remind right away, once
            const gk=p.id+'_'+dk+'_'+m.time;let rec=ES[gk];
            if(!rec){rec=ES[gk]=now+2500;esChanged=true}
            if(rec>now+500)eat=rec;
          }
          if(eat){const g=groups[m.time+'|'+eat]=groups[m.time+'|'+eat]||{at:new Date(eat),doseAt:at.getTime(),time:m.time,ms:[]};g.ms.push(m)}
        }
      });
      Object.keys(groups).forEach(gk=>{
        const g=groups[gk],mins=Math.max(1,Math.round((g.doseAt-g.at.getTime())/60000));
        out.push({kind:'early',at:g.at,title:'MediMate · '+fmt(g.time)+' in '+mins+' min',body:g.ms.map(m=>m.name+(m.dose?' · '+m.dose:'')).join('\n')+who,profileId:p.id,medicineId:g.ms[0].id,profileName:p.name,medicineName:g.ms[0].name,dose:'',time:g.time,
          mk:g.ms.map(m=>p.id+'_'+dk+'_'+m.id),takenList:g.ms.map(m=>({profileId:p.id,medicineId:m.id,dateKey:dk}))});
      });
    }
    Object.keys(p.snooze).forEach(k=>{                       // snoozed doses ring again
      const until=p.snooze[k],mid=Number(k.split('_').pop()),m=p.meds.find(x=>x.id===mid);
      if(m&&until>now+3000)out.push({k:'s_'+p.id+'_'+k,kind:'alarm',at:new Date(until),title:'MediMate · '+p.name+' (snoozed)',body:m.name+who,profileId:p.id,medicineId:m.id,profileName:p.name,medicineName:m.name,dose:m.dose||'',time:m.time,
        taken:JSON.stringify([{profileId:p.id,medicineId:m.id,dateKey:k.slice(0,10)}])});
    });
  });
  if(esChanged){try{localStorage.setItem('mm_early_sent',JSON.stringify(ES))}catch(e){}}
  out.sort((a,b)=>a.at-b.at);
  const list=out.slice(0,450).map((x,i)=>Object.assign(x,{id:i+1})),byKey={};
  list.forEach(x=>{if(x.k)byKey[x.k]=x.id});
  list.forEach(x=>{if(x.kind==='early'){x.mainIds=x.mk.map(k=>byKey[k]).filter(Boolean).join(',');x.taken=JSON.stringify(x.takenList)}});
  return list;
}
const MA=()=>plug('MediMateAlarm');
async function doSchedule(){
  try{
    const ma=MA(),ln=ma?null:LN(),cd=(ma||ln)?null:CDV();if(!ma&&!ln&&!cd)return;
    const items=nativeItems();
    if(ma){
      // MediMateAlarm = exact Android alarm that can wake the phone and show the app over the lock screen
      if(!lnReady){lnReady=true;try{if(!localStorage.getItem('mm_native_setup')){localStorage.setItem('mm_native_setup','1');await ma.requestSetup()}}catch(e){}}
      await ma.schedule({notifications:items.map(x=>({id:x.id,title:x.title,body:x.body,at:x.at.getTime(),kind:x.kind||'alarm',taken:x.taken||'',mainIds:x.mainIds||'',profileId:x.profileId,medicineId:x.medicineId,profileName:x.profileName,medicineName:x.medicineName,dose:x.dose,time:x.time}))});
    }else if(ln){
      if(!lnReady){
        try{await ln.requestPermissions()}catch(e){}
        try{await ln.createChannel({id:'medicine',name:'Medicine reminders',description:'Reminders at your medicine times',importance:5,visibility:1,vibration:true})}catch(e){}
        lnReady=true;
      }
      try{const pend=await ln.getPending();if(pend&&pend.notifications&&pend.notifications.length)await ln.cancel({notifications:pend.notifications.map(n=>({id:n.id}))})}catch(e){}
      if(items.length)await ln.schedule({notifications:items.map(x=>({id:x.id,title:x.title,body:x.body,channelId:'medicine',schedule:{at:x.at,allowWhileIdle:true}}))});
    }else{
      cd.cancelAll(()=>{if(items.length)cd.schedule(items.map(x=>({id:x.id,title:x.title,text:x.body,trigger:{at:x.at},foreground:true,wakeup:true,priority:2,vibrate:true})))});
    }
  }catch(e){console.warn('Could not schedule phone notifications',e)}
}
document.addEventListener('deviceready',scheduleNative);

// ---------- reminder checker ----------
// A dose is "due" from its time until MISS_MIN minutes later, so a slow or paused
// timer (for example a background tab) still rings as soon as the page wakes up.
function checkReminders(){
  const nd=midnight();if(dkey(nd)!==dkey(today)){today=nd;scheduleNative();if(P())render()}
  const n=new Date(),nowM=n.getHours()*60+n.getMinutes(),nowMs=Date.now();
  store.profiles.forEach(p=>{
    const due=medsOf(p,today).filter(m=>{
      const diff=nowM-toMin(m.time),k=dkey(today)+'_'+m.id;
      return !m.review&&diff>=0&&diff<=MISS_MIN&&!p.taken[k]&&!(p.snooze[k]>nowMs)&&!fired[fkey(p,m)];
    });
    if(due.length&&startRing(p,due))due.forEach(m=>{fired[fkey(p,m)]=1});
  });
}
setInterval(()=>{if(!document.hidden)checkReminders()},15000);
setInterval(()=>{if(P()&&!document.hidden)render()},60000);
let hiddenAt=0;
function lockNow(id){
  document.querySelectorAll('.scrim').forEach(s=>s.classList.remove('on'));
  closeDrawer();closeProfileDetails();closeOnboard();
  store.current=null;renderChooser();$('profiles').style.display='block';askPin(id);
}
document.addEventListener('visibilitychange',()=>{
  if(document.hidden){hiddenAt=Date.now();return}
  const p=P(),away=hiddenAt?Date.now()-hiddenAt:0;hiddenAt=0;
  if(p&&p.pin&&away>10000)needLock=p.id;      // ask for the PIN again after the app was away
  checkReminders();scheduleNative();
  if(needLock&&!ring.active){const id=needLock;needLock=0;lockNow(id);return}
  if(P())render();
});
document.addEventListener('resume',checkReminders);
window.addEventListener('focus',checkReminders);

// ---------- profile chooser ----------
function backFromChooser(){$('profiles').style.display='none'}
function renderChooser(){
  $('pback').style.display=P()?'flex':'none';
  $('plist').innerHTML=store.profiles.length?store.profiles.map(p=>
    `<div class="card" style="cursor:pointer" role="button" onclick="openProfile(${p.id})">
      <div class="avatar">${esc(ini(p.name))}</div>
      <div class="m"><b>${esc(p.name)}</b></div>
      ${p.pin?'<span class="ms" style="color:#747775">lock</span>':''}
      <span class="ms" style="color:#747775">chevron_right</span></div>`).join('')
    :'<div class="empty">No profiles yet.<br>Tap "Add profile" to start.</div>';
}
function showChooser(){closeDrawer();renderChooser();$('profiles').style.display='block'}
function openProfile(id){
  const p=store.profiles.find(x=>x.id===id);
  if(p&&id===store.current){closeDrawer();$('profiles').style.display='none';return}   // already in this profile: no PIN
  if(p&&p.pin)askPin(id);else enter(id)
}
function enter(id){
  const q=store.profiles.find(x=>x.id===id);
  if(q&&(!q.dob||!q.agreed||q.termsVersion!==TERMS_VERSION)){openAddProfile(q);return}
  try{persistProfilePrefs()}catch(e){}
  store.current=id;save();loadProfilePrefs(id);
  $('profiles').style.display='none';
  selDay=new Date(today);calY=today.getFullYear();calM=today.getMonth();
  unlockAudio();enableMotion();askPermission();
  goTab('home');render();maybeAskLink();
}
let profEdit=null,profileEditMode=false,pvEdit=false,pvDob='';
const fmtLong=d=>d.toLocaleDateString('en',{day:'numeric',month:'long',year:'numeric'});
function openTerms(){$('tscrim').classList.add('on')}
function closeTerms(){$('tscrim').classList.remove('on')}
// p given = an older profile that still needs a date of birth and the terms
function openAddProfile(p){
  profileEditMode=false;profEdit=p||null;$('p-title').textContent=p?'Finish setting up':'Welcome';
  $('p-name').value=p?p.name:'';setPDob(p&&p.dob?p.dob:'');$('p-dob-btn').disabled=!!(p&&p.dob);
  $('p-agree').checked=false;$('p-guardian').checked=false;$('p-err').textContent='';updateGuardianField();$('pscrim').classList.add('on');setTimeout(()=>$('p-name').focus(),50)}
function closeAddProfile(){$('pscrim').classList.remove('on');profileEditMode=false}
function profileAge(dob){
  const b=parseD(dob),t=midnight();let age=t.getFullYear()-b.getFullYear();
  if(t.getMonth()<b.getMonth()||(t.getMonth()===b.getMonth()&&t.getDate()<b.getDate()))age--;
  return age;
}
function updateGuardianField(){
  const dob=$('p-dob').value,minor=!!dob&&!isNaN(parseD(dob))&&profileAge(dob)<=18;
  $('p-guardian-wrap').style.display=minor?'flex':'none';
  $('p-agree-text').innerHTML=minor
    ?'A parent or legal guardian has read and agrees to the <a href="#" onclick="openTerms();return false">Terms and Privacy Policy</a> for this child.'
    :'I have read and agree to the <a href="#" onclick="openTerms();return false">Terms and Privacy Policy</a>.';
  if(!minor)$('p-guardian').checked=false;
}
$('p-dob').addEventListener('change',updateGuardianField);
function saveProfile(){
  const name=$('p-name').value.trim(),dob=$('p-dob').value,b=dob?parseD(dob):null;
  if(!name){$('p-err').textContent='Please enter your name.';return}
  if(!b||isNaN(b)||b>midnight()||b.getFullYear()<1900){$('p-err').textContent='Please enter a valid date of birth.';return}
  if(!$('p-agree').checked){$('p-err').textContent='Please confirm that the Terms and Privacy Policy have been read.';return}
  if(profileAge(dob)<=18&&!$('p-guardian').checked){$('p-err').textContent='A parent or legal guardian must confirm supervision for this child profile.';return}
  if(profEdit){
    const duplicate=store.profiles.some(x=>x.id!==profEdit.id&&x.dob===dob&&x.name.toLowerCase()===name.toLowerCase());
    if(duplicate){$('p-err').textContent='Another profile already uses this name and date of birth.';return}
    const p=profEdit,wasAdult=profileAge(p.dob)>18;p.name=name;p.dob=dob;p.agreed=Date.now();p.termsVersion=TERMS_VERSION;
    if(wasAdult&&profileAge(dob)<=18)p.meds.forEach(m=>{m.review=true});
    save();profileEditMode=false;profEdit=null;closeAddProfile();enter(p.id);if(!p.meds.length)showOnboard();return;
  }
  if(store.profiles.some(p=>p.dob===dob&&p.name.toLowerCase()===name.toLowerCase())){$('p-err').textContent='This profile is already added.';return}
  const id=Date.now(),p=norm({id,name,dob,agreed:Date.now(),termsVersion:TERMS_VERSION,meds:[],taken:{},nextId:1});
  store.profiles.push(p);save();closeAddProfile();enter(p.id);showOnboard();
}
function showOnboard(){$('onboard').style.display='flex'}
function closeOnboard(){$('onboard').style.display='none'}
let resetArmed=false;
// Erases everything on this device and shows the first-time screen again (no undo, so back up first)
function resetApp(){
  const lab=$('d-reset').lastElementChild;
  if(!resetArmed){resetArmed=true;lab.textContent='Tap again to erase everything';setTimeout(()=>{resetArmed=false;lab.textContent='Reset app'},4000);return}
  resetArmed=false;lab.textContent='Reset app';
  try{localStorage.removeItem(KEY)}catch(e){}
  store={profiles:[],current:null};scheduleNative();
  endRing();closeDrawer();closeOnboard();renderChooser();$('profiles').style.display='block';openAddProfile();
}
function deleteProfile(){
  const lab=$('d-del').lastElementChild;
  if(!delArmed){delArmed=true;lab.textContent='Tap again to confirm';setTimeout(()=>{delArmed=false;lab.textContent='Delete this profile'},3500);return}
  const gone=P();
  store.profiles=store.profiles.filter(p=>p.id!==store.current);store.current=null;save();
  delArmed=false;lab.textContent='Delete this profile';showChooser();
  toast('Profile deleted',{label:'Undo',fn:()=>{store.profiles.push(gone);save();renderChooser()}},10000);
}

// ---------- PIN lock (keeps other people on this device out of a profile) ----------
async function hashPin(pin,salt){
  try{const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(salt+':'+pin));return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('')}
  catch(e){return 'p:'+salt+':'+pin}
}
function pinDialog(mode,title,hint,ok){
  pinMode=mode;forgot=false;$('n-title').textContent=title;$('n-hint').textContent=hint;$('n-ok').textContent=ok;
  $('n-pin').value='';$('n-mail').value='';$('n-mail').type='email';$('n-mail').placeholder='name@gmail.com';$('n-err').textContent='';
  $('n-mail-l').textContent='Gmail account (used if you forget the PIN)';
  $('n-pinrow').style.display='block';$('n-mailrow').style.display=mode==='set'?'block':'none';
  $('n-forgot').style.display=mode==='open'?'':'none';$('n-remove').style.display='none';
  $('nscrim').classList.add('on');setTimeout(()=>$('n-pin').focus(),50);
}
function askPin(id){pinFor=id;pinDialog('open','Enter PIN','This profile is locked.','Open')}
function openSetPin(){
  closeDrawer();pinFor=store.current;const p=P();if(!p)return;
  pinDialog('set','PIN lock','Choose a 4 digit PIN and enter your Gmail account. The app asks for this PIN every time it opens.','Save');
  $('n-mail').value=p.email||'';$('n-remove').style.display=p.pin?'':'none';
}
function closePin(){$('nscrim').classList.remove('on')}
function removePin(){
  const p=store.profiles.find(x=>x.id===pinFor);if(!p)return;
  p.pin='';p.email='';save();closePin();toast('PIN removed');
}
function pinForgot(){
  const p=store.profiles.find(x=>x.id===pinFor);if(!p)return;
  forgot=true;$('n-pinrow').style.display='none';$('n-mailrow').style.display='block';$('n-forgot').style.display='none';$('n-err').textContent='';
  if(p.email){$('n-mail-l').textContent='Gmail account';$('n-hint').textContent='Enter the Gmail account you saved with this PIN to open this profile.'}
  else{$('n-mail').type='text';$('n-mail').placeholder='YYYY-MM-DD';$('n-mail-l').textContent='Date of birth';$('n-hint').textContent='No Gmail was saved with this PIN. Enter the date of birth of this profile (YYYY-MM-DD).'}
  $('n-ok').textContent='Open';setTimeout(()=>$('n-mail').focus(),50);
}
async function checkPin(){
  const p=store.profiles.find(x=>x.id===pinFor);if(!p)return;
  if(pinMode==='set'){
    const v=$('n-pin').value.trim(),em=$('n-mail').value.trim().toLowerCase();
    if(!/^\d{4}$/.test(v)){$('n-err').textContent='Enter a 4 digit PIN.';return}
    if(!/^[^\s@]+@(gmail|googlemail)\.com$/.test(em)){$('n-err').textContent='Enter your Gmail account, for example name@gmail.com.';return}
    p.pin=await hashPin(v,String(p.id));p.email=em;save();closePin();toast('PIN lock saved');return;
  }
  if(forgot){
    const entered=$('n-mail').value.trim().toLowerCase();
    if(entered&&(p.email?entered===p.email:entered===p.dob)){p.pin='';p.email='';save();closePin();toast('PIN removed. You can set a new one in the menu.');enter(p.id)}
    else $('n-err').textContent=p.email?'That is not the Gmail account saved for this profile.':'That is not the date of birth of this profile.';
    return;
  }
  if(await hashPin($('n-pin').value.trim(),String(p.id))===p.pin){closePin();enter(p.id)}
  else $('n-err').textContent='Wrong PIN. Try again.';
}

// ---------- back up and restore ----------
function openBackup(){closeDrawer();restoreArmed=false;$('b-err').textContent='';$('b-text').value=JSON.stringify({app:APP,v:2,profiles:store.profiles});$('bscrim').classList.add('on')}
function copyBackup(){
  const t=$('b-text');t.select();const ok=()=>toast('Copied. Save it somewhere safe.');
  try{navigator.clipboard.writeText(t.value).then(ok).catch(()=>{document.execCommand('copy');ok()})}catch(e){try{document.execCommand('copy');ok()}catch(e2){}}
}
function restoreBackup(){
  let o;try{o=JSON.parse($('b-text').value)}catch(e){$('b-err').textContent='This is not a valid backup.';return}
  if(!o||!Array.isArray(o.profiles)||!o.profiles.length||!o.profiles.every(p=>p&&typeof p.id==='number'&&typeof p.name==='string'&&Array.isArray(p.meds))){$('b-err').textContent='This is not a valid backup.';return}
  if(!restoreArmed){restoreArmed=true;$('b-err').textContent='Tap Restore again to replace all data on this device.';return}
  store.profiles=o.profiles.map(norm);store.current=null;save();$('bscrim').classList.remove('on');showChooser();toast('Backup restored');
}

// ---------- drawer ----------
function openDrawer(){renderDrawer();$('dscrim').style.display='block';$('drawer').classList.add('on')}
function closeDrawer(){$('dscrim').style.display='none';$('drawer').classList.remove('on')}
function renderDrawer(){
  const p=P();
  $('d-av').textContent=ini(p.name);$('d-name').textContent=p.name;$('d-mail').textContent='';
  $('d-list').innerHTML=store.profiles.map(x=>
    `<div class="item ${x.id===p.id?'on':''}" onclick="closeDrawer();openProfile(${x.id})">
      <div class="avatar">${esc(ini(x.name))}</div>${esc(x.name)}</div>`).join('');
}

// ---------- daily routine (read-only view; edit it in Profile details) ----------
const RT_ROWS=[['Breakfast','breakfast','free_breakfast'],['Lunch','lunch','lunch_dining'],['Evening','evening','wb_twilight'],['Dinner','dinner','dinner_dining'],['Bedtime','bedtime','bedtime']];
function openRoutine(){
  closeDrawer();const p=P();if(!p)return;const r=Object.assign({},DEF_ROUTINE,p.routine||{});
  $('rt-list').innerHTML=RT_ROWS.map(([l,k,ic])=>`<div class="rt-row"><span class="ms">${ic}</span><span>${l}</span><b>${r[k]?fmt(r[k]):'Not set'}</b></div>`).join('');
  $('rscrim').classList.add('on');
}

// ---------- navigation ----------
function goTab(name){
  document.querySelectorAll('#nav button').forEach(x=>x.classList.toggle('on',x.dataset.s===name));
  document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('on',s.id==='s-'+name));
  $('fab').style.display=name==='time'?'flex':'none';
}
document.querySelectorAll('#nav button').forEach(b=>b.onclick=()=>{const o=['home','time','cal','ai'],c=(document.querySelector('#nav button.on')||{dataset:{}}).dataset.s;document.body.dataset.dir=o.indexOf(b.dataset.s)>=o.indexOf(c)?'next':'prev';goTab(b.dataset.s);render()});

// ---------- Google Calendar (alerts even when the phone is locked) ----------
function confirmCalendarShare(id){
  const p=P(),m=p&&p.meds.find(x=>x.id===id);if(!p||!m)return false;
  const message=profileAge(p.dob)<=18
    ?'Parent or guardian: this opens Google Calendar and shares the medicine name and dose. Continue?'
    :'This opens Google Calendar and shares the medicine name and dose. Continue?';
  return window.confirm(message);
}
function calLink(m){
  const s=parseD(m.start),[h,mi]=m.time.split(':').map(Number),ev=m.every||1;
  const st=new Date(s.getFullYear(),s.getMonth(),s.getDate(),h,mi),en=new Date(st.getTime()+15*60000);
  const f=d=>d.getFullYear()+pad(d.getMonth()+1)+pad(d.getDate())+'T'+pad(d.getHours())+pad(d.getMinutes())+'00';
  const rec='RRULE:FREQ=DAILY;INTERVAL='+ev+(m.days>=3650?'':';COUNT='+Math.max(1,Math.ceil(m.days/ev)));
  return 'https://calendar.google.com/calendar/render?action=TEMPLATE&text='+encodeURIComponent('Take '+m.name)
    +'&details='+encodeURIComponent(m.dose+' (from '+APP+')')+'&dates='+f(st)+'/'+f(en)+'&recur='+encodeURIComponent(rec);
}


function bdayInfo(dob){
  const b=parseD(dob),t=midnight();
  const mk=y=>{const d=(b.getMonth()===1&&b.getDate()===29&&new Date(y,1,29).getMonth()!==1)?28:b.getDate();return new Date(y,b.getMonth(),d)};
  let nb=mk(t.getFullYear());if(nb<t)nb=mk(t.getFullYear()+1);
  return {left:Math.round((nb-t)/864e5),age:nb.getFullYear()-b.getFullYear()};
}
// ---------- profile details ----------
function setVoice(on){const p=P();if(!p)return;p.voiceAlerts=!!on;save();if(!on){try{window.speechSynthesis&&window.speechSynthesis.cancel()}catch(e){}}toast(on?'Spoken alert on':'Spoken alert off');if($('set-view')?.classList.contains('on'))renderSettings()}
function closeProfileDetails(){pvEdit=false;$('profile-view').classList.remove('on')}
function pvRender(){
  const p=P();if(!p)return;
  const age=profileAge(pvEdit?pvDob:p.dob);
  const accepted=p.agreed?new Date(p.agreed).toLocaleDateString('en',{day:'numeric',month:'long',year:'numeric'}):'Not available';
  const meds=[...p.meds].sort((a,b)=>a.time.localeCompare(b.time));
  const medicineHtml=meds.length?meds.map(m=>{
    const end=m.days>=3650?'No end date':fmtD(addDays(parseD(m.start),m.days-1));
    return `<div class="profile-med"><b>${esc(m.name)}</b><small>${m.dose?esc(m.dose)+' · ':''}${fmt(m.time)}<br>Starts ${fmtD(parseD(m.start))} · ${esc(end)}${(m.every||1)>1?' · Repeats every '+m.every+' days':''}</small><small>${m.review?'Needs checking against the current prescription or label':'Reminder details marked as checked'}</small></div>`;
  }).join(''):'<div class="profile-empty">No scheduled medicines have been added.</div>';
  const routine=Object.assign({},DEF_ROUTINE,p.routine||{});
  const RN=[['Breakfast','breakfast'],['Lunch','lunch'],['Evening','evening'],['Dinner','dinner'],['Bedtime','bedtime']];
  $('pv-edit-btn').style.display=pvEdit?'none':'';
  const personal=pvEdit?`<div class="profile-data">
      <label class="datum"><small>Full name</small><input id="pe-name" value="${esc(p.name)}" maxlength="40" autocomplete="off"></label>
      <div class="datum"><small>Date of birth</small><button type="button" class="dobbtn" id="pe-dob" onclick="openDatePicker(pvDob,v=>{pvDob=v;updatePvAge()})">${fmtLong(parseD(pvDob))}</button></div>
      <div class="datum"><small>Age</small><b id="pe-age">${age} years</b></div>
      <div class="datum"><small>Terms accepted</small><b>${accepted}</b></div>
    </div>`:`<div class="profile-data">
      <div class="datum"><small>Full name</small><b>${esc(p.name)}</b></div>
      <div class="datum"><small>Age</small><b>${age} years</b></div>
      <div class="datum"><small>Date of birth</small><b>${fmtLong(parseD(p.dob))}</b></div>
      <div class="datum"><small>Terms accepted</small><b>${accepted}</b></div>
    </div>`;
  const routineHtml=pvEdit
    ?`<div class="profile-data">${RN.map(([l,k])=>`<label class="datum"><small>${l}</small><input type="time" id="pe-r-${k}" value="${esc(routine[k])}"></label>`).join('')}</div>`
    :`<div class="profile-routine">${RN.map(([l,k])=>`<div><span>${l}</span><b>${routine[k]?fmt(routine[k]):'Not set'}</b></div>`).join('')}</div>`;
  $('profile-content').innerHTML=`
    <div class="profile-identity"><div class="avatar">${esc(ini(p.name))}</div><div><h3>${esc(p.name)}</h3><p>MediMate profile · ${age} years old</p></div></div>
    <section class="profile-section"><h3>Personal details</h3>${personal}</section>
    <section class="profile-section"><h3>Scheduled medicines (${meds.length})</h3>${medicineHtml}</section>
    
    ${pvEdit?'<div class="pe-actions"><button type="button" class="btn t" onclick="cancelProfileEdit()">Cancel</button><button type="button" class="btn" onclick="saveProfileEdit()">Save changes</button></div>':''}
    <p class="profile-note" style="padding:0 4px 12px">For users aged 18 and younger, a parent or legal guardian must continue to check the medicines and supervise medicine-taking. Keep this profile private because it contains personal and medicine information.</p>`;
}
function updatePvAge(){const b=$('pe-dob'),a=$('pe-age');if(b)b.textContent=fmtLong(parseD(pvDob));if(a)a.textContent=profileAge(pvDob)+' years'}
function showProfileView(){$('profile-view').classList.add('on');$('profile-view').scrollTop=0}
function openProfileDetails(){const p=P();if(!p)return;closeDrawer();pvEdit=false;pvRender();showProfileView()}
function openEditProfile(){const p=P();if(!p)return;closeDrawer();pvEdit=true;pvDob=p.dob;pvRender();showProfileView()}
function toggleProfileEdit(){const p=P();if(!p)return;pvEdit=true;pvDob=p.dob;pvRender()}
function cancelProfileEdit(){pvEdit=false;pvRender()}
function saveProfileEdit(){
  const p=P();if(!p)return;
  const name=$('pe-name').value.trim(),dob=pvDob,b=dob?parseD(dob):null;
  if(!name){toast('Please enter a name');return}
  if(!b||isNaN(b)||b>midnight()||b.getFullYear()<1900){toast('Please choose a valid date of birth');return}
  if(store.profiles.some(x=>x.id!==p.id&&x.dob===dob&&x.name.toLowerCase()===name.toLowerCase())){toast('Another profile already uses this name and date of birth');return}
  const wasAdult=profileAge(p.dob)>18;
  p.name=name;
  if(dob!==p.dob){if(wasAdult&&profileAge(dob)<=18)p.meds.forEach(m=>{m.review=true});p.dob=dob}
  const r={};RT_ROWS.forEach(([l,k])=>{{const el=$('pe-r-'+k);r[k]=(el&&el.value)||(p.routine&&p.routine[k])||DEF_ROUTINE[k]}});p.routine=r;
  save();pvEdit=false;render();pvRender();toast('Profile updated');
}

// Delete is done by holding a medicine (or tapping a history entry) and using the Delete button - no swipe-to-delete.
function archiveTakenForMedicine(p,m){p.hist=p.hist||[];const prefix='_'+m.id;let n=0;Object.keys(p.taken||{}).forEach(k=>{if(!k.endsWith(prefix)||!p.taken[k])return;const date=k.slice(0,k.lastIndexOf('_'));p.hist.push({id:Date.now()+n++,date,name:m.name,time:(p.takenAt&&p.takenAt[k])||m.time||'00:00',dose:m.dose||'',medId:m.id,archived:true});unmarkTaken(p,k)});return n}
function swipeDeleteMedicine(id){const p=P(),m=p&&p.meds.find(x=>x.id===id);if(!p||!m)return;archiveTakenForMedicine(p,m);p.meds=p.meds.filter(x=>x.id!==id);save();render();if(document.getElementById('hist-view')?.classList.contains('on'))histRender();toast('Medicine removed')}
function histDeleteIndex(i){const e=(window.__H||[])[i];if(!e)return;const p=P();if(e.own)p.hist=(p.hist||[]).filter(x=>x.id!==e.id);else if(e.key)unmarkTaken(p,e.key);save();aiClose();histRender();render();toast('History entry deleted')}

// ---------- render ----------
function medCard(m,d,o){
  const done=isTaken(m,d),n=new Date();
  const missed=!!o.check&&!done&&dkey(d)===dkey(midnight())&&(n.getHours()*60+n.getMinutes())-toMin(m.time)>MISS_MIN;
  const og=m.days>=3650,ev=m.every||1;
  const range=o.edit?`<small>${og?'From '+fmtD(parseD(m.start))+' · no end date':fmtD(parseD(m.start))+' to '+fmtD(addDays(parseD(m.start),m.days-1))+' · '+m.days+' day'+(m.days==1?'':'s')}${ev>1?' · every '+ev+' days':''}</small>`:'';
  return `<div class="card ${done&&o.check?'done':''}" data-med-id="${o.edit?m.id:''}" >
    <div class="ic"><span class="ms">medication</span></div>
    <div class="m"><b>${esc(m.name)}${m.review?`<span class="tag">${m.nodur?'Set days':'Check me'}</span>`:''}${missed?'<span class="tag red">Not recorded</span>':''}</b>${m.dose?`<small>${esc(m.dose)}</small>`:''}${m.notes?`<small class="mnote">${esc(m.notes)}</small>`:''}${range}</div>
    ${o.check&&!m.review?`<button class="iconbtn" aria-label="${done?'Mark as not taken':'Mark as taken'}: ${esc(m.name)}" onclick="toggleTaken(${m.id})"><span class="ms" style="color:${done?'#34a853':'#747775'}">${done?'check_circle':'radio_button_unchecked'}</span></button>`:o.check&&m.review?'<span class="tag">Check before use</span>':''}
    ${o.edit?`<a class="iconbtn" aria-label="Add ${esc(m.name)} to Google Calendar" href="${esc(calLink(m))}" target="_blank" rel="noopener" onclick="return confirmCalendarShare(${m.id})"><span class="ms">event</span></a>
              <button class="iconbtn" aria-label="Edit ${esc(m.name)}" onclick="openEdit(${m.id})"><span class="ms">edit</span></button>
              <button class="iconbtn" aria-label="Delete ${esc(m.name)}" onclick="delMed(${m.id})"><span class="ms">delete</span></button>`:''}
  </div>`}


let __lpAt=0;
function lpOnce(fn){const n=Date.now();if(n-__lpAt<1300)return;__lpAt=n;fn()}
function histClick(i){if(Date.now()-__lpAt<900)return;histOpen(i)}
function medLongPressInfo(e,id){try{e&&e.preventDefault&&e.preventDefault()}catch(x){}lpOnce(()=>medSheet(id))}
function medSheet(id){const p=P(),m=p&&p.meds.find(x=>x.id===id);if(!p||!m)return;aiSheet(`<h2>${esc(m.name)}</h2><p><b>Scheduled time:</b> ${fmt(m.time)}</p>${m.dose?'<p><b>Dose:</b> '+esc(m.dose)+'</p>':''}<p>${m.notes?esc(m.notes):''}</p><div class="aib"><button class="p" onclick="aiClose()">Close</button></div><div class="aib"><button id="md-del" style="color:#b3261e" onclick="medDelTap(${m.id})"><span class="ms">delete</span><span>Delete</span></button></div>`)}
let __medDelArm=0;
function medDelTap(id){const b=document.getElementById('md-del');if(__medDelArm!==id){__medDelArm=id;if(b){b.lastChild.textContent='Tap again to delete';b.style.background='#fce8e6'}setTimeout(()=>{if(__medDelArm===id)__medDelArm=0;const x=document.getElementById('md-del');if(x){x.lastChild.textContent='Delete';x.style.background=''}},3500);return}__medDelArm=0;aiClose();swipeDeleteMedicine(id)}


let medLongPressTimer=null,medLongPressFired=false;
document.addEventListener('touchstart',e=>{const card=e.target.closest('.card[data-med-id]');if(!card||!card.dataset.medId)return;medLongPressFired=false;clearTimeout(medLongPressTimer);const id=+card.dataset.medId;medLongPressTimer=setTimeout(()=>{medLongPressFired=true;lpOnce(()=>medSheet(id))},600)},{passive:true});
document.addEventListener('touchstart',e=>{const row=e.target.closest('.hrow[data-history-index]');if(!row)return;clearTimeout(medLongPressTimer);const i=+row.dataset.historyIndex;medLongPressTimer=setTimeout(()=>lpOnce(()=>histOpen(i)),600)},{passive:true});
document.addEventListener('contextmenu',e=>{const row=e.target.closest&&e.target.closest('.hrow[data-history-index]');if(row){e.preventDefault();const i=+row.dataset.historyIndex;lpOnce(()=>histOpen(i));return}if(e.target.closest&&e.target.closest('.card[data-med-id]'))e.preventDefault()});
document.addEventListener('touchmove',()=>clearTimeout(medLongPressTimer),{passive:true});
document.addEventListener('touchend',()=>clearTimeout(medLongPressTimer),{passive:true});

function grouped(list,d,o){
  const times=[...new Set(list.map(m=>m.time))].sort();
  return times.map(t=>`<div class="tsec">${fmt(t)}</div><div class="hbody">${list.filter(m=>m.time===t).map(m=>medCard(m,d,o)).join('')}</div>`).join('');
}

function render(){
  const p=P();if(!p)return;
  today=midnight();
  $('av').textContent=ini(p.name);$('pname').textContent=p.name;
  const now=new Date(),nowMin=now.getHours()*60+now.getMinutes(),hr=now.getHours();
  $('greet').textContent=hr<12?'Good morning':hr<17?'Good afternoon':'Good evening';
  $('hdate').textContent=today.toLocaleDateString('en',{weekday:'long',day:'numeric',month:'long'});
  const bd=bdayInfo(p.dob),nm=esc(p.name);
  $('bday').innerHTML=bd.left>10?'':bd.left===0
    ?`<div class="bcard"><div class="bnum"><b>🎂</b></div><div class="btxt"><div class="bt1">Happy birthday, ${nm}!</div><div class="bt2">Have a lovely birthday, ${nm}!</div></div></div>`
    :`<div class="bcard"><div class="bnum"><b>${bd.left}</b><small>day${bd.left==1?'':'s'}</small></div><div class="btxt"><div class="bt1">until your birthday 🎂</div><div class="bt2">Have a lovely birthday, ${nm}!</div></div></div>`;
  const list=medsOn(today),pending=list.filter(m=>!m.review&&!isTaken(m,today));
  const nxt=pending.find(m=>toMin(m.time)>=nowMin-MISS_MIN)||pending[0];
  if(!p.meds.length)
    $('nextcard').innerHTML=`<div class="ncard"><div class="lbl">GET STARTED</div><div class="n" style="margin:6px 0 14px">Add a medicine using the details from the current prescription or medicine label.</div>
      <button class="btn big" onclick="openEdit(null)"><span class="ms">add</span>Add medicine</button></div>`;
  else if(nxt){
    const diff=toMin(nxt.time)-nowMin,ad=Math.abs(diff);
    const t=(ad>=60?Math.floor(ad/60)+' h ':'')+(ad%60)+' min';
    const txt=diff===0?'now':diff>0?'in '+t:'was due '+t+' ago';
    $('nextcard').innerHTML=`<div class="ncard"><div class="nrow"><div><div class="lbl">NEXT MEDICINE</div><div class="t">${fmt(nxt.time)}</div></div><span class="chip ${diff<0?'over':''}">${txt}</span></div>
      <div class="n">${pending.filter(m=>m.time===nxt.time).map(m=>`<div style="margin-top:8px">${esc(m.name)}</div>`).join('')}</div><div class="d">${pending.filter(m=>m.time===nxt.time).map(m=>m.dose?`<div>${esc(m.dose)}</div>`:'').join('')}</div>
      <button class="btn big" onclick="markTimeTaken('${nxt.time}')"><span class="ms">check</span>Mark these as taken</button></div>`;
  }else if(list.some(m=>m.review))
    $('nextcard').innerHTML=`<div class="ncard"><div class="lbl">CHECK REMINDERS</div><div class="n" style="margin-top:6px">Some medicine details need to be checked in the Schedule before they can remind you.</div></div>`;
  else if(list.length)
    $('nextcard').innerHTML=`<div class="ncard ok"><div class="lbl" style="color:#0a3818">TODAY'S REMINDERS REVIEWED</div><div class="t">No more reminders due today.</div></div>`;
  else
    $('nextcard').innerHTML=`<div class="ncard"><div class="lbl">NOTHING SCHEDULED</div><div class="n" style="margin-top:6px">No medicines today</div></div>`;
  const dn=list.length-pending.length;
  const showing=p.meds.length&&nxt?nxt.time:null,left=list.filter(m=>!isTaken(m,today)&&(!showing||m.time!==showing));
  $('todaylist').innerHTML=left.length?grouped(left,today,{check:true}):(showing!==null?'':'<div class="empty">'+(list.length?'All done for today. Taken medicines are in History.':'No medicines today')+'</div>');
  $('warn').style.display=storageOk?'none':'block';
  $('tcount').textContent=p.meds.length+' medicine'+(p.meds.length==1?'':'s')+' scheduled';
  if(!scanning){
    const rev=p.meds.filter(m=>m.review),nod=rev.filter(m=>m.nodur).length,chk=rev.length-nod;
    $('reviewbar').innerHTML=(chk?`<div class="banner">Please check each reminder against the current prescription. For a child, a parent or guardian must do this. Unchecked reminders will not ring.<br><button class="btn" onclick="confirmAll()">I have checked these reminders</button></div>`:'')
      +(nod?`<div class="banner">${nod} reminder${nod==1?' has':'s have'} no end date in the prescription. Tap the pencil and set the number of days, or tick "No end date" for long-term medicines.</div>`:'');
    const all=[...p.meds].sort((a,b)=>a.time.localeCompare(b.time));
    $('timelist').innerHTML=(all.length?grouped(all,today,{edit:true}):'<div class="empty">Nothing yet. Tap Add to enter a medicine exactly as prescribed.</div>')
      +(p.prn.length?`<div class="sec">As needed (no reminder)</div><div class="hbody">${p.prn.map(x=>`<div class="card"><div class="ic"><span class="ms">medication</span></div><div class="m"><b>${esc(x.name)}</b>${x.dose?`<small>${esc(x.dose)}</small>`:''}</div><button class="iconbtn" aria-label="Delete ${esc(x.name)}" onclick="delPrn(${x.id})"><span class="ms">delete</span></button></div>`).join('')}</div>`:'');
  }
  renderCal();
  if($('profile-view').classList.contains('on')&&!pvEdit)pvRender();
}
function confirmAll(){
  const p=P();if(!p)return;
  const child=profileAge(p.dob)<=18;
  const message=child
    ?'Parent or guardian: have you checked every medicine name, dose, time and duration against the current prescription or label? Confirm only after checking.'
    :'Have you checked every medicine name, dose, time and duration against the current prescription or label?';
  if(!window.confirm(message))return;
  p.meds.forEach(m=>{if(!m.nodur)m.review=false});save();render();
}
function delPrn(id){const p=P();p.prn=p.prn.filter(x=>x.id!==id);save();render()}
function markTimeTaken(time){const p=P();if(!p)return;const ms=medsOn(today).filter(m=>m.time===time&&!m.review&&!isTaken(m,today));if(!ms.length)return;const names=ms.map(m=>m.name).join(', ');if(!confirm('Record these as taken: '+names+'? Only confirm after they were actually taken as prescribed.'))return;ms.forEach(m=>markTaken(p,dkey(today),m.id));save();render()}
function toggleTaken(id){
  const p=P(),m=p&&p.meds.find(x=>x.id===id);if(!p||!m||m.review)return;
  const k=dkey(today)+'_'+id,was=!!p.taken[k];
  const message=was?'Remove the taken mark for '+m.name+'?':'Record '+m.name+' as taken? Only confirm after the person has actually taken it as prescribed. For a child, check with a parent or guardian.';
  if(!window.confirm(message))return;
  if(was)unmarkTaken(p,k);else markTaken(p,dkey(today),id);save();render();
}
function delMed(id){
  const p=P(),i=p.meds.findIndex(m=>m.id===id);if(i<0)return;
  const [gone]=p.meds.splice(i,1);const archiveBefore=(p.hist||[]).length;archiveTakenForMedicine(p,gone);const archivedRecords=(p.hist||[]).slice(archiveBefore);const archivedIds=archivedRecords.map(h=>h.id);save();render();
  toast('Medicine deleted',{label:'Undo',fn:()=>{p.meds.push(gone);p.hist=(p.hist||[]).filter(h=>!archivedIds.includes(h.id));archivedRecords.forEach(h=>{p.taken[h.date+'_'+gone.id]=true});save();render()}});
}

// ---------- schedule PDF ----------
function pdfText(s){return String(s==null?'':s).replace(/[\u2018\u2019]/g,"'").replace(/[\u201C\u201D]/g,'"').replace(/[\u2013\u2014]/g,'-').replace(/\u00B7/g,'-').replace(/[^\x20-\x7E]/g,'?').replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)')}
function buildPdf(pagesOps){
  const objs=[],add=s=>{objs.push(s);return objs.length};const MB=pagesOps.mb||[595,842];
  add('<< /Type /Catalog /Pages 2 0 R >>');add('');
  add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
  add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
  const kids=[];
  pagesOps.forEach(ops=>{
    const content=ops.join('\n'),cid=objs.length+2;
    const pid=add('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+MB[0]+' '+MB[1]+'] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents '+cid+' 0 R >>');
    add('<< /Length '+content.length+' >>\nstream\n'+content+'\nendstream');kids.push(pid+' 0 R');
  });
  objs[1]='<< /Type /Pages /Kids ['+kids.join(' ')+'] /Count '+kids.length+' >>';
  let out='%PDF-1.4\n';const offs=[];
  objs.forEach((o,i)=>{offs.push(out.length);out+=(i+1)+' 0 obj\n'+o+'\nendobj\n'});
  const xr=out.length;
  out+='xref\n0 '+(objs.length+1)+'\n0000000000 65535 f \n'+offs.map(o=>String(o).padStart(10,'0')+' 00000 n \n').join('')+'trailer\n<< /Size '+(objs.length+1)+' /Root 1 0 R >>\nstartxref\n'+xr+'\n%%EOF';
  const u=new Uint8Array(out.length);for(let i=0;i<out.length;i++)u[i]=out.charCodeAt(i)&255;
  return u;
}
async function openSavedPdf(uri){
  try{await MA().openPdf({uri:uri})}
  catch(e){toast('No PDF viewer found. Open it from Files > Downloads.',null,7000)}
}
async function savePdfFile(bytes,name){
  const m=MA();
  if(m&&m.savePdf){
    try{
      toast('Downloading PDF\u2026',null,30000);
      let bin='';for(let i=0;i<bytes.length;i++)bin+=String.fromCharCode(bytes[i]);
      const data=btoa(bin);
      await new Promise(r=>setTimeout(r,700));
      const r=await m.savePdf({name:name,data:data});
      if(r&&r.saved&&r.uri){toast('PDF downloaded',{label:'Open',fn:()=>openSavedPdf(r.uri)},20000)}
      else if(r&&r.saved){toast('PDF saved in your Downloads folder',null,6000)}
      else{toast('Choose where to save your schedule',null,6000)}
    }catch(e){toast('Could not save the PDF: '+(e&&e.message||e),null,7000)}
    return;
  }
  const url=URL.createObjectURL(new Blob([bytes],{type:'application/pdf'}));
  const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();
  setTimeout(()=>{a.remove();URL.revokeObjectURL(url)},5000);
  toast('Downloading '+name);
}
function wrapText(s,n){const w=String(s||'').split(/\s+/),out=[];let l='';w.forEach(x=>{if((l+' '+x).trim().length>n){if(l)out.push(l);l=x}else l=(l+' '+x).trim()});if(l)out.push(l);return out}
function downloadGridPDF(p){
  const W=842,H=595,M=28,DAYS=14,dateW=96,rowH=42,hdrH=26;
  const times=[...new Set(p.meds.map(m=>m.time))].sort(),colW=(W-2*M-dateW)/times.length;
  const d0=new Date();d0.setHours(0,0,0,0);
  const due=(m,d)=>{const i=Math.round((d-parseD(m.start))/864e5),ev=m.every||1;return i>=0&&(m.days>=3650||i<m.days)&&i%ev===0};
  const pages=[];pages.mb=[W,H];let ops,idx=0;
  const T=(f,sz,x,yy,s,c)=>ops.push('BT /'+f+' '+sz+' Tf '+(c||'0 0 0')+' rg '+x.toFixed(1)+' '+yy.toFixed(1)+' Td ('+pdfText(s)+') Tj ET');
  const R=(x,yy,w,h,fill)=>ops.push(fill+' rg 0.75 0.78 0.82 RG 0.6 w '+x.toFixed(1)+' '+yy.toFixed(1)+' '+w.toFixed(1)+' '+h.toFixed(1)+' re B');
  while(idx<DAYS){
    ops=[];pages.push(ops);let top=H-M;
    if(pages.length===1){T('F2',22,M,top-18,'MediMate - Medicine schedule','0.043 0.341 0.816');T('F1',11,M,top-36,p.name+'   |   Next '+DAYS+' days from '+fmtLong(d0),'0.37 0.39 0.41');top-=52}
    R(M,top-hdrH,dateW,hdrH,'0.043 0.341 0.816');T('F2',10,M+8,top-17,'Date','1 1 1');
    times.forEach((t,i)=>{R(M+dateW+i*colW,top-hdrH,colW,hdrH,'0.043 0.341 0.816');T('F2',10,M+dateW+i*colW+6,top-17,fmt(t),'1 1 1')});
    let y=top-hdrH;
    while(idx<DAYS&&y-rowH>=M+14){
      const d=addDays(d0,idx),we=d.getDay()===0||d.getDay()===6;
      R(M,y-rowH,dateW,rowH,we?'0.99 0.92 0.92':'0.94 0.95 0.97');
      T('F2',11,M+8,y-17,d.toLocaleDateString('en-GB',{weekday:'long'}));T('F1',10,M+8,y-31,d.toLocaleDateString('en-GB',{day:'numeric',month:'short'}),'0.3 0.3 0.3');
      times.forEach((t,i)=>{
        const names=p.meds.filter(m=>m.time===t&&due(m,d)).map(m=>m.name),x=M+dateW+i*colW;
        R(x,y-rowH,colW,rowH,names.length?'0.89 0.93 0.99':'1 1 1');
        const sz=names.length>2?7:8.5,mc=Math.max(6,Math.floor((colW-8)/(sz*0.52)));let lines=[];
        names.forEach(n=>wrapText(n,mc).forEach(l=>lines.push(l)));
        if(lines.length>4){lines=lines.slice(0,4);lines[3]=lines[3].slice(0,Math.max(1,mc-3))+'...'}
        lines.forEach((l,j)=>T('F1',sz,x+4,y-12-j*(sz+2),l));
      });
      y-=rowH;idx++;
    }
  }
  pages.forEach((o,i)=>o.push('BT /F1 8 Tf 0.5 0.5 0.5 rg '+M+' 14 Td (Created with MediMate - check every medicine against the prescription. Page '+(i+1)+' of '+pages.length+') Tj ET'));
  savePdfFile(buildPdf(pages),'MediMate-grid-schedule-'+p.name.replace(/[^A-Za-z0-9]+/g,'-')+'.pdf');
}
function downloadTimetablePDF(){
  const p=P();if(!p)return;
  if(!p.meds.length){toast('Add a medicine first');return}
  if(S.pdf==='grid')return downloadGridPDF(p);
  const pages=[];let ops,y;
  const newPage=()=>{ops=[];pages.push(ops);y=790};
  const T=(f,sz,x,yy,s,c)=>ops.push('BT /'+f+' '+sz+' Tf '+(c||'0 0 0')+' rg '+x+' '+yy+' Td ('+pdfText(s)+') Tj ET');
  newPage();
  T('F2',28,50,y,'MediMate - Medicine schedule','0.043 0.341 0.816');y-=30;
  T('F1',13,50,y,p.name+'   |   Created '+fmtLong(new Date()),'0.37 0.39 0.41');y-=18;
  ops.push('0.85 0.86 0.88 RG 1 w 50 '+y+' m 545 '+y+' l S');y-=32;
  const all=[...p.meds].sort((a,b)=>a.time.localeCompare(b.time));
  [...new Set(all.map(m=>m.time))].forEach(t=>{
    if(y<140)newPage();
    T('F2',22,50,y,fmt(t),'0 0 0');y-=31;
    all.filter(m=>m.time===t).forEach(m=>{
      const og=m.days>=3650,ev=m.every||1;
      const lines=[['F2',17,m.name,'0 0 0']];
      wrapText(m.dose||'',58).forEach(l=>lines.push(['F1',15,l,'0.15 0.15 0.15']));
      if(m.notes)wrapText('Note: '+m.notes,62).forEach(l=>lines.push(['F1',14,l,'0.043 0.341 0.816']));
      lines.push(['F1',13,(og?'From '+fmtD(parseD(m.start))+' - no end date':fmtD(parseD(m.start))+' to '+fmtD(addDays(parseD(m.start),m.days-1)))+(ev>1?' - every '+ev+' days':''),'0.37 0.39 0.41']);
      if(y<65+lines.length*21)newPage();
      ops.push('0.043 0.341 0.816 rg 52 '+(y-1)+' 7 7 re f');
      lines.forEach(([f,sz,s,c])=>{T(f,sz,68,y,s,c);y-=sz+7});
      y-=10;
    });
    y-=10;
  });
  pages.forEach((o,i)=>o.push('BT /F1 9 Tf 0.5 0.5 0.5 rg 50 28 Td (Created with MediMate - check every medicine against the prescription. Page '+(i+1)+' of '+pages.length+') Tj ET'));
  savePdfFile(buildPdf(pages),'MediMate-schedule-'+p.name.replace(/[^A-Za-z0-9]+/g,'-')+'.pdf');
}

// ---------- calendar ----------
function shiftMonth(n){calM+=n;if(calM<0){calM=11;calY--}if(calM>11){calM=0;calY++}renderCal()}
function renderCal(){
  const first=new Date(calY,calM,1),n=new Date(calY,calM+1,0).getDate();
  $('monthname').textContent=first.toLocaleString('en',{month:'long',year:'numeric'});
  let h=['S','M','T','W','T','F','S'].map(x=>`<div class="dow">${x}</div>`).join('');
  for(let i=0;i<first.getDay();i++)h+='<div></div>';
  for(let d=1;d<=n;d++){
    const dt=new Date(calY,calM,d);
    const c=['day',(medsOn(dt).length||histOn(dt).length)?'has':'',dkey(dt)===dkey(today)?'today':'',dkey(dt)===dkey(selDay)?'sel':''].join(' ');
    h+=`<div class="${c}" onclick="pickDay(${calY},${calM},${d})">${d}</div>`;
  }
  $('grid').innerHTML=h;
  const L=medsOn(selDay),H=histOn(selDay);
  $('daytitle').textContent=selDay.toLocaleDateString('en',{weekday:'long',day:'numeric',month:'long'})+' · '+(L.length+H.length)+' medicine'+((L.length+H.length)==1?'':'s');
  $('daylist').innerHTML=(L.length?grouped(L,selDay,{}):(H.length?'':'<div class="empty">No medicines on this day</div>'))+(H.length?`<div class="hcal"><b>Taken (added by you)</b>${H.map(h=>`<div class="hcr"><span class="ms">check_circle</span><div><b>${esc(h.name)}</b><div>${fmt(h.time)}${h.dose?' \u00b7 '+esc(h.dose):''} \u00b7 taken</div></div></div>`).join('')}</div>`:'');
}
function pickDay(y,m,d){selDay=new Date(y,m,d);renderCal()}

// ---------- Google-style date picker ----------
let dp={y:2000,m:0,sel:'',mode:'day',cb:null};
function openDatePicker(cur,cb){
  const t=midnight(),ok=cur&&!isNaN(parseD(cur)),d=ok?parseD(cur):new Date(t.getFullYear()-20,0,1);
  dp={y:d.getFullYear(),m:d.getMonth(),sel:ok?cur:'',mode:ok?'day':'year',cb};
  $('dp-err').textContent='';$('dpscrim').classList.add('on');dpRender();
}
function dpRender(){
  const t=midnight(),sel=dp.sel?parseD(dp.sel):null,body=$('dp-body');
  $('dp-big').textContent=sel?sel.toLocaleDateString('en',{weekday:'short',month:'short',day:'numeric',year:'numeric'}):'Select date';
  $('dp-my').innerHTML=new Date(dp.y,dp.m,1).toLocaleString('en',{month:'long',year:'numeric'})+'<span class="ms">'+(dp.mode==='year'?'arrow_drop_up':'arrow_drop_down')+'</span>';
  $('dp-arrows').style.display=dp.mode==='year'?'none':'flex';
  if(dp.mode==='year'){
    let h='';for(let y=t.getFullYear();y>=1900;y--)h+=`<button type="button" class="dp-y${y===dp.y?' on':''}" onclick="dpYear(${y})"${y===dp.y?' id="dp-ycur"':''}>${y}</button>`;
    body.className='dp-years';body.innerHTML=h;
    const c=$('dp-ycur');if(c)body.scrollTop=Math.max(0,c.offsetTop-body.clientHeight/2+20);
  }else{
    const first=new Date(dp.y,dp.m,1),n=new Date(dp.y,dp.m+1,0).getDate();
    let h=['S','M','T','W','T','F','S'].map(x=>`<div class="dp-w">${x}</div>`).join('');
    for(let i=0;i<first.getDay();i++)h+='<div></div>';
    for(let d=1;d<=n;d++){const dt=new Date(dp.y,dp.m,d),k=dkey(dt);
      h+=`<button type="button" class="dp-d${k===dp.sel?' on':''}${k===dkey(t)?' today':''}"${dt>t?' disabled':''} onclick="dpDay('${k}')">${d}</button>`}
    body.className='dp-days';body.innerHTML=h;
  }
}
function dpToggle(){dp.mode=dp.mode==='year'?'day':'year';dpRender()}
function dpYear(y){const t=midnight();dp.y=y;if(y===t.getFullYear()&&dp.m>t.getMonth())dp.m=t.getMonth();dp.mode='day';dpRender()}
function dpDay(k){dp.sel=k;$('dp-err').textContent='';dpRender()}
function dpShift(n){
  let y=dp.y,m=dp.m+n;if(m<0){m=11;y--}if(m>11){m=0;y++}
  const t=midnight();if(y<1900||y>t.getFullYear()||(y===t.getFullYear()&&m>t.getMonth()))return;
  dp.y=y;dp.m=m;dpRender();
}
function dpClose(){$('dpscrim').classList.remove('on')}
function dpOk(){if(!dp.sel){$('dp-err').textContent='Pick a day first.';return}const cb=dp.cb,v=dp.sel;dpClose();if(cb)cb(v)}
function setPDob(v){$('p-dob').value=v;$('p-dob-btn').textContent=v?fmtLong(parseD(v)):'Select date of birth';updateGuardianField()}
function pickProfileDob(){openDatePicker($('p-dob').value,v=>setPDob(v))}

// ---------- edit dialog ----------
function openEdit(id){
  editing=id;const m=P().meds.find(x=>x.id===id);
  $('dtitle').textContent=m?'Edit schedule item':'Add medicine or task';
  $('f-kind').value=m&&m.kind==='task'?'task':'medicine';
  $('f-kind').disabled=!S.tasksEnabled&&!(m&&m.kind==='task');
  $('f-name').value=m?m.name:'';$('f-dose').value=m?m.dose:'';
  $('f-time').value=m?m.time:'09:00';$('f-start').value=m?m.start:dkey(today);
  const og=!!m&&m.days>=3650;
  $('f-ongoing').checked=og;$('f-end').disabled=og;
  $('f-end').value=og?'':dkey(addDays(parseD($('f-start').value),m?m.days-1:6));
  $('f-notes').value=m&&m.notes?m.notes:'';
  $('f-repeat-enabled').checked=false;$('f-repeat-times').value='';toggleRepeatTimes(false);
  $('f-err').textContent='';updateEditKind();$('scrim').classList.add('on');
}
function closeEdit(){$('scrim').classList.remove('on')}
function setEditKind(kind){
  if(kind==='task'&&!S.tasksEnabled){toast('Enable Tasks in App settings first');return}
  $('f-kind').value=kind;updateEditKind();
}
function toggleRepeatTimes(on){
  const w=$('f-repeat-times-wrap');if(w)w.style.display=on?'block':'none';
}
function updateEditKind(){
  const task=$('f-kind').value==='task';
  $('f-dose').closest('.field').style.display=task?'none':'';
  $('f-name-label').textContent=task?'Task name':'Medicine name';
  const mb=$('f-kind-medicine'),tb=$('f-kind-task');
  if(mb)mb.classList.toggle('active',!task);
  if(tb)tb.classList.toggle('active',task);
  if(tb)tb.disabled=!S.tasksEnabled;
}
$('f-kind').addEventListener('change',updateEditKind);
$('f-start').addEventListener('change',()=>{if(!editing&&!$('f-ongoing').checked&&$('f-start').value)$('f-end').value=dkey(addDays(parseD($('f-start').value),6))});
$('f-ongoing').onchange=()=>{$('f-end').disabled=$('f-ongoing').checked};
function saveEdit(){
  const og=$('f-ongoing').checked;
  const p=P();if(!p)return;
  const needsAdultReview=!!p&&profileAge(p.dob)<=18;
  const old=editing?p.meds.find(x=>x.id===editing):null;
  const kind=$('f-kind').value==='task'?'task':'medicine';
  if(kind==='task'&&!S.tasksEnabled){$('f-err').textContent='Enable Tasks in App settings before saving a task.';return}
  const o={kind,name:$('f-name').value.trim(),dose:kind==='task'?'':$('f-dose').value.trim(),time:$('f-time').value,
    days:3650,every:old?(old.every||1):1,start:$('f-start').value,notes:$('f-notes').value.trim(),review:needsAdultReview,nodur:false};
  if(!o.name||!o.time){$('f-err').textContent='Please enter a name and a time.';return}
  if(!o.start){$('f-err').textContent='Please choose a start date.';return}
  if(!og){
    const e=$('f-end').value;
    if(!e){$('f-err').textContent='Please choose an end date, or tick "No end date".';return}
    const n=Math.round((parseD(e)-parseD(o.start))/864e5)+1;
    if(n<1){$('f-err').textContent='The end date must be on or after the start date.';return}
    if(n>3649){$('f-err').textContent='That end date is too far away. Tick "No end date" instead.';return}
    o.days=n;
  }
  const extra=[];
  if($('f-repeat-enabled').checked){
    const raw=$('f-repeat-times').value.trim();
    const times=raw.split(/[,\n;]+/).map(x=>x.trim()).filter(Boolean);
    if(!times.length){$('f-err').textContent='Enter at least one additional time, or turn Repeat off.';return}
    const unique=[...new Set(times)];
    for(const t of unique){
      if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(t)){$('f-err').textContent='Use 24-hour times such as 08:00, 13:30 and 20:00.';return}
      if(t===o.time){$('f-err').textContent='The repeat times must be different from the main time.';return}
      extra.push(t);
    }
  }
  if(editing){Object.assign(p.meds.find(x=>x.id===editing),o)}
  else p.meds.push({id:p.nextId++,...o});
  extra.forEach(time=>{
    const duplicate=p.meds.some(m=>m.kind===kind&&m.name.toLowerCase()===o.name.toLowerCase()&&m.time===time&&m.start===o.start&&m.days===o.days);
    if(!duplicate)p.meds.push({id:p.nextId++,...o,time});
  });
  save();closeEdit();render();if(needsAdultReview)setTimeout(reviewNudge,250);
}
document.addEventListener('keydown',e=>{
  if(e.key!=='Enter')return;
  if($('pscrim').classList.contains('on'))saveProfile();
  else if($('scrim').classList.contains('on'))saveEdit();
  else if($('nscrim').classList.contains('on'))checkPin();
});

// ---------- adult-only prescription image OCR (text extraction only) ----------
let ocrWorker=null,ocrBusy=false;
function openPrescriptionPicker(){
  const p=P();
  if(!p||profileAge(p.dob)<=18){toast('Prescription image scanning is available only for profiles aged 19 or older.');return}
  $('rxfile').click();
}
async function scanPrescription(input){
  const file=input.files&&input.files[0];input.value='';if(!file)return;
  const p=P();
  if(!p||profileAge(p.dob)<=18){toast('This profile is not eligible for prescription image scanning.');return}
  if(!file.type||!file.type.startsWith('image/')){toast('Please choose an image file, such as JPG or PNG.');return}
  if(file.size>12*1024*1024){toast('Please choose an image smaller than 12 MB.');return}
  if(ocrBusy){toast('A scan is already running.');return}
  ocrBusy=true;const pid=p.id;$('rx-text').value='';$('rx-status').textContent='Preparing the on-device text scanner…';$('rxscrim').classList.add('on');
  let worker=null;
  try{
    if(!window.Tesseract||typeof window.Tesseract.createWorker!=='function')throw new Error('The text scanner did not load. Check your internet connection and try again, or enter the details manually.');
    worker=await window.Tesseract.createWorker('eng',1,{logger:m=>{
      if(!P()||P().id!==pid)return;
      const pct=typeof m.progress==='number'?' '+Math.round(m.progress*100)+'%':'';
      $('rx-status').textContent=(m.status||'Reading image…')+pct+' · Keep this window open.';
    }});
    ocrWorker=worker;
    const result=await worker.recognize(file);
    if(!P()||P().id!==pid){$('rx-status').textContent='Profile changed. The scan was discarded.';return}
    const text=(result&&result.data&&result.data.text||'').trim();
    $('rx-text').value=text;
    $('rx-status').textContent=text?'Text extraction finished. Check every word and number against the original image.':'No readable text was found. Try a sharper, brighter, straight-on image.';
  }catch(e){
    console.error('Prescription OCR error',e);
    $('rx-status').textContent=(e&&e.message)||'The image could not be read. Please enter the details manually.';
  }finally{
    if(worker){try{await worker.terminate()}catch(e){}}
    if(ocrWorker===worker)ocrWorker=null;ocrBusy=false;
  }
}
function closePrescriptionScan(){
  $('rxscrim').classList.remove('on');$('rx-text').value='';$('rx-status').textContent='Choose a clear, well-lit image. Text recognition can make mistakes.';
}
async function copyPrescriptionText(){
  const value=$('rx-text').value;if(!value){toast('There is no recognised text to copy.');return}
  try{await navigator.clipboard.writeText(value);toast('Recognised text copied. Please verify it against the original.');}
  catch(e){$('rx-text').focus();$('rx-text').select();try{document.execCommand('copy');toast('Text copied. Please verify it against the original.')}catch(e2){toast('Select the text and copy it manually.')}}
}

// ---------- resilient error fallback: no silent blank app screen ----------
function showAppError(message){
  try{$('app-error-msg').textContent=message||'Something interrupted this screen. Your saved data has not intentionally been erased. Try again or return to profiles.';$('app-error').classList.add('on')}catch(e){console.error('MediMate fallback unavailable',e)}
}
function recoverApp(){
  $('app-error').classList.remove('on');
  try{if(P()){goTab('home');render()}else forceShowProfiles()}catch(e){showAppError('The screen could not be restored. Your browser may be blocking local storage or required features. Return to profiles or refresh the notebook output.');}
}
function forceShowProfiles(){
  try{endRing();closeDrawer();closeOnboard();closeProfileDetails();$('app-error').classList.remove('on');store.current=null;renderChooser();$('profiles').style.display='block'}catch(e){showAppError('MediMate could not reopen the profile list. Refresh the notebook output and try again.')}
}
window.addEventListener('error',e=>{if(e.target&&e.target!==window){console.warn('Optional resource could not load',e.target.src||e.target.href||'resource');return;}console.error('MediMate error',e.error||e.message);showAppError('A screen could not be displayed correctly. Your saved data should remain in this browser. Try again or return to profiles.')});
window.addEventListener('unhandledrejection',e=>{console.error('MediMate async error',e.reason);showAppError('A background task failed. Your saved data should remain in this browser. Try again or return to profiles.')});

// ---------- start ----------
document.querySelector('#s-home .apptitle').textContent=APP;
$('warn').style.display=storageOk?'none':'block';
$('b-text').oninput=()=>{restoreArmed=false;$('b-err').textContent=''};
document.addEventListener('click',()=>{unlockAudio();enableMotion();askPermission()},{once:true,capture:true});
renderChooser();checkReminders();scheduleNative();
function receiveNativeAlarm(payload){if(!payload||!payload.profileId)return;const p=store.profiles.find(x=>String(x.id)===String(payload.profileId));if(!p)return;const med=p.meds.find(x=>String(x.id)===String(payload.medicineId));if(!med)return;openProfile(p.id);setTimeout(()=>{startRing(p,[med],false)},650)}
window.addEventListener('nativeAlarm',e=>receiveNativeAlarm(e.detail||{}));
setTimeout(async()=>{
  const sp=$('splash');sp.style.opacity=0;setTimeout(()=>sp.remove(),600);
  let rs=null;try{rs=JSON.parse(localStorage.getItem('mm_resume')||'null');localStorage.removeItem('mm_resume')}catch(e){}
  const fresh=!!(rs&&Date.now()-rs.t<30*60000);
  const intro=mxIntroNeeded();if(intro)mxIntroShow();
  if(!store.profiles.length){if(intro)(window.__afterIntro=window.__afterIntro||[]).push(openAddProfile);else openAddProfile()}
  else if(fresh&&rs.pid&&store.profiles.some(x=>x.id===rs.pid))openProfile(rs.pid);
  else if(store.profiles.length===1)openProfile(store.profiles[0].id);
  if(fresh&&rs.tab&&rs.tab!=='home'&&P()){goTab(rs.tab);render()}
  try{const ma=MA();if(ma&&ma.getLaunchAlarm){const r=await ma.getLaunchAlarm();if(r&&r.profileId)receiveNativeAlarm(r)}}catch(e){}
},1000);
window.addEventListener('load',()=>{try{document.fonts.load("24px 'Material Symbols Rounded'",'add').then(l=>document.documentElement.classList.toggle('noicons',!(l&&l.some(f=>f.status==='loaded')))).catch(()=>document.documentElement.classList.add('noicons'))}catch(e){}});

/* ================= v3.6: MedEx AI, hold-to-cancel, haptic test, phone settings ================= */
const MX={model:'oxygen',msgs:[],busy:false,file:null,recording:false,rec:null,chunks:[],recT:0};
// A fresh WebView/app launch starts a new conversation; in-app tab changes do not reload this page.
try{for(const k of Object.keys(sessionStorage))if(k.startsWith('mm_mx_session_'))sessionStorage.removeItem(k)}catch(e){}
try{const m=localStorage.getItem('mm_mx_model');if(m==='cosmos'||m==='oxygen')MX.model=m}catch(e){}
const MX_NAMES={oxygen:'Oxygen 1.0',cosmos:'Cosmos 1.0'};
const mxKey=()=>'mm_mx_session_'+(store.current||'x');
const mxArchiveKey=()=>'mm_mx_archive_'+(store.current||'x');
function mxLoad(){try{MX.msgs=JSON.parse(sessionStorage.getItem(mxKey())||'[]').slice(-40)}catch(e){MX.msgs=[]}}
function mxSave(){
  try{sessionStorage.setItem(mxKey(),JSON.stringify(MX.msgs.slice(-40)))}catch(e){}
  try{
    if(MX.msgs.length){let a=JSON.parse(localStorage.getItem(mxArchiveKey())||'[]');const id=MX.chatId||(MX.chatId='chat_'+Date.now());let c=a.find(x=>x.id===id);if(!c){c={id:id,date:Date.now(),msgs:[]};a.unshift(c)}
      c.date=Date.now();c.msgs=MX.msgs.slice(-40);localStorage.setItem(mxArchiveKey(),JSON.stringify(a.slice(0,50)))}
  }catch(e){}
}
function mxFmt(t){
  const inl=x=>esc(x).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>');
  const GAP='<div class="mx-gap"></div>',out=[];let prevText=false;
  String(t||'').replace(/\r/g,'').split('\n').forEach(raw=>{
    const l=raw.trim();
    if(!l){if(out.length&&out[out.length-1]!==GAP)out.push(GAP);prevText=false;return}
    let m;
    if(m=l.match(/^#{1,4}\s+(.*)$/)){out.push('<div class="mx-h">'+inl(m[1])+'</div>');prevText=false}
    else if(m=l.match(/^(\d+)[.)]\s+(.*)$/)){out.push('<span class="mx-ol" data-n="'+m[1]+'">'+inl(m[2])+'</span>');prevText=false}
    else if(m=l.match(/^[-*\u2022]\s+(.*)$/)){out.push('<span class="mx-li">'+inl(m[1])+'</span>');prevText=false}
    else{out.push((prevText?'<br>':'')+inl(l));prevText=true}
  });
  while(out.length&&out[out.length-1]===GAP)out.pop();
  return out.join('');
}
function mxLogoSvg(){return '<svg class="mx-logo-svg" viewBox="0 0 100 100" aria-label="MedX"><defs><linearGradient id="mxg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4285f4"/><stop offset=".34" stop-color="#34a853"/><stop offset=".68" stop-color="#fbbc04"/><stop offset="1" stop-color="#ea4335"/></linearGradient></defs><path d="M17 76V39c0-12 8-20 19-20 10 0 16 7 16 19V76M52 38c0-12 7-19 18-19 11 0 18 8 18 20v37" fill="none" stroke="url(#mxg)" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/></svg>'}
function mxRender(o){
  const L=$('mx-list');if(!L)return;
  const still=!!(o&&o.still);
  if(!MX.msgs.length&&!MX.busy){
    const p=P(),nm=p?esc(String(p.name||'').trim().split(/\s+/)[0]):'';
    const hr=new Date().getHours(),greet=hr<12?'Good morning':hr<17?'Good afternoon':'Good evening';
    L.innerHTML=`<div class="mx-empty"><div class="mx-empty-mark">${mxLogoSvg()}</div><h3>${greet}${nm?', '+nm:''}</h3><div class="mx-hq">How can I help?</div></div>`;
    MX._shown=0;MX._busyShown=false;return;
  }
  const from=still?MX.msgs.length:(MX._shown||0);
  let h=MX.msgs.map((m,i)=>{
    const me=m.role==='user',cls='mx-row '+(me?'me':'ai')+(m.err?' err':'')+(i>=from?' in':'');
    const file=m.file?'<div class="mx-file"><span class="ms">attach_file</span>'+esc(m.file)+'</div>':'';
    if(me)return `<div class="${cls}"><div class="mx-b">${file}${mxFmt(m.text)}</div></div>`;
    const via=m.via?'<div class="mx-note">Answered by '+esc(MX_NAMES[m.via]||m.via)+' (it can read files)</div>':'';
    const cp=m.err?'':`<div class="mx-acts"><button type="button" class="mx-cp" aria-label="Copy answer" onclick="mxCopy(${i})"><span class="ms">content_copy</span></button></div>`;
    return `<div class="${cls}"><span class="ms mx-spark">${m.err?'error':'auto_awesome'}</span><div class="mx-b">${mxFmt(m.text)}${via}${cp}</div></div>`;
  }).join('');
  if(MX.busy){h+=`<div class="mx-row ai${MX._busyShown?'':' in'}"><span class="mx-loading-logo">${mxLogoSvg()}</span><div class="mx-b"><div class="mx-progress">MedX is working on your question</div><div class="mx-sh"><i></i><i></i><i style="width:55%"></i></div></div></div>`;MX._busyShown=true}else MX._busyShown=false;
  L.innerHTML=h;MX._shown=MX.msgs.length;
  if(still)L.scrollTop=L.scrollHeight;else try{L.scrollTo({top:L.scrollHeight,behavior:'smooth'})}catch(e){L.scrollTop=L.scrollHeight}
}
function mxCopy(i){
  const m=MX.msgs[i];if(!m)return;const t=String(m.text||'');
  const old=()=>{try{const a=document.createElement('textarea');a.value=t;a.style.cssText='position:fixed;opacity:0';document.body.appendChild(a);a.select();document.execCommand('copy');a.remove();toast('Copied')}catch(e){toast('Could not copy')}};
  try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(()=>toast('Copied'),old);return}}catch(e){}
  old();
}
function mxHead(){
  const s=$('mx-sub');if(s)s.textContent=MX_NAMES[MX.model];
  document.querySelectorAll('.mx-opt').forEach(o=>o.classList.toggle('sel',o.dataset.k===MX.model));
}
function mxMenu(force){
  const m=$('mx-menu'),b=$('mx-model');if(!m)return;
  const on=force===undefined?!m.classList.contains('on'):force;
  m.classList.toggle('on',on);b.classList.toggle('open',on);
}
function mxPick(k){
  MX.model=k;try{localStorage.setItem('mm_mx_model',k)}catch(e){}
  mxHead();mxMenu(false);
}
document.addEventListener('pointerdown',e=>{const mm=$('mx-more-menu');if(mm&&mm.classList.contains('on')&&!e.target.closest('#mx-more-menu,.mx-more'))mxMoreToggle(false);const m=$('mx-menu');if(m&&m.classList.contains('on')&&!e.target.closest('#mx-menu,#mx-model'))mxMenu(false)},true);
function mxOpen(){
  mxLoad();mxHead();mxRender({still:true});mxMenu(false);
  try{const d=$('mx-disc');if(d&&localStorage.getItem('mm_mx_disc_seen')==='1')d.style.display='none'}catch(e){}
  let ok=false;try{ok=localStorage.getItem('mm_mx_ok')==='1'}catch(e){}
  if(!ok){
    aiSheet(`<h2>Connect with MedEx</h2><p>MedEx answers questions about your medicines using your schedule.</p>
      <p>To do this, your medicine names, doses, times, today's taken status, your age and your messages are sent to AI services (Google Gemini and Groq) through the app owner's private service. Your name and date of birth are not sent.</p>
      <p>MedEx can make mistakes. Never start, stop or change a medicine because of it. For serious or long-term medicines, always ask your doctor or pharmacist.</p>
      <div class="aib"><button onclick="aiClose();document.body.dataset.dir='prev';goTab('home');render()">Not now</button><button class="p" onclick="mxAccept()">Connect</button></div>`);
  }
}
function mxAccept(){try{localStorage.setItem('mm_mx_ok','1');localStorage.setItem('mm_mx_promo_hide','1')}catch(e){}aiClose();mxPromo()}
function mxClear(){
  mxMoreToggle(false);
  if(!MX.msgs.length)return;
  if(!window.confirm('Clear this MedX chat?'))return;
  MX.msgs=[];MX.chatId=null;try{sessionStorage.removeItem(mxKey())}catch(e){}mxRender({still:true});
}
function mxMoreToggle(force){const m=$('mx-more-menu');if(!m)return;const on=force===undefined?!m.classList.contains('on'):!!force;m.classList.toggle('on',on)}
function mxOverlayClose(){document.querySelectorAll('.mx-overlay').forEach(x=>x.classList.remove('on'))}
function mxNewChat(){
  mxMoreToggle(false);
  if(MX.busy){toast('Wait until MedX finishes the current answer.');return}
  MX.msgs=[];MX.chatId=null;MX.file=null;try{sessionStorage.removeItem(mxKey())}catch(e){}
  mxChip();mxRender({still:true});mxOverlayClose();$('mx-in').value='';mxInput();
}
function mxOpenHistory(){
  mxMoreToggle(false);mxOverlayClose();
  const v=$('mx-history-view'),L=$('mx-history-list');let a=[];
  try{a=JSON.parse(localStorage.getItem(mxArchiveKey())||'[]')}catch(e){}
  const escFn=x=>esc(String(x||''));
  const rows=[];
  a.forEach(c=>{
    const first=(c.msgs||[]).find(m=>m.role==='user'&&m.text);
    const last=[...(c.msgs||[])].reverse().find(m=>m.role==='assistant'&&!m.err&&m.text);
    const charts=(c.msgs||[]).filter(m=>m.role==='assistant'&&m.text&&/chart|graph|table|schedule overview/i.test(m.text));
    if(first)rows.push(`<button class="mx-history-item" type="button" onclick="mxRestoreChat('${escFn(c.id)}')"><b>${escFn(first.text.slice(0,72))}</b><small>${new Date(c.date).toLocaleString()} · ${(c.msgs||[]).length} messages · ${charts.length} chart-related replies</small>${last?`<p>${escFn(last.text.slice(0,130))}</p>`:''}</button>`);
  });
  L.innerHTML=rows.join('')||'<div class="mx-overlay-empty">No saved chats yet. Your conversations will appear here.</div>';
  v.classList.add('on');
}
function mxRestoreChat(id){
  let a=[];try{a=JSON.parse(localStorage.getItem(mxArchiveKey())||'[]')}catch(e){}
  const c=a.find(x=>x.id===id);if(!c)return;
  MX.msgs=(c.msgs||[]).slice(-40);MX.chatId=c.id;mxSave();mxOverlayClose();mxRender({still:true});
}
function mxOpenMemory(){
  const escFn=x=>esc(String(x||''));
  mxMoreToggle(false);mxOverlayClose();const L=$('mx-memory-list'),p=P();let facts=[];
  if(p){
    (p.meds||[]).forEach(m=>facts.push(['Scheduled medicine',`${m.name||'Medicine'}${m.dose?' · '+m.dose:''}${m.time?' · '+m.time:''}`]));
  }
  // Only explicit statements are retained as local memory; no diagnosis or condition is inferred.
  let allMsgs=MX.msgs.slice();try{JSON.parse(localStorage.getItem(mxArchiveKey())||'[]').forEach(c=>allMsgs.push(...(c.msgs||[])))}catch(e){}
  const explicit=allMsgs.filter(m=>m.role==='user').map(m=>m.text||'').filter((t,i,a)=>a.indexOf(t)===i&&/\b(i have|i am allergic to|my allergy is|allergic to|my condition is|i was diagnosed with|my doctor said i have|i take|i am taking|my health issue|my medical history|i have asthma|i have diabetes|i have epilepsy|i have high blood pressure)\b/i.test(t));
  explicit.forEach(t=>facts.push(['User-stated note',t.slice(0,220)]));
  L.innerHTML=facts.map((f,i)=>`<div class="mx-memory-item"><b>${escFn(f[0])}</b><p>${escFn(f[1])}</p><small>Stored on this device · review with a parent/guardian</small></div>`).join('')||'<div class="mx-overlay-empty">No memory points yet. Medicine schedule details will appear here when available.</div>';
  $('mx-memory-view').classList.add('on');
}
function mxEnterKey(e){if((e.key==="Enter"||e.keyCode===13)&&!e.shiftKey&&!e.isComposing){e.preventDefault();mxSendNow()}}
function mxInput(){
  const t=$('mx-in');if(!t)return;
  t.style.height='0px';t.style.height=Math.min(120,t.scrollHeight)+'px';
  const has=!!t.value.trim()||!!MX.file,b=$('mx-act');
  b.classList.toggle('send',has&&!MX.recording);
  if(!MX.recording)b.firstChild.textContent=has?'arrow_upward':'mic';
  b.setAttribute('aria-label',has?'Send':'Voice input');
}
function mxAct(){
  if(MX.recording){mxMicStop();return}
  const has=!!$('mx-in').value.trim()||!!MX.file;
  if(has)mxSendNow();else mxMic();
}
function mxAsk(t){$('mx-in').value=t;mxInput();mxSendNow()}
function mxChip(){
  const c=$('mx-chip');if(!c)return;
  c.classList.toggle('on',!!MX.file);
  c.querySelector('.n').textContent=MX.file?MX.file.name:'';
  mxInput();
}
function mxReadFile(f){
  return new Promise((res,rej)=>{
    if(f.type==='application/pdf'){const r=new FileReader();r.onload=()=>res({mime:f.type,data:String(r.result).split(',')[1]});r.onerror=()=>rej(new Error('read'));r.readAsDataURL(f);return}
    const img=new Image(),u=URL.createObjectURL(f);
    img.onload=()=>{const s=Math.min(1,1600/Math.max(img.width,img.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.width*s));c.height=Math.max(1,Math.round(img.height*s));c.getContext('2d').drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(u);res({mime:'image/jpeg',data:c.toDataURL('image/jpeg',.85).split(',')[1]})};
    img.onerror=()=>{URL.revokeObjectURL(u);rej(new Error('img'))};img.src=u;
  });
}
async function mxPickFile(inp){
  const f=inp.files&&inp.files[0];inp.value='';if(!f)return;
  if(f.size>12*1048576){toast('Please choose a file under 12 MB');return}
  if(!/^image\//.test(f.type)&&f.type!=='application/pdf'){toast('Choose a photo or a PDF');return}
  try{const r=await mxReadFile(f);MX.file={name:f.name||'file',mime:r.mime,data:r.data};mxChip();$('mx-in').focus()}catch(e){toast('Could not read that file')}
}
function mxContext(){
  const p=P(),now=new Date(),t=midnight();
  const take=m=>{const k=dkey(t)+'_'+m.id;return p.taken&&p.taken[k]?('taken at '+((p.takenAt&&p.takenAt[k])||'unknown time')):'not taken yet'};
  const meds=(p.meds||[]).filter(m=>!m.review).slice(0,40).map(m=>({kind:m.kind||'medicine',name:m.name,dose:m.dose||'',time:m.time,notes:m.notes||'',startDate:m.start||'',days:m.days>=3650?'ongoing':m.days,everyNDays:m.every||1}));
  const today=medsOn(t).filter(m=>!m.review).map(m=>({name:m.name,dose:m.dose||'',scheduledTime:m.time,status:take(m)}));
  const notes=[];try{const archive=JSON.parse(localStorage.getItem(mxArchiveKey())||'[]');archive.forEach(c=>(c.msgs||[]).filter(m=>m.role==='user').forEach(m=>{const t=String(m.text||'').trim();if(t&&/\b(i have|i am allergic to|my allergy is|allergic to|my condition is|i was diagnosed with|my doctor said i have|i take|i am taking|my health issue|my medical history|i have asthma|i have diabetes|i have epilepsy|i have high blood pressure)\b/i.test(t)&&!notes.includes(t))notes.push(t.slice(0,220))}))}catch(e){}
  MX.msgs.filter(m=>m.role==='user').forEach(m=>{const t=String(m.text||'').trim();if(t&&/\b(i have|i am allergic to|my allergy is|allergic to|my condition is|i was diagnosed with|my doctor said i have|i take|i am taking|my health issue|my medical history|i have asthma|i have diabetes|i have epilepsy|i have high blood pressure)\b/i.test(t)&&!notes.includes(t))notes.push(t.slice(0,220))});
  return {now:now.toLocaleString('en-GB',{weekday:'long',year:'numeric',month:'long',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false}),ageYears:profileAge(p.dob),dailyRoutine:p.routine||{},medicines:meds,todaySchedule:today,userNotes:notes.slice(-20)};
}
function mxErr(status,j){
  if(status===401)return 'The access code is wrong. Open App settings, then AI timetable scan, and enter the code again.';
  if(status===429)return 'Too many questions in a short time. Please wait a few minutes and try again.';
  if(status===400&&/JPG|PNG|PDF/i.test((j&&j.error)||''))return 'Your Cloudflare Worker does not have the MedEx update yet. Replace its code with the worker.js from this version and deploy it.';
  if(status===404)return 'MedEx could not be reached. Check that the AI service address is correct and the Worker is updated.';
  if(j&&j.error&&status<500)return String(j.error);
  return 'MedEx could not answer right now. Try again, or switch to the other model from the top of this screen.';
}
function mxLocalAction(text){
  const raw=String(text||'').trim(),t=raw.toLowerCase();
  const say=(s)=>{MX.msgs.push({role:'assistant',text:s});mxRender();mxSave()};
  const go=(tab,label)=>{document.body.dataset.dir='next';goTab(tab);render();say(label);return true};
  if(/\b(open|show|go to|take me to)\b.*\b(settings|app settings)\b/.test(t)){openSettings();say('App settings are open.');return true}
  if(/\b(open|show|go to|take me to)\b.*\b(schedule|timetable|medicines)\b/.test(t))return go('time','Your schedule is open.');
  if(/\b(open|show|go to|take me to)\b.*\b(calendar)\b/.test(t))return go('cal','Your calendar is open.');
  if(/\b(open|show|go to|take me to)\b.*\b(home)\b/.test(t))return go('home','Home is open.');
  const hv=t.match(/\b(?:turn|switch|set|keep)\b.*\b(haptic|vibration|vibrate)\b.*\b(on|off|enable|disable)\b|\b(haptic|vibration)\s+(on|off)\b/);
  if(hv){const on=/on|enable/.test(hv[3]||hv[5]||'');setHaptic(on);say('Button vibration is '+(on?'on':'off')+'.');return true}
  const ts=t.match(/\b(?:turn|switch|set|keep)\b.*\b(tasks?)\b.*\b(on|off|enable|disable)\b|\b(tasks?)\s+(on|off)\b/);
  if(ts){const on=/on|enable/.test(ts[3]||ts[5]||'');setTasksEnabled(on);say('Tasks are '+(on?'enabled':'hidden')+' in your schedule.');return true}
  const tm=raw.match(/\b(?:at|@)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b/i);
  let time='';if(tm){let hh=+tm[1],mm=+(tm[2]||0),ap=(tm[3]||'').toLowerCase();if(mm<=59&&hh<=23){if(ap&&hh>=1&&hh<=12)hh=hh%12+(ap==='pm'?12:0);else if(ap)hh=-1;if(hh>=0)time=pad(hh)+':'+pad(mm)}}
  const task=/\b(task|face wash|brush|reading|workout|study|water plants|walk the dog)\b/i.test(raw);
  const add=/\b(add|create|make|set up|schedule|remind me|put)\b/i.test(raw);
  if(add&&time){
    let name=raw.replace(/^(please\s*)?(add|create|make|set up|schedule|remind me to|remind me|put)\s*/i,'').replace(/\b(a\s+)?(medicine|medication|tablet|task|reminder)\b/i,' ').replace(/\b(at|@)\s*\d{1,2}(:\d{2})?\s*(am|pm)?\b/i,'').replace(/\b(to my|in my|into my)\s+(schedule|timetable)\b/i,'').replace(/\b(every day|daily)\b/i,'').replace(/[,.!?]+$/,'').trim();
    if(name.length>1){const kind=task?'task':'medicine';if(kind==='task'&&!S.tasksEnabled){S.tasksEnabled=true;saveS();renderSettings()}openEdit(null);$('f-kind').value=kind;$('f-kind').disabled=false;$('f-name').value=name;$('f-time').value=time;updateEditKind();say((kind==='task'?'Task':'Medicine reminder')+' form is ready for '+name+' at '+fmt(time)+'. Check the details and tap Save. I have not selected a medicine dose.');return true}
  }
  if(add&&/\b(medicine|medication|tablet|task|reminder)\b/i.test(raw)){say('Please include the exact name and time, for example: “Add face wash task at 7:30 AM” or “Add my prescribed medicine at 8:00 PM”. I will open the form for you to confirm.');return true}
  return false;
}
async function mxSendNow(){
  if(MX.busy||MX.recording)return;
  const inp=$('mx-in'),text=inp.value.trim();if(!text&&!MX.file)return;
  if(!AI.url||!AI.code){aiSetup();return}
  if(navigator.onLine===false){toast('No internet connection. MedEx needs Wi-Fi or mobile data.');return}
  if(!P())return;
  const file=MX.file;
  MX.msgs.push({role:'user',text:text||'Please look at this file.',file:file?file.name:''});
  inp.value='';MX.file=null;mxChip();if(!file&&mxLocalAction(text))return;MX.busy=true;mxRender();mxSave();
  const chosen=MX.model,ac=new AbortController(),tm=setTimeout(()=>ac.abort(),75000);
  try{
    const body={model:chosen,messages:MX.msgs.filter(m=>!m.err).slice(-14).map(m=>({role:m.role,text:m.text})),schedule:mxContext()};
    if(file)body.file={mime:file.mime,data:file.data};
    const r=await fetch(AI.url.replace(/\/+$/,'')+'/chat',{method:'POST',headers:{'Content-Type':'application/json','X-App-Token':AI.code},body:JSON.stringify(body),signal:ac.signal});
    const j=await r.json().catch(()=>({}));
    if(!r.ok||!j.reply)MX.msgs.push({role:'assistant',text:mxErr(r.status,j),err:true});
    else MX.msgs.push({role:'assistant',text:String(j.reply),via:j.via&&j.via!==chosen?j.via:''});
  }catch(e){
    MX.msgs.push({role:'assistant',text:e&&e.name==='AbortError'?'That took too long. Try again, or switch to Oxygen 1.0 for a faster answer.':'Could not connect. Check your internet and try again.',err:true});
  }finally{clearTimeout(tm);MX.busy=false;mxSave();mxRender()}
}
/* voice input: records, then the Worker turns the speech into text */
async function mxMic(){
  if(!AI.url||!AI.code){aiSetup();return}
  if(navigator.onLine===false){toast('No internet connection. Voice input needs Wi-Fi or mobile data.');return}
  if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia||!window.MediaRecorder){toast('Voice input is not available on this phone');return}
  let st;
  try{st=await navigator.mediaDevices.getUserMedia({audio:true})}catch(e){toast('Allow the microphone for MediMate to use voice input');return}
  const mime=['audio/webm;codecs=opus','audio/webm','audio/mp4','audio/ogg'].find(x=>{try{return MediaRecorder.isTypeSupported(x)}catch(e){return false}})||'';
  let rec;try{rec=new MediaRecorder(st,mime?{mimeType:mime}:{})}catch(e){st.getTracks().forEach(t=>t.stop());toast('Voice input is not available on this phone');return}
  MX.chunks=[];MX.rec=rec;
  rec.ondataavailable=e=>{if(e.data&&e.data.size)MX.chunks.push(e.data)};
  rec.onstop=()=>{st.getTracks().forEach(t=>t.stop());mxTranscribe(rec.mimeType||mime||'audio/webm')};
  rec.start();MX.recording=true;
  const b=$('mx-act');b.classList.remove('send');b.classList.add('rec');b.firstChild.textContent='stop';$('mx-in').placeholder='Listening\u2026 tap to stop';
  MX.recT=setTimeout(mxMicStop,60000);
}
function mxMicStop(){
  clearTimeout(MX.recT);if(!MX.recording)return;MX.recording=false;
  const b=$('mx-act');b.classList.remove('rec');b.classList.add('wait');b.firstChild.textContent='more_horiz';$('mx-in').placeholder='Converting to text\u2026';
  try{MX.rec.stop()}catch(e){mxMicDone()}
}
function mxMicDone(){const b=$('mx-act');if(!b)return;b.classList.remove('rec','wait');$('mx-in').placeholder='Ask MedEx';mxInput()}
async function mxTranscribe(mime){
  try{
    const blob=new Blob(MX.chunks,{type:mime});
    if(blob.size<1500){toast('I did not hear anything. Try again.');return}
    const data=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(String(r.result).split(',')[1]);r.onerror=rej;r.readAsDataURL(blob)});
    const ac=new AbortController(),tm=setTimeout(()=>ac.abort(),40000);
    let r,j;
    try{r=await fetch(AI.url.replace(/\/+$/,'')+'/stt',{method:'POST',headers:{'Content-Type':'application/json','X-App-Token':AI.code},body:JSON.stringify({mime:mime.split(';')[0],data}),signal:ac.signal});j=await r.json().catch(()=>({}))}
    finally{clearTimeout(tm)}
    if(!r.ok||typeof j.text!=='string'){toast(r.status===401?'Wrong access code':'Could not convert your voice. Try again.');return}
    const t=j.text.trim();if(!t){toast('I did not hear anything. Try again.');return}
    const inp=$('mx-in');inp.value=(inp.value?inp.value.trim()+' ':'')+t;inp.focus();
  }catch(e){toast('Could not convert your voice. Try again.')}
  finally{mxMicDone()}
}
/* keep the keyboard from squeezing the screen: hide the bottom bar while typing */
document.addEventListener('focusin',e=>{if(e.target&&e.target.id==='mx-in')document.body.classList.add('mx-typing')});
document.addEventListener('focusout',e=>{if(e.target&&e.target.id==='mx-in')setTimeout(()=>document.body.classList.remove('mx-typing'),80)});

/* Home card: Connect with MedEx */
function mxPromo(){
  const h=$('mxpromo');if(!h)return;
  let hide=false;try{hide=localStorage.getItem('mm_mx_promo_hide')==='1'}catch(e){}
  if(hide){if(h.dataset.k!=='0'){h.dataset.k='0';h.innerHTML=''}return}
  if(h.dataset.k==='1')return;h.dataset.k='1';
  h.innerHTML=`<div class="mx-promo"><div class="pi"><svg class="mx-m-mark" viewBox="0 0 100 100" aria-hidden="true"><defs><linearGradient id="mxmarkpromo" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4285f4"/><stop offset=".34" stop-color="#34a853"/><stop offset=".68" stop-color="#fbbc04"/><stop offset="1" stop-color="#ea4335"/></linearGradient></defs><path d="M17 76V39c0-12 8-20 19-20 10 0 16 7 16 19V76M52 38c0-12 7-19 18-19 11 0 18 8 18 20v37" fill="none" stroke="url(#mxmarkpromo)" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/></svg></div><div class="pt"><b>Meet MedEx</b><small>Ask about your doses and timing. It already knows your schedule.</small></div><button class="pb" onclick="mxGo()">Connect</button><button class="px" aria-label="Dismiss" onclick="mxPromoHide()"><span class="ms">close</span></button></div>`;
}
function mxPromoHide(){try{localStorage.setItem('mm_mx_promo_hide','1')}catch(e){}mxPromo()}
function mxGo(){document.body.dataset.dir='next';goTab('ai');render()}

/* tab switching: add the MedEx screen */
(function(){
  const _goTab=goTab;
  goTab=function(name){
    _goTab(name);
    document.body.classList.toggle('mx-on',name==='ai');
    if(name!=='ai'){document.body.classList.remove('mx-typing');mxMenu(false)}
    if(name==='ai')mxOpen();
    if(name==='home')mxPromo();
  };
  const _render=render;
  render=function(){_render.apply(this,arguments);try{mxPromo()}catch(e){}};
  window.addEventListener('load',()=>setTimeout(()=>{try{mxPromo()}catch(e){}},400));
})();

/* ---- hold the middle button of the reminder screen for 3 seconds = cancel ---- */
const HOLD={raf:0,t0:0};
function holdStart(){
  holdStop();const th=$('sl-thumb');if(!th)return;HOLD.t0=performance.now();th.classList.add('holding');
  const step=()=>{const f=Math.min(1,(performance.now()-HOLD.t0)/3000);th.style.setProperty('--hp',(f*360)+'deg');if(f>=1){holdFire();return}HOLD.raf=requestAnimationFrame(step)};
  HOLD.raf=requestAnimationFrame(step);
}
function holdStop(){cancelAnimationFrame(HOLD.raf);const th=$('sl-thumb');if(th){th.classList.remove('holding');th.style.setProperty('--hp','0deg')}}
function holdFire(){holdStop();if(SL.done||!ring.active)return;SL.on=false;hap('click');slideReset(true);ringCancel()}
function ringCancel(){
  const test=ring.test;
  endRing();                                  // stops the sound and closes the screen; nothing is marked taken and nothing is snoozed
  ringFinish().then(closing=>{if(closing)return;toast(test?'Test cancelled':'Reminder cancelled. The medicine stays on your list. Open MediMate when you are ready.')});
}

/* ---- haptic test + phone settings ---- */
async function testHaptic(){
  try{
    const m=MA();
    if(!m||!m.haptic){if(navigator.vibrate){navigator.vibrate(80);toast('Vibration sent (browser method)')}else toast('This phone cannot vibrate');return}
    const r=await m.haptic({kind:'click'});
    if(r&&r.path==='none')toast('No vibration motor was found on this phone');
    else toast('Vibration sent ('+((r&&r.path)||'ok')+'). If you felt nothing, turn off Battery saver and turn on Vibration feedback in the phone\'s Sound settings.',null,6000);
  }catch(e){toast('Could not vibrate: '+((e&&e.message)||e))}
}
async function openOemSettings(){
  try{const m=MA();if(m&&m.openOemSettings)await m.openOemSettings();else if(m&&m.openAppSettings)await m.openAppSettings()}catch(e){}
}

/* ---- MedEx privacy slide: shown once when the app opens, then Home (never Schedule) ---- */
function mxIntroNeeded(){try{return localStorage.getItem('mm_mx_intro')!=='1'}catch(e){return false}}
function mxIntroShow(){
  const el=$('mxintro');if(!el)return;
  let ok=false;try{ok=localStorage.getItem('mm_mx_ok')==='1'}catch(e){}
  $('mi-go').textContent=ok?'Continue':'Connect';$('mi-no').style.display=ok?'none':'';
  window.__introOn=true;el.classList.add('on');
}
function mxIntroClose(connect){
  const el=$('mxintro');if(!el||!window.__introOn)return;
  try{localStorage.setItem('mm_mx_intro','1');if(connect){localStorage.setItem('mm_mx_ok','1');localStorage.setItem('mm_mx_promo_hide','1')}}catch(e){}
  window.__introOn=false;
  el.classList.add('out');
  setTimeout(()=>{el.classList.remove('on','out')},240);
  try{mxPromo()}catch(e){}
  if(connect)toast('MedEx connected');
  try{askPermission()}catch(e){}
  const q=window.__afterIntro||[];window.__afterIntro=null;
  q.forEach(f=>{try{f()}catch(e){}});
  setTimeout(()=>{try{if($('nscrim').classList.contains('on'))$('n-pin').focus()}catch(e){}},260);
}
function mxIntroTerms(){
  openTerms();
  setTimeout(()=>{try{const c=document.querySelector('#tscrim .terms'),p=[...c.querySelectorAll('p')].find(x=>/^7B\./.test(x.textContent.trim()));if(c&&p)c.scrollTop+=p.getBoundingClientRect().top-c.getBoundingClientRect().top}catch(e){}},60);
}
(function(){
  const _ap=askPermission;askPermission=function(){if(window.__introOn)return;return _ap.apply(this,arguments)};
  document.addEventListener('focusin',e=>{if(window.__introOn&&e.target&&e.target.blur&&!(e.target.closest&&e.target.closest('#mxintro')))e.target.blur()},true);
})();


;
document.addEventListener('contextmenu',e=>{if(e.target.closest('input,textarea,[contenteditable="true"]'))return;e.preventDefault()},true);
;

(function(){
 document.addEventListener('contextmenu',function(e){
   const bubble=e.target.closest&&e.target.closest('#mx-list .mx-b');if(!bubble)return;
   const row=bubble.closest('.mx-row'),rows=[...document.querySelectorAll('#mx-list .mx-row')];
   const index=rows.indexOf(row),msg=MX.msgs[index];if(!msg)return;
   const old=document.getElementById('mx-msg-actions');if(old)old.remove();
   const menu=document.createElement('div');menu.id='mx-msg-actions';
   menu.style.cssText='position:fixed;z-index:99999;left:'+Math.max(8,Math.min(innerWidth-158,e.clientX))+'px;top:'+Math.max(8,Math.min(innerHeight-100,e.clientY))+'px;background:#fff;border:1px solid #dadce0;border-radius:14px;box-shadow:0 4px 18px #0002;padding:6px;display:flex;gap:4px';
   const add=(label,fn)=>{const b=document.createElement('button');b.textContent=label;b.style.cssText='border:0;background:#f1f3f4;border-radius:10px;padding:9px 12px;color:#202124';b.onclick=()=>{menu.remove();fn()};menu.appendChild(b)};
   add('Copy',()=>mxCopy(index));
   if(msg.role==='user')add('Edit',()=>{MX.msgs=MX.msgs.slice(0,index);mxSave();mxRender({still:true});const input=$('mx-in');input.value=msg.text||'';mxInput();input.focus()});
   document.body.appendChild(menu);
   const remove=()=>{menu.remove();document.removeEventListener('pointerdown',remove,true)};
   setTimeout(()=>document.addEventListener('pointerdown',remove,true),0);
 },false);
})();
