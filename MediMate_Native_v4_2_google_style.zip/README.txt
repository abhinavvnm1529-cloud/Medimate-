MediMate native project (Capacitor + custom MediMateAlarm plugin).

Upload this ZIP to the target GitHub repository. It includes a GitHub Actions workflow to build the APK on tags (v3.0+) and manually from Actions. Tag v3.9 to publish the APK asset for the in-app updater.

worker/ = AI timetable service (Cloudflare Worker). Redeploy worker/worker.js if the AI service endpoint needs updates.

Android alarm behavior depends on device permissions and OEM restrictions. Full-screen intents may require enabling the app's full-screen alarm permission and notification permissions in Android settings. The app's installer update flow downloads in-app, but Android's system confirmation cannot be silently bypassed.

Profile, medicine schedule and history data remain in local WebView storage. Do not uninstall or clear app data when updating. Backups are unencrypted; keep them private.


Release version: 3.9.0 (28 November 2026). See CHANGELOG_3.9.txt for updates. MedEx setup: see SETUP_MEDEX.txt.

To publish: upload this ZIP's files to the repository, then create the tag v3.9 (exactly this name). The in-app updater compares the tag with the installed version and downloads the .apk attached to the newest release. Do not change native/debug.keystore: the same key keeps updates from 3.8 to 3.9 installing in place.

Deploy worker/worker.js to the existing Cloudflare Worker to update MedEx response behaviour.


MediMate Native v4.0: see CHANGELOG_4.0.txt. Rebuild the Android APK after replacing the project files. Native vibration changes are in native/MediMateAlarmPlugin.java.

Version 4.0 maintenance refinement:
The original MediMate logo is retained for the app; the multicolour M is used for MedX AI. Settings are now forced to an opaque Google-style surface. Swipe left/right between Home, Schedule, Calendar and MedX AI. MedX can navigate the app, change supported settings and prepare schedule edits; edits require Save confirmation and removals require confirmation. Native vibration code is retained from v3.7. App version remains 4.0.
