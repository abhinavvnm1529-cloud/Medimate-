package com.abhi.medimate;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {
    static final String CH = "medimate_alarm_v1";

    @Override
    public void onReceive(Context c, Intent in) {
        int id = in.getIntExtra("id", 1);
        String title = in.getStringExtra("title");
        String body = in.getStringExtra("body");
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        int tone = c.getSharedPreferences("mm_setup", Context.MODE_PRIVATE).getInt("tone", 0);
        final String chId = "medimate_alarm_t" + tone;
        int resId = c.getResources().getIdentifier("tone" + (tone + 1), "raw", c.getPackageName());
        Uri sound = resId != 0 ? Uri.parse("android.resource://" + c.getPackageName() + "/" + resId)
                : RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(chId, "Medicine alarms", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Rings like a call at medicine time");
            ch.enableVibration(true);
            ch.setVibrationPattern(new long[]{0, 800, 500, 800, 500, 800});
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            ch.setBypassDnd(true);
            ch.setSound(sound, new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, chId)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title == null ? "Medicine time" : title)
                .setContentText(body == null ? "" : body)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setOngoing(false)
                .setTimeoutAfter(120000)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true);
        if (Build.VERSION.SDK_INT < 26) {
            b.setSound(sound).setVibrate(new long[]{0, 800, 500, 800, 500, 800});
        }
        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT;
        nm.notify(id, n);
    }
}
