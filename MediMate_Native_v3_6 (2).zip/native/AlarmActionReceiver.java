package com.abhi.medimate;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * The "Taken" and "Snooze" buttons on the alarm / 15-minute notifications.
 * Works even when the app is closed. Taken records the EXACT time the button was pressed.
 */
public class AlarmActionReceiver extends BroadcastReceiver {
    static final String PENDING = "mm_pending";
    static final long SNOOZE_MS = 10 * 60 * 1000L;
    static final int SNOOZE_BASE = 900000;

    @Override
    public void onReceive(Context c, Intent in) {
        try {
            String act = in.getStringExtra("act");
            if ("snooze".equals(act)) snooze(c, in); else taken(c, in);
        } catch (Exception ignored) { }
    }

    private void taken(Context c, Intent in) throws Exception {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        int nid = in.getIntExtra("nid", -1);
        int selfId = in.getIntExtra("selfId", -1);
        if (nid >= 0) nm.cancel(nid);

        java.util.HashSet<Integer> gone = new java.util.HashSet<>();
        if (selfId >= 0) gone.add(selfId);
        String ids = in.getStringExtra("mainIds");
        if (ids != null && !ids.isEmpty()) {
            for (String part : ids.split(",")) {
                try {
                    int mid = Integer.parseInt(part.trim());
                    gone.add(mid);
                    PendingIntent pi = PendingIntent.getBroadcast(c, mid, AlarmScheduler.baseIntent(c, mid),
                            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                    if (pi != null) { am.cancel(pi); pi.cancel(); }
                    nm.cancel(mid);
                } catch (Exception ignored) { }
            }
        }
        if (selfId >= 0) {
            PendingIntent pi = PendingIntent.getBroadcast(c, selfId, AlarmScheduler.baseIntent(c, selfId),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) { am.cancel(pi); pi.cancel(); }
        }

        // remember what was taken and exactly when; the app records it the next time it opens
        long now = System.currentTimeMillis();
        SharedPreferences sp = c.getSharedPreferences(PENDING, Context.MODE_PRIVATE);
        JSONArray all = new JSONArray(sp.getString("taken", "[]"));
        String t = in.getStringExtra("taken");
        if (t != null && !t.isEmpty()) {
            JSONArray add = new JSONArray(t);
            for (int i = 0; i < add.length(); i++) {
                JSONObject o = add.getJSONObject(i);
                o.put("ts", now);
                all.put(o);
            }
        }
        sp.edit().putString("taken", all.toString()).apply();
        removeFromSaved(c, gone);
        Toast.makeText(c, "Marked as taken", Toast.LENGTH_SHORT).show();
    }

    private void snooze(Context c, Intent in) throws Exception {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        int nid = in.getIntExtra("nid", -1);
        int selfId = in.getIntExtra("selfId", 1);
        if (nid >= 0) nm.cancel(nid);
        long until = System.currentTimeMillis() + SNOOZE_MS;

        // 1) ring again in 10 minutes, even if the app stays closed
        JSONObject o = new JSONObject();
        int newId = SNOOZE_BASE + (Math.abs(selfId) % 90000);
        o.put("id", newId);
        o.put("at", until);
        o.put("kind", "alarm");
        o.put("title", in.getStringExtra("title"));
        o.put("body", in.getStringExtra("body"));
        o.put("profileId", in.getLongExtra("profileId", -1));
        o.put("medicineId", in.getLongExtra("medicineId", -1));
        o.put("profileName", in.getStringExtra("profileName"));
        o.put("medicineName", in.getStringExtra("medicineName"));
        o.put("dose", in.getStringExtra("dose"));
        o.put("time", in.getStringExtra("time"));
        String t = in.getStringExtra("taken");
        o.put("taken", t == null ? "" : t);
        AlarmScheduler.addOne(c, o);

        // 2) tell the app, so the snooze is also kept in its own list
        SharedPreferences sp = c.getSharedPreferences(PENDING, Context.MODE_PRIVATE);
        JSONArray all = new JSONArray(sp.getString("snoozed", "[]"));
        if (t != null && !t.isEmpty()) {
            JSONArray add = new JSONArray(t);
            for (int i = 0; i < add.length(); i++) {
                JSONObject s = add.getJSONObject(i);
                s.put("until", until);
                all.put(s);
            }
        }
        sp.edit().putString("snoozed", all.toString()).apply();
        Toast.makeText(c, "Snoozed for 10 minutes", Toast.LENGTH_SHORT).show();
    }

    /** keep the saved alarm list in step so a reboot does not bring cancelled alarms back */
    static void removeFromSaved(Context c, java.util.Set<Integer> gone) {
        try {
            SharedPreferences ap = c.getSharedPreferences(AlarmScheduler.PREFS, Context.MODE_PRIVATE);
            JSONArray old = new JSONArray(ap.getString(AlarmScheduler.KEY, "[]"));
            JSONArray kept = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.getJSONObject(i);
                if (!gone.contains(o.optInt("id", -1))) kept.put(o);
            }
            ap.edit().putString(AlarmScheduler.KEY, kept.toString()).apply();
        } catch (Exception ignored) { }
    }
}
