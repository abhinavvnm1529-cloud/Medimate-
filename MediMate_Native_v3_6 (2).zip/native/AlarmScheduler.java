package com.abhi.medimate;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

public class AlarmScheduler {
    static final String PREFS = "mm_alarms";
    static final String KEY = "items";

    static Intent baseIntent(Context c, int id) {
        Intent in = new Intent(c, AlarmReceiver.class);
        in.setAction("com.abhi.medimate.ALARM." + id);
        return in;
    }

    static void cancelAll(Context c, AlarmManager am) {
        try {
            SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String old = sp.getString(KEY, "[]");
            JSONArray arr = new JSONArray(old);
            for (int i = 0; i < arr.length(); i++) {
                int id = arr.getJSONObject(i).getInt("id");
                PendingIntent pi = PendingIntent.getBroadcast(c, id, baseIntent(c, id),
                        PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                if (pi != null) { am.cancel(pi); pi.cancel(); }
            }
        } catch (Exception ignored) { }
    }

    /** The 15-minute heads-up: exact when Android allows it, otherwise falls back to an alarm-clock entry. */
    static void scheduleEarly(AlarmManager am, long at, PendingIntent show, PendingIntent pi) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pi);
            } else if (android.os.Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (SecurityException e) {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pi);
        }
    }

    /** Builds the PendingIntent for one saved alarm and registers it with Android. */
    static void scheduleOne(Context c, AlarmManager am, PendingIntent show, JSONObject o) throws Exception {
        int id = o.getInt("id");
        long at = o.getLong("at");
        Intent in = baseIntent(c, id);
        in.putExtra("id", id);
        in.putExtra("title", o.optString("title", "Medicine time"));
        in.putExtra("body", o.optString("body", ""));
        in.putExtra("profileId", o.optLong("profileId", -1));
        in.putExtra("medicineId", o.optLong("medicineId", -1));
        in.putExtra("profileName", o.optString("profileName", ""));
        in.putExtra("medicineName", o.optString("medicineName", ""));
        in.putExtra("dose", o.optString("dose", ""));
        in.putExtra("time", o.optString("time", ""));
        String kind = o.optString("kind", "alarm");
        in.putExtra("kind", kind);
        in.putExtra("taken", o.optString("taken", ""));
        in.putExtra("mainIds", o.optString("mainIds", ""));
        PendingIntent pi = PendingIntent.getBroadcast(c, id, in,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        if ("early".equals(kind)) scheduleEarly(am, at, show, pi);
        else am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pi);
    }

    static PendingIntent showIntent(Context c) {
        return PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Adds one alarm created natively (a snooze from the notification) to the saved list and schedules it. */
    public static void addOne(Context c, JSONObject o) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray old = new JSONArray(sp.getString(KEY, "[]"));
            JSONArray kept = new JSONArray();
            int id = o.getInt("id");
            for (int i = 0; i < old.length(); i++) {
                if (old.getJSONObject(i).optInt("id", -1) != id) kept.put(old.getJSONObject(i));
            }
            kept.put(o);
            scheduleOne(c, am, showIntent(c), o);
            sp.edit().putString(KEY, kept.toString()).apply();
        } catch (Exception ignored) { }
    }

    public static void scheduleAll(Context c, JSONArray items) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        JSONArray kept = new JSONArray();
        try {
            cancelAll(c, am);
            long now = System.currentTimeMillis();
            PendingIntent show = showIntent(c);
            for (int i = 0; i < items.length(); i++) {
                try {
                    JSONObject o = items.getJSONObject(i);
                    if (o.getLong("at") <= now) continue;
                    scheduleOne(c, am, show, o);
                    kept.put(o);
                } catch (Exception ignored) { }   // skip this one alarm, keep scheduling the others
            }
        } catch (Exception ignored) {
        } finally {
            // always record what was really scheduled, so the next run can cancel it (no orphaned alarms)
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, kept.toString()).apply();
        }
    }
}
