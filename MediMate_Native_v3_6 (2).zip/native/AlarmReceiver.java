package com.abhi.medimate;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {
    static final String EARLY_PREFIX = "medimate_early_s";
    static final int EARLY_BASE = 100000;

    static Uri toneUri(Context c) {
        String toneUri = c.getSharedPreferences("mm_setup", Context.MODE_PRIVATE).getString("toneUri", "");
        Uri sound = (toneUri == null || toneUri.isEmpty()) ? RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) : Uri.parse(toneUri);
        if (sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        return sound;
    }

    static void makeChannel(NotificationManager nm, String id, String name, String desc, Uri sound) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationChannel ch = new NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription(desc);
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 800, 500, 800, 500, 800});
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        ch.setBypassDnd(true);
        ch.setSound(sound, new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        nm.createNotificationChannel(ch);
    }

    /** Taken / Snooze button, handled by AlarmActionReceiver even when the app is closed. */
    static PendingIntent actionPi(Context c, Intent in, int id, int nid, String act, int reqBase) {
        Intent a = new Intent(c, AlarmActionReceiver.class);
        a.setAction("com.abhi.medimate." + act.toUpperCase(java.util.Locale.ROOT) + "." + id);
        a.putExtra("act", act);
        a.putExtra("nid", nid);
        a.putExtra("selfId", id);
        a.putExtra("taken", in.getStringExtra("taken"));
        a.putExtra("mainIds", in.getStringExtra("mainIds"));
        a.putExtra("title", in.getStringExtra("title"));
        a.putExtra("body", in.getStringExtra("body"));
        a.putExtra("profileId", in.getLongExtra("profileId", -1));
        a.putExtra("medicineId", in.getLongExtra("medicineId", -1));
        a.putExtra("profileName", in.getStringExtra("profileName"));
        a.putExtra("medicineName", in.getStringExtra("medicineName"));
        a.putExtra("dose", in.getStringExtra("dose"));
        a.putExtra("time", in.getStringExtra("time"));
        return PendingIntent.getBroadcast(c, reqBase + id, a,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    @Override
    public void onReceive(Context c, Intent in) {
        int id = in.getIntExtra("id", 1);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        Uri sound = toneUri(c);
        final String hash = Integer.toHexString(String.valueOf(sound).hashCode());
        if ("early".equals(in.getStringExtra("kind"))) { postEarly(c, nm, in, id, sound, hash); return; }

        String title = in.getStringExtra("title");
        String body = in.getStringExtra("body");
        final String chId = "medimate_alarm_s" + hash;
        makeChannel(nm, chId, "Medicine alarms", "Rings like a call at medicine time", sound);

        Intent open = new Intent(c, MainActivity.class);
        open.setAction("com.abhi.medimate.OPEN_ALARM");
        open.putExtra("alarmLaunch", true);
        open.putExtra("profileId", in.getLongExtra("profileId", -1));
        open.putExtra("medicineId", in.getLongExtra("medicineId", -1));
        open.putExtra("profileName", in.getStringExtra("profileName"));
        open.putExtra("medicineName", in.getStringExtra("medicineName"));
        open.putExtra("dose", in.getStringExtra("dose"));
        open.putExtra("time", in.getStringExtra("time"));
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, chId)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title == null ? "Medicine time" : title)
                .setContentText(body == null ? "" : body)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setOngoing(true)
                .setTimeoutAfter(120000)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true);
        // like an incoming call: answer it from the notification itself, without opening the app
        String taken = in.getStringExtra("taken");
        if (taken != null && !taken.isEmpty()) {
            b.addAction(android.R.drawable.ic_lock_idle_alarm, "Snooze 10 min", actionPi(c, in, id, id, "snooze", 300000));
            b.addAction(android.R.drawable.checkbox_on_background, "Taken", actionPi(c, in, id, id, "taken", 200000));
        }
        if (Build.VERSION.SDK_INT < 26) {
            b.setSound(sound).setVibrate(new long[]{0, 800, 500, 800, 500, 800});
        }
        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT;
        nm.notify(id, n);
    }

    /** "Coming up" notification before the dose: rings once, stays on screen, and has a Taken button. */
    private void postEarly(Context c, NotificationManager nm, Intent in, int id, Uri sound, String hash) {
        final String chId = EARLY_PREFIX + hash;
        makeChannel(nm, chId, "Early reminders", "A heads-up shortly before a medicine", sound);
        int nid = EARLY_BASE + id;
        String title = in.getStringExtra("title");
        String body = in.getStringExtra("body");
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(c, nid, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, chId)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title == null ? "Medicine coming up" : title)
                .setContentText(body == null ? "" : body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body == null ? "" : body))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setTimeoutAfter(16 * 60 * 1000L)
                .setContentIntent(openPi)
                .addAction(android.R.drawable.checkbox_on_background, "Taken", actionPi(c, in, id, nid, "taken", 200000));
        if (Build.VERSION.SDK_INT < 26) {
            b.setSound(sound).setVibrate(new long[]{0, 600, 300, 600});
        }
        nm.notify(nid, b.build());
    }
}
