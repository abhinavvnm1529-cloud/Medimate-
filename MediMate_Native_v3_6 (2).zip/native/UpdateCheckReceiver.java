package com.abhi.medimate;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

/**
 * Once a day (a tiny, non-waking check) looks for a newer MediMate release and, if there is one,
 * shows a notification. Nothing runs in between, so it costs almost no battery.
 */
public class UpdateCheckReceiver extends BroadcastReceiver {
    static final String CH = "medimate_update";
    static final int NID = 424242;
    static final String ACTION = "com.abhi.medimate.UPDATE_CHECK";

    static PendingIntent pending(Context c) {
        Intent i = new Intent(c, UpdateCheckReceiver.class).setAction(ACTION);
        return PendingIntent.getBroadcast(c, 77, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** (Re)arms the daily check. Safe to call many times. */
    static void schedule(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            am.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + AlarmManager.INTERVAL_HOUR * 6,
                    AlarmManager.INTERVAL_DAY, pending(c));
        } catch (Exception ignored) { }
    }

    static String installedVersion(Context c) {
        try { return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName; }
        catch (Exception e) { return "0"; }
    }

    static boolean newer(String a, String b) {
        String[] x = a.replaceAll("[^0-9.]", "").split("\\."), y = b.replaceAll("[^0-9.]", "").split("\\.");
        for (int i = 0; i < Math.max(x.length, y.length); i++) {
            int p = 0, q = 0;
            try { p = i < x.length ? Integer.parseInt(x[i]) : 0; } catch (Exception ignored) { }
            try { q = i < y.length ? Integer.parseInt(y[i]) : 0; } catch (Exception ignored) { }
            if (p != q) return p > q;
        }
        return false;
    }

    /** Shows the "update available" notification once per version. */
    static void notifyVersion(Context c, String ver) {
        try {
            SharedPreferences sp = c.getSharedPreferences("mm_setup", Context.MODE_PRIVATE);
            if (ver.equals(sp.getString("upd_notified", ""))) return;
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(c,
                    android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CH, "App updates", NotificationManager.IMPORTANCE_DEFAULT);
                ch.setDescription("Tells you when a new MediMate version is ready");
                nm.createNotificationChannel(ch);
            }
            Intent open = new Intent(c, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi = PendingIntent.getActivity(c, NID, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new NotificationCompat.Builder(c, CH)
                    .setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle("MediMate " + ver + " is available")
                    .setContentText("Open MediMate to update. Your medicines and history stay safe.")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setCategory(NotificationCompat.CATEGORY_RECOMMENDATION)
                    .setAutoCancel(true)
                    .setContentIntent(pi)
                    .build();
            nm.notify(NID, n);
            sp.edit().putString("upd_notified", ver).apply();
        } catch (Exception ignored) { }
    }

    @Override
    public void onReceive(final Context c, Intent in) {
        final PendingResult pr = goAsync();
        new Thread(() -> {
            HttpURLConnection h = null;
            try {
                String api = c.getSharedPreferences("mm_setup", Context.MODE_PRIVATE).getString("upd_api", "");
                if (api == null || !api.startsWith("https://api.github.com/")) return;
                h = (HttpURLConnection) new URL(api).openConnection();
                h.setConnectTimeout(8000);
                h.setReadTimeout(8000);
                h.setRequestProperty("Accept", "application/vnd.github+json");
                h.setRequestProperty("User-Agent", "MediMate-Updater");
                if (h.getResponseCode() != 200) return;
                InputStream is = h.getInputStream();
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] b = new byte[8192]; int n;
                while ((n = is.read(b)) > 0 && bo.size() < 400000) bo.write(b, 0, n);
                is.close();
                JSONObject j = new JSONObject(bo.toString("UTF-8"));
                String tag = j.optString("tag_name", "");
                if (!tag.matches("^v?\\d+(\\.\\d+)*$")) return;
                String ver = tag.replaceFirst("^v", "");
                boolean hasApk = false;
                org.json.JSONArray as = j.optJSONArray("assets");
                for (int i = 0; as != null && i < as.length(); i++)
                    if (as.getJSONObject(i).optString("name", "").toLowerCase().endsWith(".apk")) hasApk = true;
                if (hasApk && newer(ver, installedVersion(c))) notifyVersion(c, ver);
            } catch (Exception ignored) {
            } finally {
                try { if (h != null) h.disconnect(); } catch (Exception ignored) { }
                pr.finish();
            }
        }).start();
    }
}
