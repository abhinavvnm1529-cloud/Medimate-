package com.abhi.medimate;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONArray;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        try {
            String s = c.getSharedPreferences(AlarmScheduler.PREFS, Context.MODE_PRIVATE)
                    .getString(AlarmScheduler.KEY, "[]");
            AlarmScheduler.scheduleAll(c, new JSONArray(s));
        } catch (Exception ignored) { }
        try { UpdateCheckReceiver.schedule(c); } catch (Exception ignored) { }
        try {
            // Only reopen MediMate after an update the person started from inside the app,
            // so an update done any other way never pops the app open unexpectedly.
            if (Intent.ACTION_MY_PACKAGE_REPLACED.equals(in.getAction())) {
                long until = c.getSharedPreferences("mm_setup", Context.MODE_PRIVATE).getLong("relaunch_until", 0);
                if (until > System.currentTimeMillis()) {
                    c.getSharedPreferences("mm_setup", Context.MODE_PRIVATE).edit().remove("relaunch_until").apply();
                    Intent open = new Intent(c, MainActivity.class);
                    open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    c.startActivity(open);
                }
            }
        } catch (Exception ignored) { }
    }
}
