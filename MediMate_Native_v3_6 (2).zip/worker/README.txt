MediMate AI service (Cloudflare Worker) - v3.6

1. Cloudflare dashboard > Workers & Pages > open your existing worker > Edit code.
2. Replace ALL the code with worker.js from this folder, then Deploy.
3. Settings > Variables and Secrets. Keep the two you already have:
     GEMINI_API_KEY  (Secret)  Google AI Studio key, used by the scan and by Cosmos
     APP_TOKEN       (Secret)  the access code you type in the app
   Add these new ones:
     OXYGEN_KEY      (Secret)  your Groq key (console.groq.com > API Keys)
     COSMOS_MODEL    (Text)    optional. Default gemini-3.8-flash. For best accuracy put the strongest Gemini model your key can use (copy the exact name from aistudio.google.com)
     OXYGEN_MODEL    (Text)    optional. Default llama-3.3-70b-versatile. Copy a current model name from console.groq.com/docs/models if it ever stops working
     GEMINI_MODEL    (Text)    optional. Scan model; leave empty
   Save and deploy again after adding variables.
4. Test chat:
   curl -X POST <worker-url>/chat -H "X-App-Token: <code>" -H "Content-Type: application/json" -d '{"model":"oxygen","messages":[{"role":"user","text":"Hello"}]}'
   Expected: {"reply":"...","via":"oxygen"}
Notes: if Oxygen is down or OXYGEN_KEY is missing, the worker answers with Gemini instead (the app shows a small note). Files are always read by Cosmos. Voice uses Groq Whisper, or Gemini if there is no Groq key.
