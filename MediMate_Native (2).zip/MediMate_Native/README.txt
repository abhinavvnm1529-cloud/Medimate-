MediMate native project (Capacitor + custom MediMateAlarm plugin).
Upload this ZIP to a GitHub repo together with .github/workflows/build.yml.
GitHub builds the APK automatically and publishes it under Releases.
