MediMate native project (Capacitor + custom MediMateAlarm plugin).
Application version: 2.2
Upload this ZIP to a GitHub repo together with .github/workflows/build.yml.
GitHub builds the APK automatically and publishes it under Releases.

worker/  = the AI timetable service (Cloudflare Worker). Redeploy worker/worker.js to fix
           "AI service error (404)". See worker/README.txt.
