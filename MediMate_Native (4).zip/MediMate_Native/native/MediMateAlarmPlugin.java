package com.abhi.medimate;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONArray;

@CapacitorPlugin(name = "MediMateAlarm")
public class MediMateAlarmPlugin extends Plugin {

    private boolean notifGranted() {
        return Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(getContext(),
                Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void requestSetup(PluginCall call) {
        try {
            if (!notifGranted()) {
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4711);
            }
        } catch (Exception ignored) { }
        call.resolve(new JSObject());
    }

    @Override
    protected void handleOnResume() {
        super.handleOnResume();
        try {
            if (Build.VERSION.SDK_INT >= 34 && notifGranted()) {
                NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
                SharedPreferences sp = getContext().getSharedPreferences("mm_setup", Context.MODE_PRIVATE);
                if (!nm.canUseFullScreenIntent() && !sp.getBoolean("fsi_asked", false)) {
                    sp.edit().putBoolean("fsi_asked", true).apply();
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:" + getContext().getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i);
                }
            }
        } catch (Exception ignored) { }
    }

    @PluginMethod
    public void stopAlarm(PluginCall call) {
        try {
            NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            nm.cancelAll();
        } catch (Exception ignored) { }
        call.resolve(new JSObject());
    }

    @PluginMethod
    public void schedule(PluginCall call) {
        try {
            JSONArray arr = call.getArray("notifications");
            AlarmScheduler.scheduleAll(getContext(), arr == null ? new JSONArray() : arr);
            call.resolve(new JSObject());
        } catch (Exception e) {
            call.reject("schedule failed: " + e.getMessage());
        }
    }
}
