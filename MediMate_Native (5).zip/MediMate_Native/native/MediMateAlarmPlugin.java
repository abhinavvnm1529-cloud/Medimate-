package com.abhi.medimate;

import android.Manifest;
import android.content.ContentValues;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONArray;

@CapacitorPlugin(name = "MediMateAlarm")
public class MediMateAlarmPlugin extends Plugin {

    private boolean notifGranted() {
        return Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(getContext(),
                Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void requestSetup(PluginCall call) {
        try {
            if (!notifGranted()) {
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4711);
            }
        } catch (Exception ignored) { }
        call.resolve(new JSObject());
    }

    @Override
    protected void handleOnResume() {
        super.handleOnResume();
        try {
            if (Build.VERSION.SDK_INT >= 34 && notifGranted()) {
                NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
                SharedPreferences sp = getContext().getSharedPreferences("mm_setup", Context.MODE_PRIVATE);
                if (!nm.canUseFullScreenIntent() && !sp.getBoolean("fsi_asked", false)) {
                    sp.edit().putBoolean("fsi_asked", true).apply();
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:" + getContext().getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i);
                }
            }
        } catch (Exception ignored) { }
    }

    @PluginMethod
    public void stopAlarm(PluginCall call) {
        try {
            NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            nm.cancelAll();
        } catch (Exception ignored) { }
        call.resolve(new JSObject());
    }

    @PluginMethod
    public void savePdf(PluginCall call) {
        try {
            String name = call.getString("name", "MediMate.pdf");
            String data = call.getString("data");
            if (data == null) { call.reject("no data"); return; }
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            Context c = getContext();
            JSObject r = new JSObject();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) { call.reject("could not create file"); return; }
                OutputStream os = c.getContentResolver().openOutputStream(u);
                os.write(bytes);
                os.close();
                r.put("saved", true);
            } else {
                File dir = new File(c.getCacheDir(), "pdf");
                dir.mkdirs();
                File f = new File(dir, name);
                FileOutputStream fo = new FileOutputStream(f);
                fo.write(bytes);
                fo.close();
                Uri uri = FileProvider.getUriForFile(c, c.getPackageName() + ".fileprovider", f);
                Intent s = new Intent(Intent.ACTION_SEND);
                s.setType("application/pdf");
                s.putExtra(Intent.EXTRA_STREAM, uri);
                s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent ch = Intent.createChooser(s, "Save or share your timetable");
                ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(ch);
                r.put("saved", false);
            }
            call.resolve(r);
        } catch (Exception e) {
            call.reject("save failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void schedule(PluginCall call) {
        try {
            JSONArray arr = call.getArray("notifications");
            AlarmScheduler.scheduleAll(getContext(), arr == null ? new JSONArray() : arr);
            call.resolve(new JSObject());
        } catch (Exception e) {
            call.reject("schedule failed: " + e.getMessage());
        }
    }
}
