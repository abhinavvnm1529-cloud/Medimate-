package com.abhi.medimate;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {
    static final String CH = "medimate_alarm_v1";

    @Override
    public void onReceive(Context c, Intent in) {
        int id = in.getIntExtra("id", 1);
        if ("early".equals(in.getStringExtra("kind"))) { postEarly(c, in, id); return; }
        String title = in.getStringExtra("title");
        String body = in.getStringExtra("body");
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        String toneUri = c.getSharedPreferences("mm_setup", Context.MODE_PRIVATE).getString("toneUri", "");
        Uri sound = (toneUri == null || toneUri.isEmpty()) ? RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) : Uri.parse(toneUri);
        if (sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        final String chId = "medimate_alarm_s" + Integer.toHexString(String.valueOf(sound).hashCode());
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(chId, "Medicine alarms", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Rings like a call at medicine time");
            ch.enableVibration(true);
            ch.setVibrationPattern(new long[]{0, 800, 500, 800, 500, 800});
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            ch.setBypassDnd(true);
            ch.setSound(sound, new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(c, MainActivity.class);
        open.setAction("com.abhi.medimate.OPEN_ALARM");
        open.putExtra("alarmLaunch", true);
        open.putExtra("profileId", in.getLongExtra("profileId", -1));
        open.putExtra("medicineId", in.getLongExtra("medicineId", -1));
        open.putExtra("profileName", in.getStringExtra("profileName"));
        open.putExtra("medicineName", in.getStringExtra("medicineName"));
        open.putExtra("dose", in.getStringExtra("dose"));
        open.putExtra("time", in.getStringExtra("time"));
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, chId)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title == null ? "Medicine time" : title)
                .setContentText(body == null ? "" : body)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setOngoing(false)
                .setTimeoutAfter(120000)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true);
        if (Build.VERSION.SDK_INT < 26) {
            b.setSound(sound).setVibrate(new long[]{0, 800, 500, 800, 500, 800});
        }
        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT;
        nm.notify(id, n);
    }

    static final String EARLY_CH = "medimate_early_v1";
    static final int EARLY_BASE = 100000;

    /** Small "coming up in 15 minutes" notification with a Taken button. */
    private void postEarly(Context c, Intent in, int id) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(EARLY_CH, "Early reminders", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("A small heads-up 15 minutes before a medicine");
            ch.enableVibration(true);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        int nid = EARLY_BASE + id;
        String title = in.getStringExtra("title");
        String body = in.getStringExtra("body");
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(c, nid, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent act = new Intent(c, EarlyActionReceiver.class);
        act.setAction("com.abhi.medimate.TAKEN." + id);
        act.putExtra("nid", nid);
        act.putExtra("taken", in.getStringExtra("taken"));
        act.putExtra("mainIds", in.getStringExtra("mainIds"));
        act.putExtra("selfId", id);
        PendingIntent takenPi = PendingIntent.getBroadcast(c, nid, act,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, EARLY_CH)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title == null ? "Medicine coming up" : title)
                .setContentText(body == null ? "" : body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body == null ? "" : body))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setTimeoutAfter(16 * 60 * 1000L)
                .setContentIntent(openPi)
                .addAction(android.R.drawable.checkbox_on_background, "Taken", takenPi);
        nm.notify(nid, b.build());
    }
}
