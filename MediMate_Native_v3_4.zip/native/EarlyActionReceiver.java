package com.abhi.medimate;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

/** The "Taken" button on the 15-minute heads-up: records the dose and cancels its alarm, even if the app is closed. */
public class EarlyActionReceiver extends BroadcastReceiver {
    static final String PENDING = "mm_pending";

    @Override
    public void onReceive(Context c, Intent in) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            int nid = in.getIntExtra("nid", -1);
            int selfId = in.getIntExtra("selfId", -1);
            if (nid >= 0) nm.cancel(nid);

            java.util.HashSet<Integer> gone = new java.util.HashSet<>();
            if (selfId >= 0) gone.add(selfId);
            String ids = in.getStringExtra("mainIds");
            if (ids != null && !ids.isEmpty()) {
                for (String part : ids.split(",")) {
                    try {
                        int mid = Integer.parseInt(part.trim());
                        gone.add(mid);
                        PendingIntent pi = PendingIntent.getBroadcast(c, mid, AlarmScheduler.baseIntent(c, mid),
                                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                        if (pi != null) { am.cancel(pi); pi.cancel(); }
                        nm.cancel(mid);
                    } catch (Exception ignored) { }
                }
            }

            // remember what was taken; the app records it the next time it opens
            SharedPreferences sp = c.getSharedPreferences(PENDING, Context.MODE_PRIVATE);
            JSONArray all = new JSONArray(sp.getString("taken", "[]"));
            String t = in.getStringExtra("taken");
            if (t != null && !t.isEmpty()) {
                JSONArray add = new JSONArray(t);
                for (int i = 0; i < add.length(); i++) all.put(add.getJSONObject(i));
            }
            sp.edit().putString("taken", all.toString()).apply();

            // keep the saved alarm list in step so a reboot does not bring the cancelled alarms back
            SharedPreferences ap = c.getSharedPreferences(AlarmScheduler.PREFS, Context.MODE_PRIVATE);
            JSONArray old = new JSONArray(ap.getString(AlarmScheduler.KEY, "[]"));
            JSONArray kept = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.getJSONObject(i);
                if (!gone.contains(o.optInt("id", -1))) kept.put(o);
            }
            ap.edit().putString(AlarmScheduler.KEY, kept.toString()).apply();

            Toast.makeText(c, "Marked as taken", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) { }
    }
}
