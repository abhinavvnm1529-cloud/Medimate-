package com.abhi.medimate;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.res.Configuration;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.media.AudioManager;
import android.app.Activity;
import androidx.core.view.WindowInsetsControllerCompat;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.util.Base64;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.app.NotificationManager;
import android.app.DownloadManager;
import android.os.Environment;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONArray;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.pm.PackageInstaller;
import android.app.PendingIntent;
import android.media.AudioAttributes;
import android.os.Process;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@CapacitorPlugin(name = "MediMateAlarm")
public class MediMateAlarmPlugin extends Plugin {

    private boolean notifGranted() {
        return Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(getContext(),
                Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void requestSetup(PluginCall call) {
        try {
            if (!notifGranted()) {
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4711);
            }
        } catch (Exception ignored) { }
        call.resolve(new JSObject());
    }

    @Override
    protected void handleOnResume() {
        super.handleOnResume();
        try {
            if (Build.VERSION.SDK_INT >= 34 && notifGranted()) {
                NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
                SharedPreferences sp = getContext().getSharedPreferences("mm_setup", Context.MODE_PRIVATE);
                if (!nm.canUseFullScreenIntent() && !sp.getBoolean("fsi_asked", false)) {
                    sp.edit().putBoolean("fsi_asked", true).apply();
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:" + getContext().getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i);
                }
            }
        } catch (Exception ignored) { }
    }

    @PluginMethod
    public void stopAlarm(PluginCall call) {
        try {
            NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            nm.cancelAll();
        } catch (Exception ignored) { }
        call.resolve(new JSObject());
    }

    @PluginMethod
    public void savePdf(PluginCall call) {
        try {
            String name = call.getString("name", "MediMate.pdf");
            String data = call.getString("data");
            if (data == null) { call.reject("no data"); return; }
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            Context c = getContext();
            JSObject r = new JSObject();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) { call.reject("could not create file"); return; }
                OutputStream os = c.getContentResolver().openOutputStream(u);
                if (os == null) { call.reject("could not open file"); return; }
                try { os.write(bytes); } finally { os.close(); }
                r.put("saved", true);
                r.put("uri", u.toString());
            } else {
                File dir = new File(c.getCacheDir(), "pdf");
                dir.mkdirs();
                File f = new File(dir, name);
                FileOutputStream fo = new FileOutputStream(f);
                try { fo.write(bytes); } finally { fo.close(); }
                Uri uri = FileProvider.getUriForFile(c, c.getPackageName() + ".fileprovider", f);
                Intent s = new Intent(Intent.ACTION_SEND);
                s.setType("application/pdf");
                s.putExtra(Intent.EXTRA_STREAM, uri);
                s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent ch = Intent.createChooser(s, "Save or share your timetable");
                ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(ch);
                r.put("saved", false);
            }
            call.resolve(r);
        } catch (Exception e) {
            call.reject("save failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void openPdf(PluginCall call) {
        try {
            String uri = call.getString("uri");
            if (uri == null) { call.reject("no uri"); return; }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(uri), "application/pdf");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve(new JSObject());
        } catch (Exception e) {
            call.reject("open failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void setOrientation(PluginCall call) {
        final String mode = call.getString("mode", "auto");
        final Activity a = getActivity();
        a.runOnUiThread(() -> a.setRequestedOrientation("portrait".equals(mode)
                ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                : "landscape".equals(mode) ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : "system".equals(mode) ? ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                : ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR));
        call.resolve(new JSObject());
    }

    @PluginMethod
    public void setPrefs(PluginCall call) {
        try {
            Integer tone = call.getInt("tone", 0);
            Integer vol = call.getInt("vol", 80);
            getContext().getSharedPreferences("mm_setup", Context.MODE_PRIVATE).edit().putInt("tone", tone).apply();
            AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            am.setStreamVolume(AudioManager.STREAM_ALARM, Math.max(1, Math.round(Math.max(10, vol) / 100f * max)), 0);
        } catch (Exception ignored) { }
        call.resolve(new JSObject());
    }

    @PluginMethod
    public void setBars(PluginCall call) {
        final boolean dark = Boolean.TRUE.equals(call.getBoolean("dark", false));
        final Activity a = getActivity();
        a.runOnUiThread(() -> {
            a.getWindow().getDecorView().setBackgroundColor(Color.parseColor(dark ? "#070502" : "#f8fafd"));
            WindowInsetsControllerCompat c = new WindowInsetsControllerCompat(a.getWindow(), a.getWindow().getDecorView());
            c.setAppearanceLightStatusBars(!dark);
            c.setAppearanceLightNavigationBars(!dark);
        });
        call.resolve(new JSObject());
    }

    @PluginMethod
    public void haptic(PluginCall call) {
        try {
            Vibrator v = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
            boolean click = "click".equals(call.getString("kind", "tick"));
            int intensity = Math.max(0, Math.min(100, call.getInt("intensity", 72)));
            if (v != null && v.hasVibrator() && intensity > 0) {
                // Every percent is stronger: both the motor amplitude and the length rise with the slider.
                // 100% = full amplitude (255) and the longest pulse.
                int duration = Math.round((click ? 18 : 12) + intensity * (click ? 0.85f : 0.6f));
                if (Build.VERSION.SDK_INT >= 26) {
                    VibrationEffect fx;
                    if (v.hasAmplitudeControl()) {
                        int amp = Math.max(1, Math.min(255, Math.round(intensity * 2.55f)));
                        fx = VibrationEffect.createOneShot(duration, amp);
                    } else if (intensity >= 97) {
                        fx = VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE);
                    } else {
                        // No amplitude control: imitate strength by pulsing on/off (duty cycle = intensity).
                        int unit = 6, on = Math.max(1, Math.round(unit * intensity / 100f)), off = Math.max(1, unit - on);
                        int reps = Math.max(1, duration / unit);
                        long[] t = new long[reps * 2 + 1];
                        for (int i = 0; i < reps; i++) { t[1 + i * 2] = on; t[2 + i * 2] = off; }
                        fx = VibrationEffect.createWaveform(t, -1);
                    }
                    // Use the alarm vibration channel so the phone's "touch vibration strength" cap does not weaken it.
                    try {
                        if (Build.VERSION.SDK_INT >= 33) {
                            v.vibrate(fx, android.os.VibrationAttributes.createForUsage(android.os.VibrationAttributes.USAGE_ALARM));
                        } else {
                            v.vibrate(fx, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                        }
                    } catch (Exception e) { v.vibrate(fx); }
                } else {
                    v.vibrate(duration);
                }
            }
        } catch (Exception ignored) { }
        call.resolve(new JSObject());
    }

    private void emitProgress(String status, long done, long total, String msg) {
        JSObject o = new JSObject();
        o.put("status", status); o.put("done", done); o.put("total", total);
        if (msg != null) o.put("message", msg);
        notifyListeners("updateProgress", o);
    }

    @PluginMethod
    public void downloadApk(final PluginCall call) {
        final String url = call.getString("url", "");
        if (!url.startsWith("https://github.com/") && !url.startsWith("https://release-assets.githubusercontent.com/")
                && !url.startsWith("https://objects.githubusercontent.com/")) {
            call.reject("Untrusted APK download address"); return;
        }
        call.resolve(new JSObject());
        new Thread(() -> {
            try {
                File dir = new File(getContext().getCacheDir(), "update");
                dir.mkdirs();
                File[] old = dir.listFiles();
                if (old != null) for (File f : old) f.delete();
                File apk = new File(dir, "MediMate-update.apk");
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setInstanceFollowRedirects(true);
                c.setConnectTimeout(15000); c.setReadTimeout(20000);
                int code = c.getResponseCode();
                if (code / 100 == 3) {
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    c = (HttpURLConnection) new URL(loc).openConnection();
                    c.setConnectTimeout(15000); c.setReadTimeout(20000);
                    code = c.getResponseCode();
                }
                if (code != 200) { emitProgress("error", 0, 0, "Server replied " + code); return; }
                long total = c.getContentLengthLong();
                InputStream in = c.getInputStream();
                FileOutputStream out = new FileOutputStream(apk);
                byte[] buf = new byte[32768];
                long done = 0, last = 0; int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n); done += n;
                    long now = System.currentTimeMillis();
                    if (now - last > 250) { last = now; emitProgress("downloading", done, total, null); }
                }
                out.close(); in.close(); c.disconnect();
                emitProgress("downloading", total > 0 ? total : done, total > 0 ? total : done, null);
                emitProgress("installing", done, done, null);
                installApk(apk);
            } catch (Exception e) {
                emitProgress("error", 0, 0, e.getMessage());
            }
        }).start();
    }

    private void installApk(File apk) throws Exception {
        final Context ctx = getContext();
        // Android only lets an app install after the user has allowed "install unknown apps" for MediMate.
        if (Build.VERSION.SDK_INT >= 26 && !ctx.getPackageManager().canRequestPackageInstalls()) {
            Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
            emitProgress("error", 0, 0, "Allow MediMate to install updates, then tap Update again");
            return;
        }
        PackageInstaller pi = ctx.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams sp = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        if (Build.VERSION.SDK_INT >= 31) sp.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
        int sid = pi.createSession(sp);
        PackageInstaller.Session ses = pi.openSession(sid);
        InputStream in = new java.io.FileInputStream(apk);
        OutputStream os = ses.openWrite("medimate", 0, apk.length());
        byte[] b = new byte[65536]; int n;
        while ((n = in.read(b)) > 0) os.write(b, 0, n);
        ses.fsync(os); os.close(); in.close();
        final String action = ctx.getPackageName() + ".INSTALL_RESULT";
        BroadcastReceiver rcv = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent it) {
                int st = it.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
                if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                    Intent confirm = it.getParcelableExtra(Intent.EXTRA_INTENT);
                    if (confirm != null) { confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(confirm); }
                } else if (st != PackageInstaller.STATUS_SUCCESS) {
                    emitProgress("error", 0, 0, it.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE));
                    try { c.unregisterReceiver(this); } catch (Exception ignored) { }
                }
            }
        };
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(rcv, new IntentFilter(action), Context.RECEIVER_NOT_EXPORTED);
        else ctx.registerReceiver(rcv, new IntentFilter(action));
        Intent cb = new Intent(action).setPackage(ctx.getPackageName());
        PendingIntent pend = PendingIntent.getBroadcast(ctx, sid, cb,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0));
        ses.commit(pend.getIntentSender());
    }

    @PluginMethod
    public void closeApp(PluginCall call) {
        call.resolve(new JSObject());
        final Activity a = getActivity();
        a.runOnUiThread(() -> {
            try { a.finishAndRemoveTask(); } catch (Exception e) { a.finish(); }
            // End the process so nothing keeps running in the background (alarms are held by Android's AlarmManager).
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> Process.killProcess(Process.myPid()), 400);
        });
    }

    @PluginMethod
    public void getNight(PluginCall call) {
        JSObject r = new JSObject();
        r.put("dark", (getContext().getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES);
        call.resolve(r);
    }

    @PluginMethod
    public void shareText(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, call.getString("text", ""));
            Intent ch = Intent.createChooser(i, "Share profile");
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(ch);
            call.resolve(new JSObject());
        } catch (Exception e) { call.reject("share failed: " + e.getMessage()); }
    }

    @PluginMethod
    public void copyText(PluginCall call) {
        try {
            ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("MediMate profile link", call.getString("text", "")));
            call.resolve(new JSObject());
        } catch (Exception e) { call.reject("copy failed: " + e.getMessage()); }
    }

    @PluginMethod
    public void openUrl(PluginCall call) {
        try {
            String u = call.getString("url", "");
            if (!u.startsWith("https://")) { call.reject("bad url"); return; }
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve(new JSObject());
        } catch (Exception e) { call.reject("open failed: " + e.getMessage()); }
    }

    @PluginMethod
    public void schedule(PluginCall call) {
        try {
            JSONArray arr = call.getArray("notifications");
            AlarmScheduler.scheduleAll(getContext(), arr == null ? new JSONArray() : arr);
            call.resolve(new JSObject());
        } catch (Exception e) {
            call.reject("schedule failed: " + e.getMessage());
        }
    }
}
