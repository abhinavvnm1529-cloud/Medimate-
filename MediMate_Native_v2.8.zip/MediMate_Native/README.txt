MediMate native project (Capacitor + custom MediMateAlarm plugin).
Upload this ZIP to a GitHub repo together with .github/workflows/build.yml.
GitHub builds the APK automatically and publishes it under Releases.

worker/  = the AI timetable service (Cloudflare Worker). Redeploy worker/worker.js to fix
           "AI service error (404)". See worker/README.txt.


MediMate 2.7 changes:
- Android APK updates use Android DownloadManager instead of opening a browser download page.
- Android versionCode is set to 27 and versionName to 2.7 by native/patch_manifest.py.
- Haptic intensity uses a continuous slider and the device's supported vibration amplitude.
- All-profile backup links are supported; links contain unencrypted personal data and must be kept private.
- Prescription scan progress is a straight blue progress bar.
- Keep the repository's existing .github/workflows/build.yml; it reads APP_VERSION from www/index.html and runs native/patch_manifest.py.
